package com.example

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit
import java.net.SocketTimeoutException
import java.net.UnknownHostException

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    @kotlinx.serialization.SerialName("system_instruction")
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val role: String? = null,
    val parts: List<Part>? = null
)

@Serializable
data class InlineData(
    @kotlinx.serialization.SerialName("mime_type")
    val mimeType: String,
    val data: String
)

@Serializable
data class Part(
    val text: String? = null,
    @kotlinx.serialization.SerialName("inline_data")
    val inlineData: InlineData? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@Serializable
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val json = Json { ignoreUnknownKeys = true; isLenient = true }
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

suspend fun generatePresentationOutline(planContent: String): String {
    val apiKey = com.example.BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
         return "Error: API ключ не настроен."
    }
    val systemPrompt = "Ты — методист. На основе плана урока составь структуру презентации. Для каждого слайда напиши заголовок, текст, и опиши визуальный ряд. Ответ выдай в формате Markdown."
    val request = GenerateContentRequest(
        contents = listOf(Content(parts = listOf(Part(text = "План урока:\n$planContent")))),
        systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
    )
    return try {
        val response = RetrofitClient.service.generateContent(apiKey, request)
        response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Error: Нет ответа."
    } catch (e: Exception) {
        friendlyGeminiError(e)
    }
}

suspend fun generateFiveMinuteActivity(planContent: String): String {
    val apiKey = com.example.BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
         return "Error: API ключ не настроен."
    }
    val systemPrompt = "Ты — методист начальной школы. Проанализируй этот план урока и создай интересную 5-минутную активность (пятиминутку), которая объединит оба класса (например, интеллектуальная разминка, игра на внимание или нейрогимнастика, связанная с темами урока). Ответ выдай в формате Markdown, без лишних вступлений."
    val request = GenerateContentRequest(
        contents = listOf(Content(parts = listOf(Part(text = "План урока:\n$planContent")))),
        systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
    )
    return try {
        val response = RetrofitClient.service.generateContent(apiKey, request)
        response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Error: Нет ответа."
    } catch (e: Exception) {
        friendlyGeminiError(e)
    }
}

suspend fun generateHomeworkFromImage(planContent: String, images: List<Pair<String, String>>): String {
    val apiKey = com.example.BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
         return "Error: API ключ не настроен."
    }
    val systemPrompt = "Ты — методист начальной школы. Проанализируй этот план урока и приложенные фотографии учебников. Составь домашнее задание, которое опирается на материал из учебников и соответствует плану урока. Ответ выдай в формате Markdown."
    
    val parts = mutableListOf<Part>(Part(text = "План урока:\n$planContent"))
    images.forEach { (mimeType, base64Image) ->
        parts.add(Part(inlineData = InlineData(mimeType = mimeType, data = base64Image)))
    }
    
    val request = GenerateContentRequest(
        contents = listOf(Content(parts = parts)),
        systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
    )
    return try {
        val response = RetrofitClient.service.generateContent(apiKey, request)
        response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Error: Нет ответа."
    } catch (e: retrofit2.HttpException) {
        friendlyGeminiError(e)
    } catch (e: Exception) {
        friendlyGeminiError(e)
    }
}

suspend fun regeneratePlanSection(
    planContent: String,
    sectionName: String,
    additionalInstruction: String = ""
): String {
    val apiKey = BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") return "Error: API ключ не настроен."
    val exactHeader = sectionHeader(sectionName)
    val prompt = """
        Перепиши только один раздел существующего плана урока МКШ: «$sectionName».
        Верни только готовый раздел Markdown, начиная строго с заголовка:
        $exactHeader

        Сохрани предметы, классы, темы и общую длительность из исходного плана. Не меняй остальные разделы. Для тайминга проверь непрерывность интервалов и общую сумму минут. Для карточек создай полностью готовые ученические листы с заголовками второго уровня «## Карточка — Класс А», «## Карточка — Класс Б» и отдельным «## Ответы учителю».
        Дополнительное пожелание: ${additionalInstruction.ifBlank { "нет" }}
    """.trimIndent()
    val request = GenerateContentRequest(
        contents = listOf(Content(parts = listOf(Part(text = "Исходный план:\n$planContent")))),
        systemInstruction = Content(parts = listOf(Part(text = prompt)))
    )
    return try {
        RetrofitClient.service.generateContent(apiKey, request)
            .candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: "Error: Gemini не вернул новый раздел."
    } catch (e: Exception) {
        friendlyGeminiError(e)
    }
}

fun replacePlanSection(planContent: String, sectionName: String, generatedSection: String): String {
    val expectedHeader = sectionHeader(sectionName)
    val cleaned = generatedSection
        .removePrefix("```markdown")
        .removePrefix("```")
        .removeSuffix("```")
        .trim()
    val replacement = if (cleaned.startsWith("# ")) cleaned else "$expectedHeader\n$cleaned"
    val lines = planContent.lines()
    val start = lines.indexOfFirst { it.startsWith("# ") && it.contains(sectionName, ignoreCase = true) }
    if (start < 0) return planContent.trimEnd() + "\n\n" + replacement + "\n"
    val end = (start + 1 until lines.size).firstOrNull { lines[it].startsWith("# ") } ?: lines.size
    return (lines.take(start) + replacement.lines() + lines.drop(end)).joinToString("\n").trimEnd() + "\n"
}

private fun sectionHeader(sectionName: String): String = when (sectionName) {
    "Поминутный тайминг" -> "# ⏱ Поминутный тайминг"
    "Физкультминутка" -> "# 🤸 Физкультминутка"
    "Методические рекомендации" -> "# 💡 Методические рекомендации"
    "Материалы для самостоятельной работы" -> "# 📝 Материалы для самостоятельной работы"
    "Готовые карточки для печати" -> "# 🖨 Готовые карточки для печати"
    "Домашнее задание" -> "# 📚 Домашнее задание"
    else -> "# $sectionName"
}

private fun friendlyGeminiError(error: Exception): String = when (error) {
    is UnknownHostException -> "Error: Нет подключения к интернету."
    is SocketTimeoutException -> "Error: Gemini отвечает слишком долго. Повторите запрос."
    is retrofit2.HttpException -> when (error.code()) {
        401, 403 -> "Error: Ключ Gemini отклонён. Проверьте ключ и доступ к модели."
        429 -> "Error: Лимит запросов Gemini исчерпан. Попробуйте немного позже."
        in 500..599 -> "Error: Gemini временно недоступен. Попробуйте позже."
        else -> "Error: Ошибка Gemini (код ${error.code()})."
    }
    else -> "Error: Не удалось выполнить запрос. ${error.localizedMessage.orEmpty()}"
}
