package com.example.data.remote

import android.util.Log
import com.google.firebase.firestore.FirebaseFirestore
import com.example.data.local.LessonPlanEntity
import kotlinx.coroutines.tasks.await
import java.security.MessageDigest

data class CloudDownloadResult(
    val plans: List<LessonPlanEntity> = emptyList(),
    val errorMessage: String? = null
)

object FirebaseSyncManager {
    private var db: FirebaseFirestore? = null

    fun initialize() {
        try {
            db = FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.d("FirebaseSync", "Firebase not initialized. Sync features will be disabled.")
        }
    }

    suspend fun syncPlan(plan: LessonPlanEntity, syncCode: String): Boolean {
        if (db == null) return false
        val normalizedCode = syncCode.trim().lowercase()
        if (normalizedCode.length < 6) return false
        return try {
            val planMap = hashMapOf(
                "title" to plan.title,
                "content" to plan.content,
                "timestamp" to plan.timestamp,
                "isFavorite" to plan.isFavorite,
                "tags" to plan.tags
            )
            val stableId = MessageDigest.getInstance("SHA-256")
                .digest("${plan.timestamp}|${plan.title}".toByteArray())
                .joinToString("") { "%02x".format(it) }
                .take(24)
            db!!.collection("sync").document(normalizedCode).collection("plans").document(stableId)
                .set(planMap)
                .await()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun downloadPlans(syncCode: String): CloudDownloadResult {
        if (db == null) return CloudDownloadResult(errorMessage = "Облачная копия не настроена")
        val normalizedCode = syncCode.trim().lowercase()
        if (normalizedCode.length < 6) return CloudDownloadResult(errorMessage = "Код должен содержать не менее 6 символов")
        return try {
            val snapshot = db!!.collection("sync").document(normalizedCode).collection("plans").get().await()
            val plans = snapshot.documents.mapNotNull { doc ->
                val title = doc.getString("title") ?: return@mapNotNull null
                val content = doc.getString("content") ?: ""
                val timestamp = doc.getLong("timestamp") ?: 0L
                val isFavorite = doc.getBoolean("isFavorite") ?: false
                val tags = doc.getString("tags") ?: ""
                LessonPlanEntity(folderId = 0, title = title, content = content, timestamp = timestamp, isFavorite = isFavorite, tags = tags)
            }
            CloudDownloadResult(plans = plans)
        } catch (e: Exception) {
            Log.e("FirebaseSync", "Download failed", e)
            CloudDownloadResult(errorMessage = "Не удалось скачать облачную копию. Проверьте интернет и настройки Firebase")
        }
    }
}
