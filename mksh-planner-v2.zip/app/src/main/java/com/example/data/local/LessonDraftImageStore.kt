package com.example.data.local

import android.content.Context
import android.util.Base64
import java.io.File

object LessonDraftImageStore {
    private const val DIRECTORY = "lesson_draft_images"

    fun load(context: Context): List<Pair<String, String>> = runCatching {
        val directory = File(context.filesDir, DIRECTORY)
        directory.listFiles()
            ?.filter { it.isFile && it.extension == "draft" }
            ?.sortedBy { it.nameWithoutExtension.toIntOrNull() ?: Int.MAX_VALUE }
            ?.mapNotNull { file ->
                val bytes = file.readBytes()
                val separator = bytes.indexOf('\n'.code.toByte())
                if (separator <= 0) return@mapNotNull null
                val mime = bytes.copyOfRange(0, separator).toString(Charsets.UTF_8)
                val image = bytes.copyOfRange(separator + 1, bytes.size)
                mime to Base64.encodeToString(image, Base64.NO_WRAP)
            }
            .orEmpty()
    }.getOrDefault(emptyList())

    fun save(context: Context, images: List<Pair<String, String>>) {
        val directory = File(context.filesDir, DIRECTORY)
        if (!directory.exists()) directory.mkdirs()
        directory.listFiles()?.forEach { it.delete() }
        images.take(6).forEachIndexed { index, (mime, base64) ->
            val imageBytes = Base64.decode(base64, Base64.DEFAULT)
            File(directory, "$index.draft").outputStream().use { output ->
                output.write(mime.toByteArray(Charsets.UTF_8))
                output.write('\n'.code)
                output.write(imageBytes)
            }
        }
    }

    fun clear(context: Context) {
        File(context.filesDir, DIRECTORY).listFiles()?.forEach { it.delete() }
    }
}
