package com.example.data.local

import android.content.Context

data class LessonDraft(
    val classASubject: String = "",
    val classAGrade: String = "",
    val classATopic: String = "",
    val classBSubject: String = "",
    val classBGrade: String = "",
    val classBTopic: String = "",
    val lessonType: String = "Комбинированный",
    val lessonDuration: String = "45",
    val additionalInstructions: String = "",
    val planTitle: String = "",
    val generatedPlan: String = "",
    val planMode: String = "Практический",
    val independentMinutesA: Int = 7,
    val independentMinutesB: Int = 7
) {
    val isEmpty: Boolean
        get() = classASubject.isBlank() && classAGrade.isBlank() && classATopic.isBlank() &&
            classBSubject.isBlank() && classBGrade.isBlank() && classBTopic.isBlank() &&
            additionalInstructions.isBlank() && planTitle.isBlank() && generatedPlan.isBlank()
}

object LessonDraftStore {
    private const val PREFS = "lesson_draft"

    fun load(context: Context): LessonDraft {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return LessonDraft(
            classASubject = prefs.getString("classASubject", "").orEmpty(),
            classAGrade = prefs.getString("classAGrade", "").orEmpty(),
            classATopic = prefs.getString("classATopic", "").orEmpty(),
            classBSubject = prefs.getString("classBSubject", "").orEmpty(),
            classBGrade = prefs.getString("classBGrade", "").orEmpty(),
            classBTopic = prefs.getString("classBTopic", "").orEmpty(),
            lessonType = prefs.getString("lessonType", "Комбинированный") ?: "Комбинированный",
            lessonDuration = prefs.getString("lessonDuration", "45") ?: "45",
            additionalInstructions = prefs.getString("additionalInstructions", "").orEmpty(),
            planTitle = prefs.getString("planTitle", "").orEmpty(),
            generatedPlan = prefs.getString("generatedPlan", "").orEmpty(),
            planMode = prefs.getString("planMode", "Практический") ?: "Практический",
            independentMinutesA = prefs.getInt("independentMinutesA", 7),
            independentMinutesB = prefs.getInt("independentMinutesB", 7)
        )
    }

    fun save(context: Context, draft: LessonDraft) {
        if (draft.isEmpty) {
            clear(context)
            return
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("classASubject", draft.classASubject)
            .putString("classAGrade", draft.classAGrade)
            .putString("classATopic", draft.classATopic)
            .putString("classBSubject", draft.classBSubject)
            .putString("classBGrade", draft.classBGrade)
            .putString("classBTopic", draft.classBTopic)
            .putString("lessonType", draft.lessonType)
            .putString("lessonDuration", draft.lessonDuration)
            .putString("additionalInstructions", draft.additionalInstructions)
            .putString("planTitle", draft.planTitle)
            .putString("generatedPlan", draft.generatedPlan)
            .putString("planMode", draft.planMode)
            .putInt("independentMinutesA", draft.independentMinutesA)
            .putInt("independentMinutesB", draft.independentMinutesB)
            .apply()
    }

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
    }
}
