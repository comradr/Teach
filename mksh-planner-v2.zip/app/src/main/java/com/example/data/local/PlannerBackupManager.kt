package com.example.data.local

import android.content.Context
import android.net.Uri
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
private data class FolderBackup(val id: Long, val name: String, val isArchived: Boolean)

@Serializable
private data class PlanBackup(
    val folderId: Long,
    val title: String,
    val content: String,
    val isFavorite: Boolean,
    val tags: String,
    val timestamp: Long
)

@Serializable
private data class PlannerBackup(
    val schemaVersion: Int = 1,
    val folders: List<FolderBackup>,
    val plans: List<PlanBackup>
)

data class BackupImportResult(val addedPlans: Int, val errorMessage: String? = null)

object PlannerBackupManager {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }

    suspend fun export(context: Context, uri: Uri, dao: PlannerDao): String? = try {
        val folders = dao.getAllFoldersSnapshot()
        val plans = dao.getAllPlansSnapshot()
        val backup = PlannerBackup(
            folders = folders.map { FolderBackup(it.id, it.name, it.isArchived) },
            plans = plans.map { PlanBackup(it.folderId, it.title, it.content, it.isFavorite, it.tags, it.timestamp) }
        )
        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
            writer.write(json.encodeToString(backup))
        } ?: return "Не удалось открыть файл"
        null
    } catch (e: Exception) {
        e.localizedMessage ?: "Не удалось создать резервную копию"
    }

    suspend fun importBackup(context: Context, uri: Uri, dao: PlannerDao): BackupImportResult = try {
        val text = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            ?: return BackupImportResult(0, "Не удалось прочитать файл")
        val backup = json.decodeFromString<PlannerBackup>(text)
        if (backup.schemaVersion != 1) return BackupImportResult(0, "Неподдерживаемая версия резервной копии")

        val folderIdMap = mutableMapOf<Long, Long>()
        backup.folders.forEach { folder ->
            val existing = dao.getFolderByName(folder.name)
            val localId = existing?.id ?: dao.insertFolder(FolderEntity(name = folder.name, isArchived = folder.isArchived))
            folderIdMap[folder.id] = localId
        }

        var added = 0
        backup.plans.forEach { plan ->
            val localFolderId = folderIdMap[plan.folderId] ?: return@forEach
            if (dao.findMatchingPlan(localFolderId, plan.title, plan.timestamp) == null) {
                dao.insertLessonPlan(
                    LessonPlanEntity(
                        folderId = localFolderId,
                        title = plan.title,
                        content = plan.content,
                        isFavorite = plan.isFavorite,
                        tags = plan.tags,
                        timestamp = plan.timestamp
                    )
                )
                added++
            }
        }
        BackupImportResult(added)
    } catch (e: Exception) {
        BackupImportResult(0, "Файл повреждён или имеет неверный формат")
    }
}
