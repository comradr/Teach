package com.example.data.local

import kotlinx.coroutines.flow.Flow

class PlannerRepository(private val plannerDao: PlannerDao) {

    val allFolders: Flow<List<FolderEntity>> = plannerDao.getAllFolders()
    val archivedFolders: Flow<List<FolderEntity>> = plannerDao.getArchivedFolders()

    suspend fun insertFolder(name: String): Long {
        return plannerDao.insertFolder(FolderEntity(name = name))
    }
    
    suspend fun updateFolderArchiveStatus(folderId: Long, isArchived: Boolean) {
        plannerDao.updateFolderArchiveStatus(folderId, isArchived)
    }

    suspend fun getFolderByName(name: String): FolderEntity? {
        return plannerDao.getFolderByName(name)
    }

    suspend fun insertLessonPlan(folderId: Long, title: String, content: String): Long {
        return plannerDao.insertLessonPlan(
            LessonPlanEntity(
                folderId = folderId,
                title = title,
                content = content
            )
        )
    }

    fun getPlansForFolder(folderId: Long): Flow<List<LessonPlanEntity>> {
        return plannerDao.getPlansForFolder(folderId)
    }

    suspend fun getPlanById(planId: Long): LessonPlanEntity? {
        return plannerDao.getPlanById(planId)
    }

    suspend fun updateFavoriteStatus(planId: Long, isFavorite: Boolean) {
        plannerDao.updateFavoriteStatus(planId, isFavorite)
    }
    
    suspend fun updatePlanTags(planId: Long, tags: String) {
        plannerDao.updatePlanTags(planId, tags)
    }

    suspend fun updatePlan(planId: Long, title: String, content: String) {
        plannerDao.updatePlan(planId, title, content)
    }

    suspend fun movePlan(planId: Long, folderId: Long) {
        plannerDao.movePlan(planId, folderId)
    }

    fun getFavoritePlans(): Flow<List<LessonPlanEntity>> {
        return plannerDao.getFavoritePlans()
    }

    suspend fun deletePlan(planId: Long) {
        plannerDao.deletePlan(planId)
    }

    suspend fun deleteFolder(folderId: Long) {
        plannerDao.deleteFolder(folderId)
    }
}
