package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(entities = [FolderEntity::class, LessonPlanEntity::class], version = 4, exportSchema = false)
abstract class PlannerDatabase : RoomDatabase() {
    abstract fun plannerDao(): PlannerDao

    companion object {
        @Volatile
        private var INSTANCE: PlannerDatabase? = null

        fun getDatabase(context: Context): PlannerDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PlannerDatabase::class.java,
                    "planner_database"
                )
                .addMigrations(MIGRATION_1_4, MIGRATION_2_4, MIGRATION_3_4)
                .build()
                INSTANCE = instance
                instance
            }
        }

        private fun rebuildPreservingData(database: SupportSQLiteDatabase) {
            val folderColumns = database.query("PRAGMA table_info(folders)").use { cursor ->
                val nameIndex = cursor.getColumnIndex("name")
                buildSet {
                    while (cursor.moveToNext()) add(cursor.getString(nameIndex))
                }
            }
            database.execSQL(
                """
                CREATE TABLE IF NOT EXISTS folders_migration_backup (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    name TEXT NOT NULL,
                    isArchived INTEGER NOT NULL
                )
                """.trimIndent()
            )
            if (folderColumns.containsAll(listOf("id", "name"))) {
                val archived = if ("isArchived" in folderColumns) "isArchived" else "0"
                database.execSQL("INSERT INTO folders_migration_backup(id, name, isArchived) SELECT id, name, $archived FROM folders")
            }

            val planColumns = database.query("PRAGMA table_info(lesson_plans)").use { cursor ->
                val nameIndex = cursor.getColumnIndex("name")
                buildSet {
                    while (cursor.moveToNext()) add(cursor.getString(nameIndex))
                }
            }
            database.execSQL(
                """
                CREATE TABLE IF NOT EXISTS plans_migration_backup (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    folderId INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    isFavorite INTEGER NOT NULL,
                    tags TEXT NOT NULL,
                    timestamp INTEGER NOT NULL
                )
                """.trimIndent()
            )
            if (planColumns.containsAll(listOf("id", "folderId", "title", "content", "timestamp"))) {
                val favorite = if ("isFavorite" in planColumns) "isFavorite" else "0"
                val tags = if ("tags" in planColumns) "tags" else "''"
                database.execSQL(
                    "INSERT INTO plans_migration_backup(id, folderId, title, content, isFavorite, tags, timestamp) " +
                        "SELECT id, folderId, title, content, $favorite, $tags, timestamp FROM lesson_plans"
                )
            }

            database.execSQL("DROP TABLE IF EXISTS lesson_plans")
            database.execSQL("DROP TABLE IF EXISTS folders")
            database.execSQL(
                "CREATE TABLE folders (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, name TEXT NOT NULL, isArchived INTEGER NOT NULL)"
            )
            database.execSQL("INSERT INTO folders SELECT id, name, isArchived FROM folders_migration_backup")
            database.execSQL(
                """
                CREATE TABLE lesson_plans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    folderId INTEGER NOT NULL,
                    title TEXT NOT NULL,
                    content TEXT NOT NULL,
                    isFavorite INTEGER NOT NULL,
                    tags TEXT NOT NULL,
                    timestamp INTEGER NOT NULL,
                    FOREIGN KEY(folderId) REFERENCES folders(id) ON UPDATE NO ACTION ON DELETE CASCADE
                )
                """.trimIndent()
            )
            database.execSQL(
                "INSERT INTO lesson_plans SELECT id, folderId, title, content, isFavorite, tags, timestamp FROM plans_migration_backup"
            )
            database.execSQL("DROP TABLE folders_migration_backup")
            database.execSQL("DROP TABLE plans_migration_backup")
            database.execSQL("CREATE INDEX IF NOT EXISTS index_lesson_plans_folderId ON lesson_plans(folderId)")
        }

        private val MIGRATION_1_4 = object : Migration(1, 4) {
            override fun migrate(database: SupportSQLiteDatabase) = rebuildPreservingData(database)
        }
        private val MIGRATION_2_4 = object : Migration(2, 4) {
            override fun migrate(database: SupportSQLiteDatabase) = rebuildPreservingData(database)
        }
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(database: SupportSQLiteDatabase) = rebuildPreservingData(database)
        }
    }
}
