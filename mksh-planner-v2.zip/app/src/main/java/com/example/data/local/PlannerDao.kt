package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
interface PlannerDao {
    @Insert
    suspend fun insertFolder(folder: FolderEntity): Long

    @Query("SELECT * FROM folders WHERE isArchived = 0 ORDER BY name ASC")
    fun getAllFolders(): Flow<List<FolderEntity>>
    
    @Query("SELECT * FROM folders WHERE isArchived = 1 ORDER BY name ASC")
    fun getArchivedFolders(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders ORDER BY id ASC")
    suspend fun getAllFoldersSnapshot(): List<FolderEntity>

    @Query("SELECT * FROM lesson_plans ORDER BY id ASC")
    suspend fun getAllPlansSnapshot(): List<LessonPlanEntity>
    
    @Query("UPDATE folders SET isArchived = :isArchived WHERE id = :folderId")
    suspend fun updateFolderArchiveStatus(folderId: Long, isArchived: Boolean)

    @Query("SELECT * FROM folders WHERE name = :name LIMIT 1")
    suspend fun getFolderByName(name: String): FolderEntity?

    @Insert
    suspend fun insertLessonPlan(plan: LessonPlanEntity): Long

    @Query("SELECT * FROM lesson_plans WHERE folderId = :folderId ORDER BY timestamp DESC")
    fun getPlansForFolder(folderId: Long): Flow<List<LessonPlanEntity>>

    @Query("SELECT * FROM lesson_plans WHERE id = :planId")
    suspend fun getPlanById(planId: Long): LessonPlanEntity?
    
    @Query("UPDATE lesson_plans SET isFavorite = :isFavorite WHERE id = :planId")
    suspend fun updateFavoriteStatus(planId: Long, isFavorite: Boolean)
    
    @Query("UPDATE lesson_plans SET content = :content WHERE id = :planId")
    suspend fun updatePlanContent(planId: Long, content: String)

    @Query("UPDATE lesson_plans SET title = :title, content = :content WHERE id = :planId")
    suspend fun updatePlan(planId: Long, title: String, content: String)

    @Query("UPDATE lesson_plans SET folderId = :folderId WHERE id = :planId")
    suspend fun movePlan(planId: Long, folderId: Long)
    
    @Query("UPDATE lesson_plans SET tags = :tags WHERE id = :planId")
    suspend fun updatePlanTags(planId: Long, tags: String)
    
    @Query("SELECT * FROM lesson_plans WHERE isFavorite = 1 ORDER BY timestamp DESC")
    fun getFavoritePlans(): Flow<List<LessonPlanEntity>>
    
    @Query("DELETE FROM lesson_plans WHERE id = :planId")
    suspend fun deletePlan(planId: Long)
    
    @Query("DELETE FROM folders WHERE id = :folderId")
    suspend fun deleteFolder(folderId: Long)

    @Query("UPDATE folders SET name = :name WHERE id = :folderId")
    suspend fun renameFolder(folderId: Long, name: String)

    @Query("SELECT * FROM lesson_plans WHERE folderId = :folderId AND title = :title AND timestamp = :timestamp LIMIT 1")
    suspend fun findMatchingPlan(folderId: Long, title: String, timestamp: Long): LessonPlanEntity?
}
