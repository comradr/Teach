package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LessonPlanEntity
import com.example.data.local.PlannerDatabase
import com.example.data.local.PlannerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LessonPlanListViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PlannerRepository
    private val _plans = MutableStateFlow<List<LessonPlanEntity>>(emptyList())
    val plans: StateFlow<List<LessonPlanEntity>> = _plans.asStateFlow()

    init {
        val plannerDao = PlannerDatabase.getDatabase(application).plannerDao()
        repository = PlannerRepository(plannerDao)
    }

    fun loadPlans(folderId: Long) {
        viewModelScope.launch {
            repository.getPlansForFolder(folderId).collect {
                _plans.value = it
            }
        }
    }

    fun loadFavoritePlans() {
        viewModelScope.launch {
            repository.getFavoritePlans().collect {
                _plans.value = it
            }
        }
    }

    fun toggleFavorite(planId: Long, isFavorite: Boolean) {
        viewModelScope.launch {
            repository.updateFavoriteStatus(planId, isFavorite)
        }
    }

    fun deletePlan(planId: Long) {
        viewModelScope.launch {
            repository.deletePlan(planId)
        }
    }
}
