package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.FolderEntity
import com.example.data.local.LessonPlanEntity
import com.example.data.local.PlannerDatabase
import com.example.data.local.PlannerRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PlannerFoldersViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PlannerRepository

    val allFolders: StateFlow<List<FolderEntity>>
    val archivedFolders: StateFlow<List<FolderEntity>>

    init {
        val plannerDao = PlannerDatabase.getDatabase(application).plannerDao()
        repository = PlannerRepository(plannerDao)
        allFolders = repository.allFolders.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
        archivedFolders = repository.archivedFolders.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )
    }

    fun addFolder(name: String, onReady: (Long) -> Unit = {}) = viewModelScope.launch {
        val cleanName = name.trim()
        if (cleanName.isNotEmpty()) {
            val existing = repository.getFolderByName(cleanName)
            val id = existing?.id ?: repository.insertFolder(cleanName)
            onReady(id)
        }
    }

    fun deleteFolder(folderId: Long) = viewModelScope.launch {
        repository.deleteFolder(folderId)
    }
    
    fun archiveFolder(folderId: Long, isArchived: Boolean) = viewModelScope.launch {
        repository.updateFolderArchiveStatus(folderId, isArchived)
    }

    fun renameFolder(folderId: Long, name: String) = viewModelScope.launch {
        val cleanName = name.trim()
        if (cleanName.isNotEmpty() && repository.getFolderByName(cleanName) == null) {
            PlannerDatabase.getDatabase(getApplication()).plannerDao().renameFolder(folderId, cleanName)
        }
    }
}
