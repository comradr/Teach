package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PlannerDatabase
import com.example.data.local.PlannerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.SocketTimeoutException
import java.net.UnknownHostException

sealed class PlannerUiState {
    object Idle : PlannerUiState()
    object Loading : PlannerUiState()
    data class Success(val resultText: String) : PlannerUiState()
    data class Error(val message: String) : PlannerUiState()
    data class Saved(val planId: Long) : PlannerUiState()
}

class LessonPlannerViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PlannerRepository
    private val _uiState = MutableStateFlow<PlannerUiState>(PlannerUiState.Idle)
    val uiState: StateFlow<PlannerUiState> = _uiState.asStateFlow()

    init {
        val plannerDao = PlannerDatabase.getDatabase(application).plannerDao()
        repository = PlannerRepository(plannerDao)
    }

    fun generateLessonPlan(
        classASubject: String,
        classAGrade: String,
        classATopic: String,
        classBSubject: String,
        classBGrade: String,
        classBTopic: String,
        lessonType: String = "Комбинированный",
        images: List<Pair<String, String>> = emptyList(),
        duration: Int = 45,
        additionalInstructions: String = "",
        planMode: String = "Практический",
        maxIndependentMinutesA: Int = 7,
        maxIndependentMinutesB: Int = 7
    ) {
        if (classASubject.isBlank() || classBSubject.isBlank()) {
            _uiState.value = PlannerUiState.Error("Пожалуйста, выберите предметы для обоих классов.")
            return
        }
        if ((classATopic.isBlank() || classBTopic.isBlank()) && images.isEmpty()) {
            _uiState.value = PlannerUiState.Error("Заполните темы для обоих классов или прикрепите фотографии страниц учебника.")
            return
        }
        viewModelScope.launch {
            _uiState.value = PlannerUiState.Loading

            val modeInstructions = if (planMode == "Официальный") {
                """
                РЕЖИМ «ОФИЦИАЛЬНЫЙ ПЛАН»:
                После паспорта обязательно добавь разделы «# 🎯 Цель и задачи», «# ✅ Планируемые результаты» и «# 📚 Образовательные технологии». Формулировки должны быть конкретными, проверяемыми и связанными с фактическими заданиями урока. Укажи образовательные, развивающие и воспитательные задачи, а также предметные, метапредметные и личностные результаты. Не добавляй пустую бюрократию.
                """.trimIndent()
            } else {
                """
                РЕЖИМ «ПРАКТИЧЕСКИЙ ПЛАН ДЛЯ СЕБЯ»:
                Не пиши УУД, формальные цели, задачи и планируемые результаты. Оставь только информацию, которая помогает непосредственно провести урок.
                """.trimIndent()
            }

            val systemPrompt = """
                Ты — ведущий эксперт-методист начального образования с профильным опытом работы в малокомплектных школах (МКШ). Твоя задача — создавать ИДЕАЛЬНЫЕ, ВЫСОКОКАЧЕСТВЕННЫЕ планы уроков для совмещенных классов. Планы должны быть максимально подробными, креативными и готовыми к использованию.
                (Опционально) Тебе могут быть переданы фото учебников. Если темы не указаны явно, определи их по фото и составь план на основе материала.
                
                $modeInstructions

                ОБЩИЕ ОГРАНИЧЕНИЯ:
                - НЕ ПИШИ НИКАКОЙ ВОДЫ, бюрократии и сухой теории.
                - Все формулировки должны быть пригодны для реального урока.
                
                ОСНОВНЫЕ ПРАВИЛА:
                1. Принцип «Качелей»: Пока один класс работает под руководством учителя (изучение нового, устный опрос), второй класс работает полностью самостоятельно (карточки, тесты, чтение, творческое задание). Затем классы меняются.
                2. Внимание учителя не может разрываться. В любую минуту урока учитель активно взаимодействует только с одним классом, либо дает общую инструкцию/физкультминутку для обоих.
                3. Урок длится ровно ${duration} минут.
                4. Класс А может работать без обращения к учителю не более ${maxIndependentMinutesA} минут подряд.
                5. Класс Б может работать без обращения к учителю не более ${maxIndependentMinutesB} минут подряд.
                6. Перед выдачей ответа внутренне проверь: интервалы идут непрерывно от 0 до ${duration}, сумма равна ${duration}, учитель нигде не ведёт разные объяснения двум классам одновременно.
                
                ФОРМАТ ОТВЕТА (выдавай ответ строго по этой структуре в формате Markdown):
                
                # 📌 Паспорт урока
                *   **Предметы/Классы:** [Например: Математика (2 класс) и Окружающий мир (3 класс)]
                *   **Тема для Класса А:** [...]
                *   **Тема для Класса Б:** [...]
                *   **Длительность:** ${duration} минут
                *   **Оборудование:** Подробный список, что нужно подготовить учителю (раздаточный материал, презентации и т.д.).
                
                # ⏱ Поминутный тайминг (${duration} минут)
                Создай таблицу со столбцами: Время | Этап урока | Деятельность [Класс А] | Деятельность [Класс Б] | Фокус внимания учителя.
                Распредели все ${duration} минут без пробелов. Чередуй самостоятельную работу и работу с учителем. 
                ОБЯЗАТЕЛЬНО выдели 2-3 минуты на общую «Физкультминутку» в середине урока. Тайминг должен быть логичным и выполнимым.
                
                # 🤸 Физкультминутка
                Опиши конкретное, интересное упражнение для проведения физкультминутки, которое объединит оба класса (стишок, разминка для глаз и т.д.).
                
                # 💡 Методические рекомендации
                Дай 2-3 практических совета учителю по проведению этого конкретного урока (например, как организовать переход между этапами, на что обратить внимание, как увлечь детей, как дифференцировать задания).
                
                # 📝 Материалы для самостоятельной работы
                Для каждого этапа самостоятельной работы напиши КОНКРЕТНЫЕ тексты заданий, карточек или примеров. НЕ ПИШИ "дайте задание из учебника". Придумай само задание, чтобы учитель мог просто распечатать этот план.

                # 🖨 Готовые карточки для печати
                Подготовь минимум одну полностью готовую карточку для каждого класса. Каждая начинается заголовком строго второго уровня: «## Карточка — Класс А» или «## Карточка — Класс Б». Внутри должны быть имя ученика, понятная инструкция и все задания без ссылок на отсутствующие материалы. После ученических карточек добавь «## Ответы учителю» с нумерованными ответами. Ответы не смешивай с карточками учеников.
                
                # 🎨 Иллюстрации к карточкам
                Для визуализации заданий добавляй изображения, генерируя их через нейросеть (nanobanana/pollinations)!
                Вставляй картинки прямо в текст с помощью Markdown:
                ![описание](https://image.pollinations.ai/prompt/Твой%20детальный%20промпт%20на%20английском%20языке%20в%20стиле%20детской%20иллюстрации?width=800&height=600&nologo=true)
                ВАЖНО: Промпт в ссылке ДОЛЖЕН быть на английском языке, а пробелы заменены на %20.
            """.trimIndent()
            
            val userPrompt = """
                Сгенерируй план урока ($lessonType) для следующих классов:
                
                Класс А:
                Предмет: $classASubject
                Класс: $classAGrade
                Тема: $classATopic
                Максимум самостоятельной работы подряд: $maxIndependentMinutesA минут
                
                Класс Б:
                Предмет: $classBSubject
                Класс: $classBGrade
                Тема: $classBTopic
                Максимум самостоятельной работы подряд: $maxIndependentMinutesB минут

                Режим документа: $planMode
                
                Дополнительные пожелания от учителя:
                ${if (additionalInstructions.isNotBlank()) additionalInstructions else "Нет"}
            """.trimIndent()
            
            val parts = mutableListOf<Part>(Part(text = userPrompt))
            images.forEach { (mimeType, base64Image) ->
                parts.add(Part(inlineData = InlineData(mimeType = mimeType, data = base64Image)))
            }

            val request = GenerateContentRequest(
                contents = listOf(Content(parts = parts)),
                systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
            )

            val apiKey = BuildConfig.GEMINI_API_KEY
            if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
                _uiState.value = PlannerUiState.Error("Ключ Gemini не настроен. Добавьте GEMINI_API_KEY в файл .env.")
                return@launch
            }

            try {
                val apiResponse = RetrofitClient.service.generateContent(apiKey, request)
                val response = apiResponse.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text ?: "Error: Нет ответа от модели."
                
                if (response.startsWith("Error:")) {
                    _uiState.value = PlannerUiState.Error(response)
                } else {
                    _uiState.value = PlannerUiState.Success(response)
                }
            } catch (e: retrofit2.HttpException) {
                _uiState.value = PlannerUiState.Error(httpErrorMessage(e.code()))
            } catch (e: UnknownHostException) {
                _uiState.value = PlannerUiState.Error("Нет подключения к интернету. Введённые данные сохранены — подключитесь к сети и повторите.")
            } catch (e: SocketTimeoutException) {
                _uiState.value = PlannerUiState.Error("Сервис отвечает слишком долго. Попробуйте ещё раз — введённые данные не потеряны.")
            } catch (e: Exception) {
                _uiState.value = PlannerUiState.Error("Не удалось создать план. Попробуйте ещё раз. ${e.localizedMessage.orEmpty()}")
            }
        }
    }

    fun updateGeneratedPlan(newText: String) {
        if (_uiState.value is PlannerUiState.Success) {
            _uiState.value = PlannerUiState.Success(newText)
        }
    }

    fun restoreGeneratedPlan(text: String) {
        if (text.isNotBlank() && _uiState.value is PlannerUiState.Idle) {
            _uiState.value = PlannerUiState.Success(text)
        }
    }

    fun saveLessonPlan(folderId: Long, title: String, content: String, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val id = repository.insertLessonPlan(folderId, title, content)
            _uiState.value = PlannerUiState.Saved(id)
            onSaved(id)
        }
    }

    fun resetState() {
        _uiState.value = PlannerUiState.Idle
    }

    private fun httpErrorMessage(code: Int): String = when (code) {
        400 -> "Сервис не смог обработать запрос. Уменьшите число фотографий или проверьте заполненные поля."
        401, 403 -> "Ключ Gemini отклонён. Проверьте GEMINI_API_KEY и доступ к выбранной модели."
        429 -> "Лимит запросов Gemini временно исчерпан. Подождите немного и повторите."
        in 500..599 -> "Сервис Gemini временно недоступен. Попробуйте ещё раз позже."
        else -> "Ошибка сервиса Gemini (код $code). Попробуйте повторить запрос."
    }
}
