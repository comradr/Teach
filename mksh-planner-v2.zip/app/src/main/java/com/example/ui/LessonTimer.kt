package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop

@Composable
fun LessonTimer(initialMinutes: Int = 45, modifier: Modifier = Modifier) {
    val totalSeconds = initialMinutes.coerceIn(1, 240) * 60
    var isRunning by rememberSaveable(initialMinutes) { mutableStateOf(false) }
    var timeLeft by rememberSaveable(initialMinutes) { mutableIntStateOf(totalSeconds) }
    var finishAtMillis by rememberSaveable(initialMinutes) { mutableLongStateOf(0L) }
    
    LaunchedEffect(isRunning) {
        while (isRunning && timeLeft > 0) {
            timeLeft = ((finishAtMillis - System.currentTimeMillis() + 999L) / 1000L)
                .coerceAtLeast(0L)
                .toInt()
            if (timeLeft > 0) delay(250L)
        }
        if (timeLeft == 0) {
            isRunning = false
        }
    }
    
    val minutes = timeLeft / 60
    val seconds = timeLeft % 60
    val progress = 1f - (timeLeft.toFloat() / totalSeconds)
    
    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Таймер урока", 
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = String.format("%02d:%02d", minutes, seconds),
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                val animatedProgress by androidx.compose.animation.core.animateFloatAsState(
                    targetValue = progress,
                    animationSpec = androidx.compose.animation.core.tween(durationMillis = 1000, easing = androidx.compose.animation.core.LinearEasing)
                )
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f)
                )
            }
            
            Spacer(modifier = Modifier.width(16.dp))
            
            IconButton(
                onClick = { 
                    if (timeLeft == 0) timeLeft = totalSeconds
                    if (isRunning) {
                        isRunning = false
                    } else {
                        finishAtMillis = System.currentTimeMillis() + timeLeft * 1000L
                        isRunning = true
                    }
                },
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = if (isRunning) "Остановить" else "Старт",
                    modifier = Modifier.size(32.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}
