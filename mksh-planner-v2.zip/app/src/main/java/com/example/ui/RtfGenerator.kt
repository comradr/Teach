package com.example.ui

import android.content.Context
import android.net.Uri
import com.example.data.local.LessonPlanEntity

object RtfGenerator {
    fun generate(context: Context, uri: Uri, plan: LessonPlanEntity): String? = try {
        val body = buildString {
            append("{\\rtf1\\ansi\\ansicpg1251\\deff0")
            append("{\\fonttbl{\\f0 Arial;}}\\viewkind4\\uc1\\f0\\fs24 ")
            append("\\qc\\b\\fs36 ").append(escape(plan.title)).append("\\b0\\fs24\\par\\par\\ql ")
            plan.content.lineSequence().forEach { rawLine ->
                val line = rawLine.trimEnd()
                when {
                    line.startsWith("# ") -> append("\\par\\b\\fs32 ").append(escape(line.drop(2))).append("\\b0\\fs24\\par ")
                    line.startsWith("## ") -> append("\\par\\b\\fs28 ").append(escape(line.drop(3))).append("\\b0\\fs24\\par ")
                    line.startsWith("### ") -> append("\\par\\b\\fs26 ").append(escape(line.drop(4))).append("\\b0\\fs24\\par ")
                    line.matches(Regex("\\s*\\|?(?:\\s*:?-+:?\\s*\\|)+\\s*")) -> Unit
                    line.contains('|') -> append(escape(line.trim('|').split('|').joinToString("\\tab") { it.trim() })).append("\\par ")
                    line.startsWith("- ") || line.startsWith("* ") -> append("\\bullet\\tab ").append(escape(stripMarkdown(line.drop(2)))).append("\\par ")
                    line.isBlank() -> append("\\par ")
                    else -> append(escape(stripMarkdown(line))).append("\\par ")
                }
            }
            append('}')
        }
        context.contentResolver.openOutputStream(uri)?.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            ?: return "Не удалось открыть файл для записи"
        null
    } catch (e: Exception) {
        e.localizedMessage ?: "Неизвестная ошибка"
    }

    private fun stripMarkdown(value: String): String = value
        .replace(Regex("!\\[([^]]*)]\\([^)]*\\)"), "$1")
        .replace("**", "")
        .replace("__", "")
        .replace("`", "")

    private fun escape(value: String): String = buildString {
        value.forEach { char ->
            when (char) {
                '\\' -> append("\\\\")
                '{' -> append("\\{")
                '}' -> append("\\}")
                '\t' -> append("\\tab ")
                else -> if (char.code in 32..126) {
                    append(char)
                } else {
                    append("\\u").append(char.code.toShort().toInt()).append('?')
                }
            }
        }
    }
}
