package com.example.ui

import android.content.Context
import android.net.Uri
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.element.Cell
import com.itextpdf.layout.element.AreaBreak
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.io.font.PdfEncodings
import com.itextpdf.layout.properties.TextAlignment
import com.itextpdf.layout.properties.AreaBreakType
import com.itextpdf.layout.properties.UnitValue
import com.example.data.local.LessonPlanEntity
import java.io.File

object PdfGenerator {
    fun generateGostPdf(context: Context, uri: Uri, plan: LessonPlanEntity): String? {
        try {
            val outputStream = context.contentResolver.openOutputStream(uri) ?: return "Failed to open output stream"
            val writer = PdfWriter(outputStream)
            val pdf = PdfDocument(writer)
            val document = Document(pdf)

            // Try to use a system font that supports Cyrillic
            val fontFile = File("/system/fonts/Roboto-Regular.ttf")
            val font = if (fontFile.exists()) {
                PdfFontFactory.createFont(fontFile.absolutePath, PdfEncodings.IDENTITY_H)
            } else {
                // Fallback (might not render Cyrillic correctly)
                PdfFontFactory.createFont()
            }

            // Title Page
            document.add(Paragraph("Министерство просвещения Российской Федерации\n\n\n\n\n\n")
                .setFont(font)
                .setFontSize(14f)
                .setTextAlignment(TextAlignment.CENTER))
                
            document.add(Paragraph("ПЛАН-КОНСПЕКТ УРОКА\n\n")
                .setFont(font)
                .setFontSize(24f)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER))
                
            document.add(Paragraph(plan.title)
                .setFont(font)
                .setFontSize(18f)
                .setTextAlignment(TextAlignment.CENTER))

            document.add(AreaBreak(AreaBreakType.NEXT_PAGE))
                
            // Add content
            // Simple markdown parsing for PDF
            val lines = plan.content.lines()
            var index = 0
            while (index < lines.size) {
                val line = lines[index]
                if (line.trim().startsWith("|") && index + 1 < lines.size && isTableSeparator(lines[index + 1])) {
                    val rows = mutableListOf<List<String>>()
                    rows += parseTableRow(line)
                    index += 2
                    while (index < lines.size && lines[index].trim().startsWith("|")) {
                        rows += parseTableRow(lines[index])
                        index++
                    }
                    val columnCount = rows.maxOfOrNull { it.size } ?: 1
                    val table = Table(UnitValue.createPercentArray(columnCount)).useAllAvailableWidth()
                    rows.forEachIndexed { rowIndex, row ->
                        repeat(columnCount) { columnIndex ->
                            val text = row.getOrNull(columnIndex).orEmpty().replace("**", "")
                            val paragraph = Paragraph(text).setFont(font).setFontSize(9f)
                            if (rowIndex == 0) paragraph.setBold()
                            table.addCell(Cell().add(paragraph))
                        }
                    }
                    document.add(table.setMarginTop(6f).setMarginBottom(8f))
                    continue
                }
                if (line.startsWith("# ")) {
                    document.add(Paragraph(line.removePrefix("# "))
                        .setFont(font).setFontSize(16f).setBold().setMarginTop(10f))
                } else if (line.startsWith("## ")) {
                    document.add(Paragraph(line.removePrefix("## "))
                        .setFont(font).setFontSize(14f).setBold().setMarginTop(8f))
                } else if (line.startsWith("### ")) {
                    document.add(Paragraph(line.removePrefix("### "))
                        .setFont(font).setFontSize(12f).setBold().setMarginTop(6f))
                } else if (line.startsWith("- ") || line.startsWith("* ")) {
                    document.add(Paragraph("• " + line.drop(2))
                        .setFont(font).setFontSize(12f).setMarginLeft(15f))
                } else if (line.isNotBlank()) {
                    // Remove basic markdown bold for plain text representation
                    val cleanText = line.replace("**", "")
                    document.add(Paragraph(cleanText)
                        .setFont(font).setFontSize(12f))
                }
                index++
            }

            document.close()
            return null // Success
        } catch (e: Exception) {
            e.printStackTrace()
            return e.localizedMessage
        }
    }

    private fun isTableSeparator(line: String): Boolean =
        line.trim().trim('|').split('|').all { it.trim().matches(Regex(":?-{3,}:?")) }

    private fun parseTableRow(line: String): List<String> =
        line.trim().trim('|').split('|').map { it.trim() }
}
