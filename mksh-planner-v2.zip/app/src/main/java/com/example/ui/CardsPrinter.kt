package com.example.ui

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.text.TextUtils
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.local.LessonPlanEntity

object CardsPrinter {
    fun print(context: Context, plan: LessonPlanEntity): Boolean {
        val section = extractSection(plan.content, "Готовые карточки для печати")
            ?: extractSection(plan.content, "Материалы для самостоятельной работы")
            ?: return false
        val parsed = parseCards(section)
        if (parsed.cards.isEmpty()) return false

        val cardsHtml = parsed.cards.joinToString("") { (title, body) ->
            "<section class=\"card\"><h2>${TextUtils.htmlEncode(title)}</h2>${markdownToHtml(body)}</section>"
        }
        val answersHtml = if (parsed.answers.isBlank()) "" else {
            "<section class=\"answers\"><h1>Ответы учителю</h1>${markdownToHtml(parsed.answers)}</section>"
        }
        val html = """
            <html><head><meta charset="utf-8"><style>
            @page { size: A4; margin: 12mm; }
            body { font-family: sans-serif; color: #111; font-size: 15px; }
            h1 { text-align: center; }
            h2 { margin: 0 0 12px; font-size: 20px; }
            .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10mm; }
            .card { border: 2px dashed #555; padding: 8mm; min-height: 95mm; page-break-inside: avoid; box-sizing: border-box; }
            .answers { page-break-before: always; border: 1px solid #777; padding: 8mm; }
            img { max-width: 100%; max-height: 70mm; object-fit: contain; }
            </style></head><body>
            <h1>Карточки к уроку</h1><div class="grid">$cardsHtml</div>$answersHtml
            </body></html>
        """.trimIndent()

        val webView = WebView(context)
        webView.settings.javaScriptEnabled = false
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                val manager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                manager.print(
                    "Карточки — ${plan.title}",
                    view.createPrintDocumentAdapter("Карточки — ${plan.title}"),
                    PrintAttributes.Builder().build()
                )
            }
        }
        webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
        return true
    }

    private data class ParsedCards(
        val cards: List<Pair<String, String>>,
        val answers: String
    )

    private fun parseCards(section: String): ParsedCards {
        val cards = mutableListOf<Pair<String, String>>()
        var title = ""
        val body = StringBuilder()
        val answers = StringBuilder()
        var answerMode = false

        fun flushCard() {
            if (title.isNotBlank() && body.isNotBlank()) cards += title to body.toString().trim()
            body.clear()
        }

        section.lines().forEach { line ->
            if (line.startsWith("## ")) {
                val heading = line.removePrefix("## ").trim()
                if (heading.contains("ответ", ignoreCase = true)) {
                    flushCard()
                    answerMode = true
                } else {
                    flushCard()
                    title = heading
                    answerMode = false
                }
            } else if (answerMode) {
                answers.appendLine(line)
            } else if (title.isNotBlank()) {
                body.appendLine(line)
            }
        }
        flushCard()
        if (cards.isEmpty() && section.isNotBlank()) cards += "Карточка ученика" to section.trim()
        return ParsedCards(cards, answers.toString().trim())
    }

    private fun extractSection(markdown: String, titlePart: String): String? {
        val lines = markdown.lines()
        val start = lines.indexOfFirst { it.startsWith("# ") && it.contains(titlePart, ignoreCase = true) }
        if (start < 0) return null
        val end = (start + 1 until lines.size).firstOrNull { lines[it].startsWith("# ") } ?: lines.size
        return lines.subList(start + 1, end).joinToString("\n").trim()
    }

    private fun markdownToHtml(markdown: String): String {
        var html = TextUtils.htmlEncode(markdown)
        html = html.replace(Regex("!\\[(.*?)]\\((.*?)\\)"), "<img src=\"$2\" alt=\"$1\">")
        html = html.replace(Regex("\\*\\*(.*?)\\*\\*"), "<b>$1</b>")
        html = html.replace(Regex("(?m)^[-*] (.+)$"), "• $1")
        return html.replace("\n", "<br>")
    }
}
