package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Slideshow
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LibraryBooks
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.FolderEntity
import com.example.data.local.LessonPlanEntity
import com.example.ui.FavoritesScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        com.example.data.remote.FirebaseSyncManager.initialize()
        setContent {
            MyApplicationTheme(darkTheme = androidx.compose.foundation.isSystemInDarkTheme()) {
                val navController = rememberNavController()
                val backStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = backStackEntry?.destination?.route
                val showBottomBar = currentRoute in setOf("generator", "folders", "favorites")
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        if (showBottomBar) NavigationBar {
                            NavigationBarItem(
                                selected = currentRoute == "generator",
                                onClick = {
                                    if (!navController.popBackStack("generator", inclusive = false)) {
                                        navController.navigate("generator") { launchSingleTop = true }
                                    }
                                },
                                icon = { Icon(Icons.Default.Add, contentDescription = "Генератор") },
                                label = { Text("Создать") }
                            )
                            NavigationBarItem(
                                selected = currentRoute == "folders",
                                onClick = { navController.navigate("folders") { popUpTo("generator"); launchSingleTop = true } },
                                icon = { Icon(Icons.Default.Folder, contentDescription = "Папки") },
                                label = { Text("Папки") }
                            )
                            NavigationBarItem(
                                selected = currentRoute == "favorites",
                                onClick = { navController.navigate("favorites") { popUpTo("generator"); launchSingleTop = true } },
                                icon = { Icon(Icons.Default.Favorite, contentDescription = "Избранное") },
                                label = { Text("Избранное") }
                            )
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "generator",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("generator") {
                            LessonPlannerScreen(navController = navController)
                        }
                        composable("folders") {
                            FoldersScreen(navController = navController)
                        }
                        composable("favorites") {
                            FavoritesScreen(navController = navController)
                        }
                        composable("folder_plans/{folderId}") { backStackEntry ->
                            val folderId = backStackEntry.arguments?.getString("folderId")?.toLongOrNull() ?: 0L
                            LessonPlansScreen(folderId = folderId, navController = navController)
                        }
                        composable("plan_detail/{planId}") { backStackEntry ->
                            val planId = backStackEntry.arguments?.getString("planId")?.toLongOrNull() ?: 0L
                            PlanDetailScreen(planId = planId, navController = navController)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonPlannerScreen(
    modifier: Modifier = Modifier,
    viewModel: LessonPlannerViewModel = viewModel(),
    foldersViewModel: PlannerFoldersViewModel = viewModel(),
    navController: NavHostController
) {
    val context = LocalContext.current
    val restoredDraft = remember { com.example.data.local.LessonDraftStore.load(context) }
    val restoredDraftImages = remember { com.example.data.local.LessonDraftImageStore.load(context) }
    var classASubject by rememberSaveable { mutableStateOf(restoredDraft.classASubject) }
    var classAGrade by rememberSaveable { mutableStateOf(restoredDraft.classAGrade) }
    var classATopic by rememberSaveable { mutableStateOf(restoredDraft.classATopic) }

    var classBSubject by rememberSaveable { mutableStateOf(restoredDraft.classBSubject) }
    var classBGrade by rememberSaveable { mutableStateOf(restoredDraft.classBGrade) }
    var classBTopic by rememberSaveable { mutableStateOf(restoredDraft.classBTopic) }
    
    var showSaveDialog by remember { mutableStateOf(false) }
    var selectedFolderId by remember { mutableStateOf<Long?>(null) }
    var planTitle by rememberSaveable { mutableStateOf(restoredDraft.planTitle) }
    var saveFolderName by rememberSaveable { mutableStateOf("Мои планы") }
    var isError by remember { mutableStateOf(false) }
    val folders by foldersViewModel.allFolders.collectAsState()
    
    var expandedASubject by remember { mutableStateOf(false) }
    var expandedAGrade by remember { mutableStateOf(false) }
    var expandedBSubject by remember { mutableStateOf(false) }
    var expandedBGrade by remember { mutableStateOf(false) }
    var expandedLessonType by remember { mutableStateOf(false) }
    var lessonType by rememberSaveable { mutableStateOf(restoredDraft.lessonType) }
    var lessonDuration by rememberSaveable { mutableStateOf(restoredDraft.lessonDuration) }
    var additionalInstructions by rememberSaveable { mutableStateOf(restoredDraft.additionalInstructions) }
    var planMode by rememberSaveable { mutableStateOf(restoredDraft.planMode) }
    var independentMinutesA by rememberSaveable { mutableIntStateOf(restoredDraft.independentMinutesA) }
    var independentMinutesB by rememberSaveable { mutableIntStateOf(restoredDraft.independentMinutesB) }

    val subjects = listOf("Математика", "Русский язык", "Литературное чтение", "Окружающий мир", "Изобразительное искусство", "Технология", "Музыка", "Физкультура")
    var attachedImages by remember { mutableStateOf(restoredDraftImages) }

    val imagePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris: List<android.net.Uri> ->
        val freeSlots = (6 - attachedImages.size).coerceAtLeast(0)
        for (uri in uris.take(freeSlots)) {
            try {                                
                val options = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                context.contentResolver.openInputStream(uri)?.use { stream -> 
                    android.graphics.BitmapFactory.decodeStream(stream, null, options) 
                }
                val maxDim = 1024
                var scale = 1
                while (options.outWidth / scale > maxDim || options.outHeight / scale > maxDim) {
                    scale *= 2
                }
                val decodeOptions = android.graphics.BitmapFactory.Options().apply { inSampleSize = scale }
                val bitmap = context.contentResolver.openInputStream(uri)?.use { stream -> 
                    android.graphics.BitmapFactory.decodeStream(stream, null, decodeOptions)
                } ?: throw Exception("Failed to decode image")
                val outputStream = java.io.ByteArrayOutputStream()
                bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, outputStream)
                val b64 = android.util.Base64.encodeToString(outputStream.toByteArray(), android.util.Base64.NO_WRAP)
                val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
                attachedImages = attachedImages + Pair(mime, b64)
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "Ошибка загрузки фото", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    val takePictureLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.TakePicturePreview()
    ) { bitmap: android.graphics.Bitmap? ->
        bitmap?.let {
            val outputStream = java.io.ByteArrayOutputStream()
            it.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, outputStream)
            val b64 = android.util.Base64.encodeToString(outputStream.toByteArray(), android.util.Base64.NO_WRAP)
            val mime = "image/jpeg"
            attachedImages = attachedImages + Pair(mime, b64)
        }
    }

    var currentSpeechField by remember { mutableStateOf(0) }
    val speechRecognizerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val data = result.data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
            val text = data?.get(0)
            if (text != null) {
                if (currentSpeechField == 1) classATopic = text
                else if (currentSpeechField == 2) classBTopic = text
            }
        }
    }
    val grades = listOf("1 класс", "2 класс", "3 класс", "4 класс")
    val lessonTypes = listOf("Комбинированный", "Изучение нового материала", "Урок закрепления", "Урок обобщения", "Контрольный урок")

    val uiState by viewModel.uiState.collectAsState()
    val generatedDraftText = (uiState as? PlannerUiState.Success)?.resultText.orEmpty()
    
    var isEditingPlan by remember { mutableStateOf(false) }
    var editingPlanContent by remember { mutableStateOf("") }

    LaunchedEffect(
        classASubject, classAGrade, classATopic,
        classBSubject, classBGrade, classBTopic,
        lessonType, lessonDuration, additionalInstructions,
        planTitle, planMode, independentMinutesA, independentMinutesB, generatedDraftText
    ) {
        kotlinx.coroutines.delay(500)
        com.example.data.local.LessonDraftStore.save(
            context,
            com.example.data.local.LessonDraft(
                classASubject = classASubject,
                classAGrade = classAGrade,
                classATopic = classATopic,
                classBSubject = classBSubject,
                classBGrade = classBGrade,
                classBTopic = classBTopic,
                lessonType = lessonType,
                lessonDuration = lessonDuration,
                additionalInstructions = additionalInstructions,
                planTitle = planTitle,
                generatedPlan = generatedDraftText,
                planMode = planMode,
                independentMinutesA = independentMinutesA,
                independentMinutesB = independentMinutesB
            )
        )
    }

    LaunchedEffect(Unit) {
        viewModel.restoreGeneratedPlan(restoredDraft.generatedPlan)
    }

    LaunchedEffect(attachedImages) {
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            com.example.data.local.LessonDraftImageStore.save(context, attachedImages)
        }
    }

    if (showSaveDialog && uiState is PlannerUiState.Success) {
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Сохранить план") },
            text = {
                Column {
                    OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                        value = planTitle,
                        onValueChange = { planTitle = it },
                        label = { Text("Название плана") }
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Выберите папку:")
                    if (folders.isEmpty()) {
                        Text("Сначала создайте папку:")
                        OutlinedTextField(
                            value = saveFolderName,
                            onValueChange = { saveFolderName = it },
                            label = { Text("Название папки") },
                            singleLine = true
                        )
                        TextButton(
                            enabled = saveFolderName.isNotBlank(),
                            onClick = { foldersViewModel.addFolder(saveFolderName) { selectedFolderId = it } }
                        ) { Text("Создать папку") }
                    } else {
                        LazyColumn {
                            items(folders) { folder ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedFolderId = folder.id }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selectedFolderId == folder.id,
                                        onClick = { selectedFolderId = folder.id }
                                    )
                                    Text(folder.name)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val folderId = selectedFolderId
                        if (folderId != null && planTitle.isNotBlank()) {
                            viewModel.saveLessonPlan(
                                folderId = folderId,
                                title = planTitle,
                                content = (uiState as PlannerUiState.Success).resultText
                            ) {
                                showSaveDialog = false
                                com.example.data.local.LessonDraftStore.clear(context)
                                com.example.data.local.LessonDraftImageStore.clear(context)
                                viewModel.resetState()
                                classASubject = ""
                                classAGrade = ""
                                classATopic = ""
                                classBSubject = ""
                                classBGrade = ""
                                classBTopic = ""
                                additionalInstructions = ""
                                attachedImages = emptyList()
                                planTitle = ""
                                selectedFolderId = null
                                navController.navigate("folders")
                            }
                        }
                    },
                    enabled = selectedFolderId != null && planTitle.isNotBlank()
                ) {
                    Text("Сохранить")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "МКШ Планировщик",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            TextButton(onClick = {
                com.example.data.local.LessonDraftStore.clear(context)
                com.example.data.local.LessonDraftImageStore.clear(context)
                viewModel.resetState()
                classASubject = ""
                classAGrade = ""
                classATopic = ""
                classBSubject = ""
                classBGrade = ""
                classBTopic = ""
                additionalInstructions = ""
                planTitle = ""
                attachedImages = emptyList()
                lessonType = "Комбинированный"
                lessonDuration = "45"
                planMode = "Практический"
                independentMinutesA = 7
                independentMinutesB = 7
            }) { Text("Очистить") }
        }

        Text(
            "Черновик сохраняется автоматически",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        HorizontalDivider()

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Общие настройки", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Режим документа", style = MaterialTheme.typography.labelLarge)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = planMode == "Практический",
                        onClick = { planMode = "Практический" },
                        label = { Text("Для себя") },
                        leadingIcon = if (planMode == "Практический") {{ Icon(Icons.Default.Check, contentDescription = null) }} else null
                    )
                    FilterChip(
                        selected = planMode == "Официальный",
                        onClick = { planMode = "Официальный" },
                        label = { Text("Официальный") },
                        leadingIcon = if (planMode == "Официальный") {{ Icon(Icons.Default.Check, contentDescription = null) }} else null
                    )
                }
                Text(
                    if (planMode == "Практический") "Короткий рабочий план без формальной части"
                    else "С целями, задачами и планируемыми результатами",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                ExposedDropdownMenuBox(
                    expanded = expandedLessonType,
                    onExpandedChange = { expandedLessonType = !expandedLessonType }
                ) {
                    OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                        value = lessonType,
                        onValueChange = { lessonType = it },
                        label = { Text("Тип урока") },
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedLessonType) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedLessonType,
                        onDismissRequest = { expandedLessonType = false }
                    ) {
                        lessonTypes.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { lessonType = selectionOption; expandedLessonType = false })
                        }
                    }
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Класс А", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                ExposedDropdownMenuBox(
                    expanded = expandedASubject,
                    onExpandedChange = { expandedASubject = !expandedASubject }
                ) {
                    OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                        value = classASubject, 
                        onValueChange = { classASubject = it; isError = false }, 
                        label = { Text("Предмет") }, 
                        isError = isError && classASubject.isBlank(), 
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedASubject) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedASubject,
                        onDismissRequest = { expandedASubject = false }
                    ) {
                        subjects.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classASubject = selectionOption; expandedASubject = false; isError = false })
                        }
                    }
                }
                ExposedDropdownMenuBox(
                    expanded = expandedAGrade,
                    onExpandedChange = { expandedAGrade = !expandedAGrade }
                ) {
                    OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                        value = classAGrade, 
                        onValueChange = { classAGrade = it; isError = false }, 
                        label = { Text("Класс") }, 
                        isError = isError && classAGrade.isBlank(), 
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedAGrade) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedAGrade,
                        onDismissRequest = { expandedAGrade = false }
                    ) {
                        grades.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classAGrade = selectionOption; expandedAGrade = false; isError = false })
                        }
                    }
                }
                OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                    value = classATopic, 
                    onValueChange = { classATopic = it; isError = false }, 
                    label = { Text("Тема урока") }, 
                    isError = isError && classATopic.isBlank(), 
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { 
                            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            }
                            currentSpeechField = 1
                            try {
                                speechRecognizerLauncher.launch(intent)
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Голосовой ввод недоступен", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Default.Mic, contentDescription = "Голосовой ввод")
                        }
                    }
                )
                IndependenceSelector(
                    value = independentMinutesA,
                    onValueChange = { independentMinutesA = it },
                    label = "Самостоятельность класса А"
                )
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Класс Б", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                ExposedDropdownMenuBox(
                    expanded = expandedBSubject,
                    onExpandedChange = { expandedBSubject = !expandedBSubject }
                ) {
                    OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                        value = classBSubject, 
                        onValueChange = { classBSubject = it; isError = false }, 
                        label = { Text("Предмет") }, 
                        isError = isError && classBSubject.isBlank(), 
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedBSubject) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedBSubject,
                        onDismissRequest = { expandedBSubject = false }
                    ) {
                        subjects.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classBSubject = selectionOption; expandedBSubject = false; isError = false })
                        }
                    }
                }
                ExposedDropdownMenuBox(
                    expanded = expandedBGrade,
                    onExpandedChange = { expandedBGrade = !expandedBGrade }
                ) {
                    OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                        value = classBGrade, 
                        onValueChange = { classBGrade = it; isError = false }, 
                        label = { Text("Класс") }, 
                        isError = isError && classBGrade.isBlank(), 
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedBGrade) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedBGrade,
                        onDismissRequest = { expandedBGrade = false }
                    ) {
                        grades.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classBGrade = selectionOption; expandedBGrade = false; isError = false })
                        }
                    }
                }
                OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                    value = classBTopic, 
                    onValueChange = { classBTopic = it; isError = false }, 
                    label = { Text("Тема урока") }, 
                    isError = isError && classBTopic.isBlank(), 
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { 
                            val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            }
                            currentSpeechField = 2
                            try {
                                speechRecognizerLauncher.launch(intent)
                            } catch (e: Exception) {
                                android.widget.Toast.makeText(context, "Голосовой ввод недоступен", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Default.Mic, contentDescription = "Голосовой ввод")
                        }
                    }
                )
                IndependenceSelector(
                    value = independentMinutesB,
                    onValueChange = { independentMinutesB = it },
                    label = "Самостоятельность класса Б"
                )
            }
        }

        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            var expandedDuration by remember { mutableStateOf(false) }
            val durations = listOf("30", "40", "45", "60", "90")
            
            ExposedDropdownMenuBox(
                expanded = expandedDuration,
                onExpandedChange = { expandedDuration = !expandedDuration },
                modifier = Modifier.weight(1f)
            ) {
                OutlinedTextField(
                    shape = RoundedCornerShape(12.dp),
                    value = lessonDuration + " мин",
                    onValueChange = {},
                    label = { Text("Длительность") },
                    readOnly = true,
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedDuration) },
                    modifier = Modifier.menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                    colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                )
                ExposedDropdownMenu(
                    expanded = expandedDuration,
                    onDismissRequest = { expandedDuration = false }
                ) {
                    durations.forEach { duration ->
                        DropdownMenuItem(
                            text = { Text("$duration минут") },
                            onClick = { lessonDuration = duration; expandedDuration = false }
                        )
                    }
                }
            }
        }
        
        OutlinedTextField(
            shape = RoundedCornerShape(12.dp),
            value = additionalInstructions,
            onValueChange = { additionalInstructions = it },
            label = { Text("Дополнительные пожелания (опционально)") },
            placeholder = { Text("Например: добавить работу в парах, больше игровой формы...") },
            modifier = Modifier.fillMaxWidth(),
            minLines = 2
        )
        
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { imagePickerLauncher.launch("image/*") },
                enabled = attachedImages.size < 6,
                modifier = Modifier.weight(1f).height(56.dp)
            ) {
                Icon(Icons.Default.Image, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Из галереи", maxLines = 1)
            }
            OutlinedButton(
                onClick = { takePictureLauncher.launch(null) },
                enabled = attachedImages.size < 6,
                modifier = Modifier.weight(1f).height(56.dp)
            ) {
                Icon(Icons.Default.CameraAlt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Сделать фото", maxLines = 1)
            }
        }
        if (attachedImages.isNotEmpty()) {
            OutlinedButton(
                onClick = { 
                    attachedImages = emptyList()
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
            ) {
                Icon(Icons.Default.Close, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Удалить фото (${attachedImages.size})")
            }
        }
        
        Button(
            onClick = {
                if (classASubject.isBlank() || classAGrade.isBlank() || classBSubject.isBlank() || classBGrade.isBlank()) {
                    isError = true
                    android.widget.Toast.makeText(context, "Заполните предметы и классы", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    if (planTitle.isBlank()) {
                        planTitle = "$classASubject $classAGrade — $classATopic; $classBSubject $classBGrade — $classBTopic"
                            .replace(Regex("\\s+"), " ")
                            .trim()
                    }
                    viewModel.generateLessonPlan(
                        classASubject,
                        classAGrade,
                        classATopic,
                        classBSubject,
                        classBGrade,
                        classBTopic,
                        lessonType,
                        attachedImages,
                        lessonDuration.toIntOrNull() ?: 45,
                        additionalInstructions,
                        planMode,
                        independentMinutesA,
                        independentMinutesB
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            enabled = uiState !is PlannerUiState.Loading
        ) {
            androidx.compose.animation.AnimatedContent(
                targetState = uiState is PlannerUiState.Loading,
                transitionSpec = {
                    androidx.compose.animation.fadeIn(animationSpec = androidx.compose.animation.core.tween(300)) togetherWith androidx.compose.animation.fadeOut(animationSpec = androidx.compose.animation.core.tween(300))
                },
                label = "generate_button_anim"
            ) { isLoading ->
                if (isLoading) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Генерация...")
                    }
                } else {
                    Text("Сгенерировать план урока")
                }
            }
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = uiState is PlannerUiState.Error,
            enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
            exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
        ) {
            Text((uiState as? PlannerUiState.Error)?.message ?: "", color = MaterialTheme.colorScheme.error)
        }

        androidx.compose.animation.AnimatedVisibility(
            visible = uiState is PlannerUiState.Success,
            enter = androidx.compose.animation.expandVertically() + androidx.compose.animation.fadeIn(),
            exit = androidx.compose.animation.shrinkVertically() + androidx.compose.animation.fadeOut()
        ) {
            if (uiState is PlannerUiState.Success) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Результат:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (isEditingPlan) {
                                    OutlinedButton(onClick = {
                                        viewModel.updateGeneratedPlan(editingPlanContent)
                                        isEditingPlan = false
                                    }) {
                                        Text("Готово")
                                    }
                                } else {
                                    IconButton(onClick = {
                                        editingPlanContent = (uiState as? PlannerUiState.Success)?.resultText ?: ""
                                        isEditingPlan = true
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Редактировать план")
                                    }
                                }
                                Button(onClick = { showSaveDialog = true }) {
                                    Text("Сохранить в папку")
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (isEditingPlan) {
                            OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                                value = editingPlanContent,
                                onValueChange = { editingPlanContent = it },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp),
                                textStyle = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            com.example.ui.MarkdownViewer(
                                markdown = (uiState as? PlannerUiState.Success)?.resultText ?: ""
                            )
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun IndependenceSelector(
    value: Int,
    onValueChange: (Int) -> Unit,
    label: String
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = when (value) {
                3 -> "3 минуты — нужна частая помощь"
                5 -> "5 минут — начальная"
                7 -> "7 минут — средняя"
                10 -> "10 минут — уверенная"
                else -> "15 минут — высокая"
            },
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            supportingText = { Text("Нейросеть не сделает самостоятельный этап длиннее") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
            modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
            shape = RoundedCornerShape(12.dp)
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            listOf(
                3 to "Нужна частая помощь",
                5 to "Начальная",
                7 to "Средняя",
                10 to "Уверенная",
                15 to "Высокая"
            ).forEach { (minutes, description) ->
                DropdownMenuItem(
                    text = { Text("$minutes минут — $description") },
                    onClick = {
                        onValueChange(minutes)
                        expanded = false
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(
    viewModel: PlannerFoldersViewModel = viewModel(),
    navController: NavHostController
) {
    var showSyncDialog by remember { mutableStateOf(false) }
    var syncCode by remember { mutableStateOf("") }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var showBackupMenu by remember { mutableStateOf(false) }
    val createBackupLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                val dao = com.example.data.local.PlannerDatabase.getDatabase(context).plannerDao()
                val error = com.example.data.local.PlannerBackupManager.export(context, it, dao)
                val message = error ?: "Резервная копия сохранена"
                android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
    val openBackupLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                val dao = com.example.data.local.PlannerDatabase.getDatabase(context).plannerDao()
                val result = com.example.data.local.PlannerBackupManager.importBackup(context, it, dao)
                val message = result.errorMessage ?: "Восстановлено планов: ${result.addedPlans}"
                android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }
    
    if (showSyncDialog) {
        AlertDialog(
            onDismissRequest = { showSyncDialog = false },
            title = { Text("Облачная Синхронизация (Firebase)") },
            text = {
                Column {
                    Text("Введите уникальный код для синхронизации планов уроков:")
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = syncCode,
                        onValueChange = { syncCode = it },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (syncCode.trim().length >= 6) {
                        showSyncDialog = false
                        coroutineScope.launch {
                            val result = com.example.data.remote.FirebaseSyncManager.downloadPlans(syncCode)
                            if (result.errorMessage != null) {
                                android.widget.Toast.makeText(context, result.errorMessage, android.widget.Toast.LENGTH_LONG).show()
                            } else if (result.plans.isNotEmpty()) {
                                val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                                val cloudFolder = db.plannerDao().getFolderByName("Облачная копия")
                                val folderId = cloudFolder?.id
                                    ?: db.plannerDao().insertFolder(com.example.data.local.FolderEntity(name = "Облачная копия"))
                                var addedCount = 0
                                result.plans.forEach { plan ->
                                    if (db.plannerDao().findMatchingPlan(folderId, plan.title, plan.timestamp) == null) {
                                        db.plannerDao().insertLessonPlan(plan.copy(id = 0, folderId = folderId))
                                        addedCount++
                                    }
                                }
                                val message = if (addedCount > 0) "Добавлено планов: $addedCount" else "Все планы уже загружены"
                                android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                            } else {
                                android.widget.Toast.makeText(context, "По этому коду планов нет", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    } else android.widget.Toast.makeText(context, "Код должен содержать не менее 6 символов", android.widget.Toast.LENGTH_SHORT).show()
                }) { Text("Скачать") }
            },
            dismissButton = {
                TextButton(onClick = { showSyncDialog = false }) { Text("Отмена") }
            }
        )
    }
    val folders by viewModel.allFolders.collectAsState()
    val archivedFolders by viewModel.archivedFolders.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var folderToDelete by remember { mutableStateOf<Long?>(null) }
    var folderToRename by remember { mutableStateOf<Long?>(null) }
    var renamedFolderName by remember { mutableStateOf("") }
    var showArchived by remember { mutableStateOf(false) }
    
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Новая папка") },
            text = {
                OutlinedTextField(shape = RoundedCornerShape(12.dp), 
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Название папки") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newFolderName.isNotBlank()) {
                        viewModel.addFolder(newFolderName)
                        newFolderName = ""
                        showAddDialog = false
                    }
                }) { Text("Создать") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Отмена") }
            }
        )
    }

    if (folderToDelete != null) {
        AlertDialog(
            onDismissRequest = { folderToDelete = null },
            title = { Text("Удалить папку?") },
            text = { Text("Вы уверены, что хотите удалить эту папку и все планы в ней?") },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteFolder(folderToDelete!!)
                    folderToDelete = null
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { folderToDelete = null }) { Text("Отмена") }
            }
        )
    }

    if (folderToRename != null) {
        AlertDialog(
            onDismissRequest = { folderToRename = null },
            title = { Text("Переименовать папку") },
            text = {
                OutlinedTextField(
                    value = renamedFolderName,
                    onValueChange = { renamedFolderName = it },
                    label = { Text("Название") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    enabled = renamedFolderName.isNotBlank(),
                    onClick = {
                        folderToRename?.let { viewModel.renameFolder(it, renamedFolderName) }
                        folderToRename = null
                    }
                ) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { folderToRename = null }) { Text("Отмена") } }
        )
    }
    
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Добавить папку")
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp)) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Мои папки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Row {
                    Box {
                        IconButton(onClick = { showBackupMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "Резервная копия")
                        }
                        DropdownMenu(expanded = showBackupMenu, onDismissRequest = { showBackupMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Сохранить резервную копию") },
                                leadingIcon = { Icon(Icons.Default.Save, contentDescription = null) },
                                onClick = {
                                    showBackupMenu = false
                                    val date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
                                    createBackupLauncher.launch("mksh-backup-$date.json")
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Восстановить из файла") },
                                leadingIcon = { Icon(Icons.Default.Restore, contentDescription = null) },
                                onClick = {
                                    showBackupMenu = false
                                    openBackupLauncher.launch(arrayOf("application/json", "text/plain"))
                                }
                            )
                        }
                    }
                    IconButton(onClick = { showSyncDialog = true }) {
                        Icon(Icons.Default.CloudSync, contentDescription = "Sync")
                    }
                    TextButton(onClick = { showArchived = !showArchived }) {
                        Text(if (showArchived) "Скрыть архив" else "Архив")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            val currentFolders = if (showArchived) archivedFolders else folders
            
            if (currentFolders.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(if (showArchived) "Архив пуст" else "У вас пока нет папок", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                    items(currentFolders) { folder ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { navController.navigate("folder_plans/${folder.id}") },
                            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), 
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), 
                            shape = RoundedCornerShape(20.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(folder.name, style = MaterialTheme.typography.titleMedium)
                                }
                                Row {
                                    IconButton(onClick = {
                                        folderToRename = folder.id
                                        renamedFolderName = folder.name
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Переименовать")
                                    }
                                    IconButton(onClick = { viewModel.archiveFolder(folder.id, !showArchived) }) {
                                        Icon(
                                            painter = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_save), 
                                            contentDescription = if (showArchived) "Разархивировать" else "Архивировать", 
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(onClick = { folderToDelete = folder.id }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonPlansScreen(
    folderId: Long,
    viewModel: LessonPlanListViewModel = viewModel(),
    navController: NavHostController
) {
    LaunchedEffect(folderId) {
        viewModel.loadPlans(folderId)
    }
    val plans by viewModel.plans.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var planToDelete by remember { mutableStateOf<Long?>(null) }
    
    val filteredPlans = plans.filter {
        it.title.contains(searchQuery, ignoreCase = true) ||
            it.content.contains(searchQuery, ignoreCase = true) ||
            it.tags.contains(searchQuery, ignoreCase = true)
    }
    val df = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    
    if (planToDelete != null) {
        AlertDialog(
            onDismissRequest = { planToDelete = null },
            title = { Text("Удалить план?") },
            text = { Text("Вы уверены, что хотите безвозвратно удалить этот план урока?") },
            confirmButton = {
                Button(onClick = {
                    viewModel.deletePlan(planToDelete!!)
                    planToDelete = null
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { planToDelete = null }) { Text("Отмена") }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
            }
            Text("Планы уроков", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black)
        }
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(shape = RoundedCornerShape(12.dp), 
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Поиск планов") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Поиск") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        if (plans.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.AutoMirrored.Filled.Article, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("В этой папке пока нет планов", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else if (filteredPlans.isEmpty()) {
             Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Ничего не найдено", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 80.dp)) {
                items(filteredPlans) { plan ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { navController.navigate("plan_detail/${plan!!.id}") },
                        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow), shape = RoundedCornerShape(20.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                                Text(plan!!.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                IconButton(onClick = { viewModel.toggleFavorite(plan!!.id, !plan!!.isFavorite) }) {
                                    Icon(
                                        if (plan!!.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, 
                                        contentDescription = "Избранное",
                                        tint = if (plan!!.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(df.format(Date(plan!!.timestamp)), style = MaterialTheme.typography.bodySmall)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                IconButton(onClick = { planToDelete = plan!!.id }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanDetailScreen(
    planId: Long,
    navController: NavHostController
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var plan by remember { mutableStateOf<LessonPlanEntity?>(null) }
    var isGeneratingActivity by remember { mutableStateOf(false) }
    var isFetching by remember { mutableStateOf(true) }
    var showEditDialog by remember { mutableStateOf(false) }
    var editedTitle by remember { mutableStateOf("") }
    var editedContent by remember { mutableStateOf("") }
    var showRegenerateDialog by remember { mutableStateOf(false) }
    var regenerateSection by remember { mutableStateOf("Поминутный тайминг") }
    var regenerateInstruction by remember { mutableStateOf("") }
    var regenerateMenuExpanded by remember { mutableStateOf(false) }
    var previousContentBeforeRegeneration by remember { mutableStateOf<String?>(null) }
    val createPdfLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        uri?.let {
            coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                plan?.let { currentPlan ->
                    val error = com.example.ui.PdfGenerator.generateGostPdf(context, it, currentPlan)
                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                        if (error != null) {
                            android.widget.Toast.makeText(context, "Ошибка PDF: $error", android.widget.Toast.LENGTH_LONG).show()
                        } else {
                            android.widget.Toast.makeText(context, "PDF сохранен", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
        }
    }

    val imagePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetMultipleContents()
    ) { uris: List<android.net.Uri> ->
        if (uris.isNotEmpty()) {
            coroutineScope.launch {
                isGeneratingActivity = true
                try {
                    val images = mutableListOf<Pair<String, String>>()
                    for (uri in uris.take(6)) {
                        
                        val options = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        context.contentResolver.openInputStream(uri)?.use { stream -> 
                            android.graphics.BitmapFactory.decodeStream(stream, null, options) 
                        }
                        val maxDim = 1024
                        var scale = 1
                        while (options.outWidth / scale > maxDim || options.outHeight / scale > maxDim) {
                            scale *= 2
                        }
                        val decodeOptions = android.graphics.BitmapFactory.Options().apply { inSampleSize = scale }
                        val bitmap = context.contentResolver.openInputStream(uri)?.use { stream -> 
                            android.graphics.BitmapFactory.decodeStream(stream, null, decodeOptions)
                        } ?: throw Exception("Failed to decode image")
                        val outputStream = java.io.ByteArrayOutputStream()
                        bitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, outputStream)
                        val base64Image = android.util.Base64.encodeToString(outputStream.toByteArray(), android.util.Base64.NO_WRAP)
                        val mimeType = context.contentResolver.getType(uri) ?: "image/jpeg"
                        images.add(Pair(mimeType, base64Image))
                    }
                    val currentPlan = plan
                    if (currentPlan != null) {
                        val hw = com.example.generateHomeworkFromImage(currentPlan.content, images)
                        if (!hw.startsWith("Error:")) {
                            val newContent = currentPlan.content + "\n\n# 📚 Домашнее задание по фото учебника\n" + hw
                            val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                            db.plannerDao().updatePlanContent(currentPlan.id, newContent)
                            plan = currentPlan.copy(content = newContent)
                        } else {
                            android.widget.Toast.makeText(context, hw, android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    android.widget.Toast.makeText(context, "Ошибка: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                } finally {
                    isGeneratingActivity = false
                }
            }
        }
    }

    val takePictureLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.TakePicturePreview()
    ) { bitmap: android.graphics.Bitmap? ->
        bitmap?.let {
            coroutineScope.launch {
                isGeneratingActivity = true
                try {
                    val outputStream = java.io.ByteArrayOutputStream()
                    it.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, outputStream)
                    val base64Image = android.util.Base64.encodeToString(outputStream.toByteArray(), android.util.Base64.NO_WRAP)
                    val mimeType = "image/jpeg"
                    val currentPlan = plan
                    if (currentPlan != null) {
                        val hw = com.example.generateHomeworkFromImage(currentPlan.content, listOf(Pair(mimeType, base64Image)))
                        if (!hw.startsWith("Error:")) {
                            val newContent = currentPlan.content + "\n\n# 📚 Домашнее задание по фото учебника\n" + hw
                            val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                            db.plannerDao().updatePlanContent(currentPlan.id, newContent)
                            plan = currentPlan.copy(content = newContent)
                        } else {
                            android.widget.Toast.makeText(context, hw, android.widget.Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Exception) {
                    android.widget.Toast.makeText(context, "Ошибка: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                } finally {
                    isGeneratingActivity = false
                }
            }
        }
    }

    
    LaunchedEffect(planId) {
        val db = com.example.data.local.PlannerDatabase.getDatabase(context)
        plan = db.plannerDao().getPlanById(planId)
        isFetching = false
    }

    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Редактировать план") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = editedTitle,
                        onValueChange = { editedTitle = it },
                        label = { Text("Название") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = editedContent,
                        onValueChange = { editedContent = it },
                        label = { Text("Содержание") },
                        minLines = 10,
                        maxLines = 16,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    enabled = editedTitle.isNotBlank() && editedContent.isNotBlank(),
                    onClick = {
                        val current = plan ?: return@Button
                        coroutineScope.launch {
                            val cleanTitle = editedTitle.trim()
                            val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                            db.plannerDao().updatePlan(current.id, cleanTitle, editedContent)
                            plan = current.copy(title = cleanTitle, content = editedContent)
                            showEditDialog = false
                        }
                    }
                ) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { showEditDialog = false }) { Text("Отмена") } }
        )
    }

    if (showRegenerateDialog) {
        AlertDialog(
            onDismissRequest = { showRegenerateDialog = false },
            title = { Text("Перегенерировать раздел") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Остальной план останется без изменений.", style = MaterialTheme.typography.bodySmall)
                    ExposedDropdownMenuBox(
                        expanded = regenerateMenuExpanded,
                        onExpandedChange = { regenerateMenuExpanded = !regenerateMenuExpanded }
                    ) {
                        OutlinedTextField(
                            value = regenerateSection,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Раздел") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(regenerateMenuExpanded) },
                            modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable)
                        )
                        ExposedDropdownMenu(
                            expanded = regenerateMenuExpanded,
                            onDismissRequest = { regenerateMenuExpanded = false }
                        ) {
                            listOf(
                                "Поминутный тайминг",
                                "Физкультминутка",
                                "Методические рекомендации",
                                "Материалы для самостоятельной работы",
                                "Готовые карточки для печати",
                                "Домашнее задание"
                            ).forEach { section ->
                                DropdownMenuItem(
                                    text = { Text(section) },
                                    onClick = {
                                        regenerateSection = section
                                        regenerateMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = regenerateInstruction,
                        onValueChange = { regenerateInstruction = it },
                        label = { Text("Что изменить (необязательно)") },
                        placeholder = { Text("Например: сделать проще или добавить игровой сюжет") },
                        minLines = 2,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val current = plan ?: return@Button
                    showRegenerateDialog = false
                    isGeneratingActivity = true
                    coroutineScope.launch {
                        try {
                            val generated = com.example.regeneratePlanSection(
                                current.content,
                                regenerateSection,
                                regenerateInstruction
                            )
                            if (generated.startsWith("Error:")) {
                                android.widget.Toast.makeText(context, generated.removePrefix("Error: "), android.widget.Toast.LENGTH_LONG).show()
                            } else {
                                val updated = com.example.replacePlanSection(current.content, regenerateSection, generated)
                                val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                                db.plannerDao().updatePlanContent(current.id, updated)
                                previousContentBeforeRegeneration = current.content
                                plan = current.copy(content = updated)
                                regenerateInstruction = ""
                            }
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Не удалось заменить раздел", android.widget.Toast.LENGTH_LONG).show()
                        } finally {
                            isGeneratingActivity = false
                        }
                    }
                }) { Text("Перегенерировать") }
            },
            dismissButton = { TextButton(onClick = { showRegenerateDialog = false }) { Text("Отмена") } }
        )
    }

    if (isFetching) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    val currentPlan = plan
    if (currentPlan == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("План не найден", color = MaterialTheme.colorScheme.error)
        }
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            IconButton(onClick = { navController.popBackStack() }) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
            }
            Text(plan!!.title, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            IconButton(onClick = { 
                coroutineScope.launch {
                    val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                    val newFav = !plan!!.isFavorite
                    db.plannerDao().updateFavoriteStatus(planId, newFav)
                    plan = plan?.copy(isFavorite = newFav)
                }
            }) {
                Icon(
                    if (plan!!.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, 
                    contentDescription = "Избранное",
                    tint = if (plan!!.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        val planDuration = Regex("(?:Длительность|тайминг)[:*\\s]*(\\d{1,3})", RegexOption.IGNORE_CASE)
            .find(plan!!.content)
            ?.groupValues
            ?.getOrNull(1)
            ?.toIntOrNull()
            ?: 45
        com.example.ui.LessonTimer(initialMinutes = planDuration)
        
        @OptIn(ExperimentalLayoutApi::class)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            OutlinedButton(onClick = {
                editedTitle = plan!!.title
                editedContent = plan!!.content
                showEditDialog = true
            }) {
                Icon(Icons.Default.Edit, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Редактировать")
            }
            OutlinedButton(
                enabled = !isGeneratingActivity,
                onClick = { showRegenerateDialog = true }
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Перегенерировать раздел")
            }
            if (previousContentBeforeRegeneration != null) {
                TextButton(onClick = {
                    val previous = previousContentBeforeRegeneration ?: return@TextButton
                    val current = plan ?: return@TextButton
                    coroutineScope.launch {
                        val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                        db.plannerDao().updatePlanContent(current.id, previous)
                        plan = current.copy(content = previous)
                        previousContentBeforeRegeneration = null
                    }
                }) {
                    Icon(Icons.Default.Undo, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Отменить замену")
                }
            }
            Button(
                onClick = {
                    isGeneratingActivity = true
                    coroutineScope.launch {
                        val activity = com.example.generateFiveMinuteActivity(plan!!.content)
                        if (!activity.startsWith("Error:")) {
                            val newContent = plan!!.content + "\n\n# ⚡ Пятиминутка\n" + activity
                            val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                            db.plannerDao().updatePlanContent(plan!!.id, newContent)
                            plan = plan?.copy(content = newContent)
                        } else {
                            android.widget.Toast.makeText(context, activity, android.widget.Toast.LENGTH_SHORT).show()
                        }
                        isGeneratingActivity = false
                    }
                },
                enabled = !isGeneratingActivity
            ) {
                if (isGeneratingActivity) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                } else {
                    Icon(androidx.compose.material.icons.Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text("Пятиминутка")
            }
            
            Button(
                onClick = {
                    isGeneratingActivity = true
                    coroutineScope.launch {
                        val presentation = com.example.generatePresentationOutline(plan!!.content)
                        if (!presentation.startsWith("Error:")) {
                            val newContent = plan!!.content + "\n\n# 📊 Структура презентации\n" + presentation
                            val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                            db.plannerDao().updatePlanContent(plan!!.id, newContent)
                            plan = plan?.copy(content = newContent)
                        } else {
                            android.widget.Toast.makeText(context, presentation, android.widget.Toast.LENGTH_SHORT).show()
                        }
                        isGeneratingActivity = false
                    }
                },
                enabled = !isGeneratingActivity
            ) {
                if (isGeneratingActivity) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                } else {
                    Icon(androidx.compose.material.icons.Icons.Default.Slideshow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text("Презентация")
            }
            




            var expandedMenu by remember { mutableStateOf(false) }
            Box {
                Button(
                    onClick = { expandedMenu = true },
                    enabled = !isGeneratingActivity
                ) {
                    if (isGeneratingActivity) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                    } else {
                        Icon(Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text("ДЗ по фото")
                }
                DropdownMenu(
                    expanded = expandedMenu,
                    onDismissRequest = { expandedMenu = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Выбрать из галереи") },
                        onClick = { 
                            expandedMenu = false
                            imagePickerLauncher.launch("image/*") 
                        },
                        leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) }
                    )
                    DropdownMenuItem(
                        text = { Text("Сделать фото") },
                        onClick = { 
                            expandedMenu = false
                            takePictureLauncher.launch(null) 
                        },
                        leadingIcon = { Icon(Icons.Default.CameraAlt, contentDescription = null) }
                    )
                }
            }

            Button(onClick = {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, plan!!.content)
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Поделиться планом"))
            }) {
                Icon(Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Поделиться")
            }
            
            val createDocLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/rtf")
            ) { uri ->
                uri?.let {
                    val error = plan?.let { current -> com.example.ui.RtfGenerator.generate(context, it, current) }
                    val message = if (error == null) "Файл для Word сохранён" else "Ошибка экспорта: $error"
                    android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
                }
            }

            Button(onClick = { 
                createDocLauncher.launch("${plan!!.title.replace(" ", "_")}.rtf")
            }) {
                Text("Скачать для Word")
            }
            
            Button(onClick = { 
                createPdfLauncher.launch("${plan!!.title.replace(" ", "_")}.pdf") 
            }) {
                Icon(painter = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_save), contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Скачать PDF")
            }
            
            OutlinedButton(onClick = {
                coroutineScope.launch {
                    val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                    db.plannerDao().insertLessonPlan(
                        plan!!.copy(id = 0, title = plan!!.title + " (Копия)", timestamp = System.currentTimeMillis())
                    )
                    android.widget.Toast.makeText(context, "План скопирован", android.widget.Toast.LENGTH_SHORT).show()
                }
            }) {
                Text("Клонировать")
            }
            
            OutlinedButton(onClick = {
                val intent = android.content.Intent(android.content.Intent.ACTION_INSERT).apply {
                    data = android.provider.CalendarContract.Events.CONTENT_URI
                    putExtra(android.provider.CalendarContract.Events.TITLE, plan!!.title)
                    putExtra(android.provider.CalendarContract.Events.DESCRIPTION, plan!!.content.take(500) + "...")
                }
                context.startActivity(intent)
            }) {
                Icon(androidx.compose.material.icons.Icons.Default.DateRange, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("В календарь")
            }
            
            var showUploadDialog by remember { mutableStateOf(false) }
            var uploadCode by remember { mutableStateOf("") }
            
            if (showUploadDialog) {
                AlertDialog(
                    onDismissRequest = { showUploadDialog = false },
                    title = { Text("Выгрузить в облако") },
                    text = {
                        Column {
                            Text("Введите код для сохранения:")
                            OutlinedTextField(value = uploadCode, onValueChange = { uploadCode = it })
                        }
                    },
                    confirmButton = {
                        Button(onClick = {
                            if (uploadCode.trim().length >= 6) {
                                coroutineScope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                    val success = com.example.data.remote.FirebaseSyncManager.syncPlan(plan!!, uploadCode)
                                    kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                        if (success) {
                                            android.widget.Toast.makeText(context, "Выгружено!", android.widget.Toast.LENGTH_SHORT).show()
                                        } else {
                                            android.widget.Toast.makeText(context, "Ошибка Firebase", android.widget.Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                showUploadDialog = false
                            } else android.widget.Toast.makeText(context, "Код должен содержать не менее 6 символов", android.widget.Toast.LENGTH_SHORT).show()
                        }) { Text("ОК") }
                    },
                    dismissButton = { TextButton(onClick = { showUploadDialog = false }) { Text("Отмена") } }
                )
            }
            
            OutlinedButton(onClick = { showUploadDialog = true }) {
                Icon(Icons.Default.CloudSync, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("В облако")
            }
            
            Button(onClick = {
                val opened = com.example.ui.CardsPrinter.print(context, plan!!)
                if (!opened) {
                    android.widget.Toast.makeText(context, "В плане пока нет готовых карточек. Создайте их через перегенерацию раздела.", android.widget.Toast.LENGTH_LONG).show()
                }
            }) {
                Icon(painter = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_agenda), contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Печатать карточки")
            }
        }
        HorizontalDivider()
        com.example.ui.MarkdownViewer(
            markdown = plan!!.content
        )
    }
}
