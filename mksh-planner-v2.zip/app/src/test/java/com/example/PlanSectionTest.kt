package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanSectionTest {
    @Test
    fun replacesOnlySelectedSection() {
        val original = """
            # Паспорт
            Старый паспорт

            # ⏱ Поминутный тайминг (45 минут)
            Старый тайминг

            # 🤸 Физкультминутка
            Старая разминка
        """.trimIndent()

        val updated = replacePlanSection(
            original,
            "Поминутный тайминг",
            "# ⏱ Поминутный тайминг\nНовый тайминг"
        )

        assertTrue(updated.contains("Новый тайминг"))
        assertFalse(updated.contains("Старый тайминг"))
        assertTrue(updated.contains("Старый паспорт"))
        assertTrue(updated.contains("Старая разминка"))
    }

    @Test
    fun appendsMissingSectionWithExpectedHeader() {
        val updated = replacePlanSection("# Паспорт\nТекст", "Домашнее задание", "Упражнение 5")
        assertEquals(1, Regex("# 📚 Домашнее задание").findAll(updated).count())
        assertTrue(updated.contains("Упражнение 5"))
    }
}
