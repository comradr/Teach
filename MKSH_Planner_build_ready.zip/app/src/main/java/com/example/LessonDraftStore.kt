package com.example

import android.content.Context
import android.content.SharedPreferences
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
data class LessonDraft(
    val useSecondClass: Boolean = false,
    val classASubject: String = "",
    val classAGrade: String = "",
    val classATopic: String = "",
    val classBSubject: String = "",
    val classBGrade: String = "",
    val classBTopic: String = "",
    val classAIndependentWorkLimit: String = "",
    val classBIndependentWorkLimit: String = "",
    val lessonDuration: String = "45",
    val additionalInstructions: String = "",
    val attachedImages: List<Pair<String, String>> = emptyList(), // For backwards compatibility
    val classAImages: List<DraftLessonImage> = emptyList(),
    val classBImages: List<DraftLessonImage> = emptyList(),
    val classAImportedPlan: ImportedLessonPlan? = null,
    val classBImportedPlan: ImportedLessonPlan? = null,
    val generatedPlan: String = "",
    val isEditingGeneratedPlan: Boolean = false,
    val editingGeneratedPlan: String = "",
    val materialUpdateMode: String = "Обновить задания по фото",
    val planMode: String = "Для себя",
    val lessonType: String = "Комбинированный"
)

class LessonDraftStore(context: Context) {
    private val appContext = context.applicationContext
    private val prefs: SharedPreferences = appContext.getSharedPreferences("lesson_draft", Context.MODE_PRIVATE)
    private val sourceDirectory = File(appContext.filesDir, "lesson_draft_sources").apply { mkdirs() }
    private val storedFingerprints = mutableMapOf<String, Pair<Int, Int>>()
    
    fun saveDraft(draft: LessonDraft) {
        val compactDraft = draft.copy(
            classAImportedPlan = externalizePlan("class_a", draft.classAImportedPlan),
            classBImportedPlan = externalizePlan("class_b", draft.classBImportedPlan)
        )
        val json = Json.encodeToString(compactDraft)
        prefs.edit().putString("draft_data", json).apply()
    }

    fun getDraft(): LessonDraft {
        val json = prefs.getString("draft_data", null)
        return if (json != null) {
            try {
                // Ignore unknown keys is needed to not crash on old draft
                val jsonParser = Json { ignoreUnknownKeys = true }
                val draft = jsonParser.decodeFromString<LessonDraft>(json)
                draft.copy(
                    classAImportedPlan = restorePlan("class_a", draft.classAImportedPlan),
                    classBImportedPlan = restorePlan("class_b", draft.classBImportedPlan)
                )
            } catch (e: Exception) {
                LessonDraft()
            }
        } else {
            LessonDraft()
        }
    }

    fun clearDraft() {
        prefs.edit().remove("draft_data").apply()
        listOf("class_a", "class_b").forEach { slot ->
            val target = sourceFile(slot)
            target.delete()
            File(sourceDirectory, "${target.name}.tmp").delete()
            File(sourceDirectory, "${target.name}.bak").delete()
        }
        storedFingerprints.clear()
    }

    private fun externalizePlan(slot: String, plan: ImportedLessonPlan?): ImportedLessonPlan? {
        val target = sourceFile(slot)
        if (plan == null) {
            target.delete()
            storedFingerprints.remove(slot)
            return null
        }
        if (plan.text.isBlank() && target.exists()) return plan
        val fingerprint = plan.text.length to plan.text.hashCode()
        if (target.exists() && storedFingerprints[slot] == fingerprint) return plan.copy(text = "")
        val written = writeAtomically(target, plan.text)
        if (written) storedFingerprints[slot] = fingerprint
        return if (written) plan.copy(text = "") else plan
    }

    private fun restorePlan(slot: String, plan: ImportedLessonPlan?): ImportedLessonPlan? {
        if (plan == null || plan.text.isNotBlank()) return plan
        val text = runCatching {
            val target = sourceFile(slot)
            val backup = File(sourceDirectory, "${target.name}.bak")
            if (!target.exists() && backup.exists()) backup.renameTo(target)
            target.takeIf(File::exists)?.readText()
        }.getOrNull()
        return text?.takeIf { it.isNotBlank() }?.let { plan.copy(text = it) }
    }

    private fun writeAtomically(target: File, content: String): Boolean = runCatching {
        if (target.exists() && target.length() == content.toByteArray().size.toLong() && target.readText() == content) {
            return@runCatching true
        }
        val temporary = File(sourceDirectory, "${target.name}.tmp")
        val backup = File(sourceDirectory, "${target.name}.bak")
        temporary.writeText(content)
        if (!target.exists() && backup.exists()) backup.renameTo(target)
        if (target.exists() && backup.exists()) backup.delete()
        if (target.exists() && !target.renameTo(backup)) error("Не удалось обновить источник черновика")
        try {
            if (!temporary.renameTo(target)) error("Не удалось сохранить источник черновика")
            backup.delete()
        } catch (error: Exception) {
            temporary.delete()
            if (!target.exists() && backup.exists()) backup.renameTo(target)
            throw error
        }
        true
    }.getOrDefault(false)

    private fun sourceFile(slot: String) = File(sourceDirectory, "$slot.txt")
}
