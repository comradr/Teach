package com.example

import android.content.Context
import java.io.File

class PlanEditDraftStore(context: Context) {
    private val directory = File(context.filesDir, "plan_edit_drafts").apply { mkdirs() }

    fun read(planId: Long): String? = runCatching {
        val target = file(planId)
        val backup = File(directory, "${target.name}.bak")
        if (!target.exists() && backup.exists()) backup.renameTo(target)
        target.takeIf(File::exists)?.readText()
    }.getOrNull()

    fun write(planId: Long, content: String): Boolean = runCatching {
        val target = file(planId)
        val temporary = File(directory, "${target.name}.tmp")
        val backup = File(directory, "${target.name}.bak")
        temporary.writeText(content)
        if (!target.exists() && backup.exists()) backup.renameTo(target)
        if (target.exists() && backup.exists()) backup.delete()
        if (target.exists() && !target.renameTo(backup)) error("Не удалось обновить черновик")
        try {
            if (!temporary.renameTo(target)) error("Не удалось сохранить черновик")
            backup.delete()
        } catch (error: Exception) {
            temporary.delete()
            if (!target.exists() && backup.exists()) backup.renameTo(target)
            throw error
        }
        true
    }.getOrDefault(false)

    fun clear(planId: Long) {
        runCatching {
            val target = file(planId)
            target.delete()
            File(directory, "${target.name}.tmp").delete()
            File(directory, "${target.name}.bak").delete()
        }
    }

    private fun file(planId: Long) = File(directory, "plan_$planId.md")
}
