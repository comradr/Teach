package com.example

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.serialization.Serializable
import org.w3c.dom.Node
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

@Serializable
data class ImportedLessonPlan(
    val fileName: String,
    val text: String,
    val wasTruncated: Boolean = false
)

internal fun importedPlanMarkdown(title: String, plan: ImportedLessonPlan): String = buildString {
    appendLine("# ${title.trim()}")
    appendLine()
    append(plan.text.trim())
}.trim()

object DocxLessonPlanImporter {
    const val MAX_IMPORTED_PLAN_CHARS = 24_000
    private const val MAX_DOCUMENT_XML_BYTES = 2_500_000

    fun import(context: Context, uri: Uri): Result<ImportedLessonPlan> = runCatching {
        val fileName = queryFileName(context, uri)
        if (!fileName.endsWith(".docx", ignoreCase = true)) {
            error("Поддерживается Word DOCX. Старый файл DOC пересохраните в Word как .docx.")
        }

        val xml = context.contentResolver.openInputStream(uri)?.use(::readDocumentXml)
            ?: error("Не удалось открыть выбранный документ.")
        val fullText = DocxTextExtractor.extractFromDocumentXml(xml).trim()
        if (fullText.isBlank()) error("В документе не найден текст плана.")

        ImportedLessonPlan(
            fileName = fileName,
            text = fullText.take(MAX_IMPORTED_PLAN_CHARS),
            wasTruncated = fullText.length > MAX_IMPORTED_PLAN_CHARS
        )
    }

    private fun readDocumentXml(input: java.io.InputStream): String {
        ZipInputStream(input.buffered()).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                if (entry.name == "word/document.xml") {
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val read = zip.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > MAX_DOCUMENT_XML_BYTES) error("Документ слишком большой для импорта.")
                        output.write(buffer, 0, read)
                    }
                    return output.toString(Charsets.UTF_8.name())
                }
                zip.closeEntry()
            }
        }
        error("Файл DOCX повреждён: не найден основной текст документа.")
    }

    private fun queryFileName(context: Context, uri: Uri): String {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                return cursor.getString(0)?.takeIf { it.isNotBlank() } ?: "готовый_план.docx"
            }
        }
        return uri.lastPathSegment?.substringAfterLast('/') ?: "готовый_план.docx"
    }
}

internal object DocxTextExtractor {
    fun extractFromDocumentXml(xml: String): String {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = true
            runCatching { setFeature("http://apache.org/xml/features/disallow-doctype-decl", true) }
            runCatching { setFeature("http://xml.org/sax/features/external-general-entities", false) }
            runCatching { setFeature("http://xml.org/sax/features/external-parameter-entities", false) }
        }
        val document = factory.newDocumentBuilder().parse(ByteArrayInputStream(xml.toByteArray(Charsets.UTF_8)))
        val body = document.getElementsByTagNameNS("*", "body").item(0) ?: return ""
        val blocks = mutableListOf<String>()
        val children = body.childNodes
        for (index in 0 until children.length) {
            val child = children.item(index)
            when (child.localName ?: child.nodeName.substringAfter(':')) {
                "p" -> paragraphText(child).takeIf { it.isNotBlank() }?.let(blocks::add)
                "tbl" -> tableMarkdown(child).takeIf { it.isNotBlank() }?.let(blocks::add)
            }
        }
        return blocks.joinToString("\n\n").replace(Regex("[ \\t]+\n"), "\n").trim()
    }

    private fun paragraphText(node: Node): String = buildString { appendTextNodes(node, this) }.trim()

    private fun appendTextNodes(node: Node, output: StringBuilder) {
        val name = node.localName ?: node.nodeName.substringAfter(':')
        when (name) {
            "t" -> output.append(node.textContent)
            "tab" -> output.append('\t')
            "br", "cr" -> output.append('\n')
            else -> {
                val children = node.childNodes
                for (index in 0 until children.length) appendTextNodes(children.item(index), output)
            }
        }
    }

    private fun tableMarkdown(table: Node): String {
        val rows = directChildren(table, "tr").map { row ->
            directChildren(row, "tc").map { cell ->
                val paragraphs = directChildren(cell, "p").map(::paragraphText).filter { it.isNotBlank() }
                paragraphs.joinToString("<br>").replace("|", "\\|")
            }
        }.filter { it.isNotEmpty() }
        if (rows.isEmpty()) return ""
        val columns = rows.maxOf { it.size }
        fun row(values: List<String>) = "| " + (0 until columns).joinToString(" | ") { values.getOrElse(it) { "" } } + " |"
        return buildString {
            appendLine(row(rows.first()))
            appendLine("| " + List(columns) { "---" }.joinToString(" | ") + " |")
            rows.drop(1).forEach { appendLine(row(it)) }
        }.trim()
    }

    private fun directChildren(node: Node, localName: String): List<Node> = buildList {
        val children = node.childNodes
        for (index in 0 until children.length) {
            val child = children.item(index)
            if ((child.localName ?: child.nodeName.substringAfter(':')) == localName) add(child)
        }
    }
}
