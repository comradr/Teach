package com.example

import android.content.Context

object GeminiApiKeyProvider {
    private const val PLACEHOLDER = "MY_GEMINI_API_KEY"

    @Suppress("UNUSED_PARAMETER")
    fun get(context: Context): String = BuildConfig.GEMINI_API_KEY.trim()

    fun isConfigured(context: Context): Boolean = isUsable(get(context))

    fun isUsable(value: String): Boolean {
        val key = value.trim()
        return key.isNotEmpty() && key != PLACEHOLDER && !key.contains("YOUR_API_KEY", ignoreCase = true)
    }
}
