package com.example.ui

import android.content.Context
import android.os.SystemClock
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.abs

internal data class PersistedLessonTimer(
    val running: Boolean,
    val remainingSeconds: Int,
    val targetWallClockMs: Long,
    val targetElapsedMs: Long,
    val bootEpochMs: Long
)

internal fun restoredTimerSeconds(
    saved: PersistedLessonTimer,
    nowWallClockMs: Long,
    nowElapsedMs: Long
): Int {
    if (!saved.running) return saved.remainingSeconds.coerceAtLeast(0)
    val currentBootEpoch = nowWallClockMs - nowElapsedMs
    val sameBoot = abs(currentBootEpoch - saved.bootEpochMs) <= 60_000L
    val remainingMs = if (sameBoot && saved.targetElapsedMs > 0L) {
        saved.targetElapsedMs - nowElapsedMs
    } else {
        saved.targetWallClockMs - nowWallClockMs
    }
    return ((remainingMs.coerceAtLeast(0L) + 999L) / 1_000L).toInt()
}

@Composable
fun LessonTimer(planId: Long = 0L, durationMinutes: Int = 45, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val totalSeconds = durationMinutes.coerceAtLeast(1) * 60
    val initial = remember(planId, durationMinutes) { readTimer(context, planId, totalSeconds) }
    var isRunning by remember(planId) { mutableStateOf(initial.running && initial.remainingSeconds > 0) }
    var timeLeftSeconds by remember(planId) { mutableIntStateOf(initial.remainingSeconds.coerceIn(0, totalSeconds)) }
    var targetEndElapsedMs by remember(planId) { mutableLongStateOf(initial.targetElapsedMs) }
    var targetEndWallClockMs by remember(planId) { mutableLongStateOf(initial.targetWallClockMs) }
    var bootEpochMs by remember(planId) { mutableLongStateOf(initial.bootEpochMs) }

    LaunchedEffect(durationMinutes) {
        if (!isRunning && timeLeftSeconds > totalSeconds) {
            timeLeftSeconds = totalSeconds
            persistPausedTimer(context, planId, timeLeftSeconds)
        }
    }

    LaunchedEffect(isRunning, targetEndElapsedMs) {
        if (!isRunning) return@LaunchedEffect
        val nowElapsed = SystemClock.elapsedRealtime()
        val currentBootEpoch = System.currentTimeMillis() - nowElapsed
        if (targetEndElapsedMs <= nowElapsed || abs(currentBootEpoch - bootEpochMs) > 60_000L) {
            targetEndElapsedMs = nowElapsed + timeLeftSeconds * 1_000L
            targetEndWallClockMs = System.currentTimeMillis() + timeLeftSeconds * 1_000L
            bootEpochMs = currentBootEpoch
            persistRunningTimer(context, planId, timeLeftSeconds, targetEndWallClockMs, targetEndElapsedMs, bootEpochMs)
        }
        while (isRunning) {
            val remainingMs = targetEndElapsedMs - SystemClock.elapsedRealtime()
            if (remainingMs <= 0L) {
                timeLeftSeconds = 0
                isRunning = false
                clearPersistedTimer(context, planId)
                break
            }
            timeLeftSeconds = ((remainingMs + 999L) / 1_000L).toInt()
            delay(250L)
        }
    }

    val minutes = timeLeftSeconds / 60
    val seconds = timeLeftSeconds % 60
    val progress = 1f - (timeLeftSeconds.toFloat() / totalSeconds.toFloat()).coerceIn(0f, 1f)

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.16f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Таймер урока", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                Text(String.format("%02d:%02d", minutes, seconds), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                val animatedProgress by androidx.compose.animation.core.animateFloatAsState(
                    targetValue = progress,
                    animationSpec = androidx.compose.animation.core.tween(1_000, easing = androidx.compose.animation.core.LinearEasing),
                    label = "lesson_timer_progress"
                )
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f)
                )
            }
            Spacer(Modifier.width(12.dp))
            IconButton(
                onClick = {
                    isRunning = false
                    timeLeftSeconds = totalSeconds
                    targetEndElapsedMs = 0L
                    targetEndWallClockMs = 0L
                    bootEpochMs = 0L
                    clearPersistedTimer(context, planId)
                },
                modifier = Modifier.size(48.dp)
            ) { Icon(Icons.Default.RestartAlt, contentDescription = "Сбросить таймер") }
            IconButton(
                onClick = {
                    if (isRunning) {
                        val remainingMs = targetEndElapsedMs - SystemClock.elapsedRealtime()
                        timeLeftSeconds = ((remainingMs.coerceAtLeast(0L) + 999L) / 1_000L).toInt()
                        isRunning = false
                        targetEndElapsedMs = 0L
                        targetEndWallClockMs = 0L
                        bootEpochMs = 0L
                        persistPausedTimer(context, planId, timeLeftSeconds)
                    } else {
                        if (timeLeftSeconds <= 0) timeLeftSeconds = totalSeconds
                        val nowElapsed = SystemClock.elapsedRealtime()
                        targetEndElapsedMs = nowElapsed + timeLeftSeconds * 1_000L
                        targetEndWallClockMs = System.currentTimeMillis() + timeLeftSeconds * 1_000L
                        bootEpochMs = System.currentTimeMillis() - nowElapsed
                        persistRunningTimer(context, planId, timeLeftSeconds, targetEndWallClockMs, targetEndElapsedMs, bootEpochMs)
                        isRunning = true
                    }
                },
                modifier = Modifier.size(56.dp)
            ) {
                Icon(
                    if (isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isRunning) "Пауза" else "Старт",
                    modifier = Modifier.size(32.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

private const val TIMER_PREFS = "lesson_timer_state"

private fun readTimer(context: Context, planId: Long, defaultSeconds: Int): PersistedLessonTimer {
    val prefs = context.applicationContext.getSharedPreferences(TIMER_PREFS, Context.MODE_PRIVATE)
    val prefix = "plan_${planId}_"
    if (!prefs.contains(prefix + "remaining")) return PersistedLessonTimer(false, defaultSeconds, 0L, 0L, 0L)
    val raw = PersistedLessonTimer(
        prefs.getBoolean(prefix + "running", false),
        prefs.getInt(prefix + "remaining", defaultSeconds),
        prefs.getLong(prefix + "target_wall", 0L),
        prefs.getLong(prefix + "target_elapsed", 0L),
        prefs.getLong(prefix + "boot_epoch", 0L)
    )
    val restored = restoredTimerSeconds(raw, System.currentTimeMillis(), SystemClock.elapsedRealtime())
    return raw.copy(remainingSeconds = restored, running = raw.running && restored > 0)
}

private fun persistRunningTimer(context: Context, planId: Long, remainingSeconds: Int, targetWallClockMs: Long, targetElapsedMs: Long, bootEpochMs: Long) {
    val prefix = "plan_${planId}_"
    context.applicationContext.getSharedPreferences(TIMER_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean(prefix + "running", true).putInt(prefix + "remaining", remainingSeconds)
        .putLong(prefix + "target_wall", targetWallClockMs).putLong(prefix + "target_elapsed", targetElapsedMs)
        .putLong(prefix + "boot_epoch", bootEpochMs).apply()
}

private fun persistPausedTimer(context: Context, planId: Long, remainingSeconds: Int) {
    val prefix = "plan_${planId}_"
    context.applicationContext.getSharedPreferences(TIMER_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean(prefix + "running", false).putInt(prefix + "remaining", remainingSeconds)
        .remove(prefix + "target_wall").remove(prefix + "target_elapsed").remove(prefix + "boot_epoch").apply()
}

private fun clearPersistedTimer(context: Context, planId: Long) {
    val prefix = "plan_${planId}_"
    context.applicationContext.getSharedPreferences(TIMER_PREFS, Context.MODE_PRIVATE).edit()
        .remove(prefix + "running").remove(prefix + "remaining").remove(prefix + "target_wall")
        .remove(prefix + "target_elapsed").remove(prefix + "boot_epoch").apply()
}
