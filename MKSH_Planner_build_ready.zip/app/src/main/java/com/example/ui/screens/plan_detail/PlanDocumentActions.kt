package com.example

import android.content.Context
import android.content.Intent
import android.provider.CalendarContract
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.example.data.local.LessonPlanEntity
import com.example.data.local.PlannerDatabase
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PlanDocumentActions(plan: LessonPlanEntity) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val createDocument = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/rtf")
    ) { uri ->
        uri?.let {
            context.contentResolver.openOutputStream(it)?.use { stream ->
                stream.write(markdownToRtf(plan.content).toByteArray())
            }
        }
    }
    val webView = remember(context) { WebView(context) }
    DisposableEffect(webView) {
        onDispose { webView.destroy() }
    }

    FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        OutlinedButton(onClick = {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_TEXT, plan.content)
                type = "text/plain"
            }
            context.startActivity(Intent.createChooser(sendIntent, "Поделиться планом"))
        }) {
            Icon(Icons.Default.Share, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Поделиться")
        }

        OutlinedButton(onClick = {
            createDocument.launch("${plan.title.replace(" ", "_")}.rtf")
        }) { Text("Документ RTF") }

        OutlinedButton(onClick = {
            scope.launch {
                PlannerDatabase.getDatabase(context).plannerDao().insertLessonPlan(
                    plan.copy(id = 0, title = "${plan.title} (Копия)", timestamp = System.currentTimeMillis())
                )
                Toast.makeText(context, "План скопирован", Toast.LENGTH_SHORT).show()
            }
        }) { Text("Клонировать") }

        OutlinedButton(onClick = {
            context.startActivity(Intent(Intent.ACTION_INSERT).apply {
                data = CalendarContract.Events.CONTENT_URI
                putExtra(CalendarContract.Events.TITLE, plan.title)
                putExtra(CalendarContract.Events.DESCRIPTION, plan.content.take(500))
            })
        }) {
            Icon(Icons.Default.DateRange, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("В календарь")
        }

        Button(onClick = { printCards(context, webView, plan.content) }) {
            Text("Карточки (PDF/Печать)")
        }
    }
}

internal fun cardsMarkdownToHtml(markdown: String): String {
    var body = extractCardsForPrinting(markdown)
        .replace(Regex("\\*\\*(.*?)\\*\\*"), "<b>$1</b>")
        .replace(Regex("### (.*?)\n"), "</div><div class=\"card\"><h3>$1</h3>\n")
        .replace(Regex("## (.*?)\n"), "</div><div class=\"card\"><h2>$1</h2>\n")
        .replace(Regex("# (.*?)\n"), "</div><div class=\"card\"><h1>$1</h1>\n")
        .replace(Regex("(?:\\*|-) (.*?)\n"), "<li>$1</li>\n")
        .replace(Regex("!\\[(.*?)\\]\\((.*?)\\)"), "<img src=\"$2\" alt=\"$1\">")
        .replace("\n", "<br>")
    body = if (body.startsWith("</div>")) body.substring(6) else "<div class=\"card\">$body"
    body = (body + "</div>").replace("<div class=\"card\"></div>", "")
    return """
        <html><head><meta charset="utf-8"><style>
        body { font-family: sans-serif; padding: 20px; font-size: 18px; background: #fff; }
        .grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; }
        .card { border: 2px dashed #999; padding: 20px; border-radius: 12px; page-break-inside: avoid; }
        h1, h2, h3 { margin-top: 0; color: #333; }
        @media print { body { padding: 0; } .card { border-color: #000; } }
        </style></head><body><h2>Раздаточные материалы</h2><div class="grid">$body</div></body></html>
    """.trimIndent()
}

private fun printCards(context: Context, webView: WebView, markdown: String) {
    webView.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView, url: String) {
            val manager = context.getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
            manager.print(
                "Cards",
                view.createPrintDocumentAdapter("Карточки к уроку"),
                android.print.PrintAttributes.Builder().build()
            )
        }
    }
    webView.loadDataWithBaseURL(null, cardsMarkdownToHtml(markdown), "text/HTML", "UTF-8", null)
}
