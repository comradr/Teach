package com.example.ui.components

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.MarkdownViewer

@Composable
fun StructuredPlanViewer(
    markdown: String,
    modifier: Modifier = Modifier
) {
    val sections = splitPlanSections(markdown)
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        sections.forEach { section ->
            SoftCard(modifier = Modifier.fillMaxWidth()) {
                splitTableAwareBlocks(section).forEach { block ->
                    if (block.isTable) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                        ) {
                            MarkdownViewer(
                                markdown = block.markdown,
                                modifier = Modifier.widthIn(min = 760.dp)
                            )
                        }
                    } else {
                        MarkdownViewer(markdown = block.markdown)
                    }
                }
            }
        }
    }
}

internal fun splitPlanSections(markdown: String): List<String> {
    if (markdown.isBlank()) return emptyList()
    val result = mutableListOf<String>()
    val current = mutableListOf<String>()
    markdown.lines().forEach { line ->
        val isHeading = line.matches(Regex("^#{1,2}\\s+.+"))
        if (isHeading && current.any { it.isNotBlank() }) {
            result += current.joinToString("\n").trim()
            current.clear()
        }
        current += line
    }
    if (current.any { it.isNotBlank() }) {
        result += current.joinToString("\n").trim()
    }
    return result.filter { it.isNotBlank() }
}

internal data class PlanRenderBlock(val markdown: String, val isTable: Boolean)

internal fun splitTableAwareBlocks(markdown: String): List<PlanRenderBlock> {
    val lines = markdown.lines()
    val result = mutableListOf<PlanRenderBlock>()
    val text = mutableListOf<String>()
    fun flushText() {
        val value = text.joinToString("\n").trim()
        if (value.isNotBlank()) result += PlanRenderBlock(value, false)
        text.clear()
    }

    var index = 0
    while (index < lines.size) {
        val isTableStart = lines[index].trimStart().startsWith("|") &&
            index + 1 < lines.size &&
            lines[index + 1].trim().replace("|", "").replace(":", "").replace("-", "").isBlank() &&
            lines[index + 1].contains("---")
        if (!isTableStart) {
            text += lines[index]
            index++
            continue
        }
        flushText()
        val table = mutableListOf<String>()
        while (index < lines.size && lines[index].trimStart().startsWith("|")) {
            table += lines[index]
            index++
        }
        result += PlanRenderBlock(table.joinToString("\n"), true)
    }
    flushText()
    return result
}
