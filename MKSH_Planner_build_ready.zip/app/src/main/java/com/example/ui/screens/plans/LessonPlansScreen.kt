package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.FolderEntity
import com.example.data.local.LessonPlanEntity
import com.example.data.local.LessonMaterialEntity
import com.example.data.local.LessonMaterialStore
import com.example.ui.FavoritesScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun LessonPlansScreen(
    folderId: Long,
    viewModel: LessonPlanListViewModel = viewModel(),
    navController: NavHostController
) {
    LaunchedEffect(folderId) {
        viewModel.loadPlans(folderId)
    }
    val plans by viewModel.plans.collectAsState()
    val materials by viewModel.materials.collectAsState()
    val folder by viewModel.folder.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var selectedSort by remember { mutableStateOf(PlanSort.Newest) }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var planToDelete by remember { mutableStateOf<Long?>(null) }
    val coroutineScope = rememberCoroutineScope()
    var planToRename by remember { mutableStateOf<com.example.data.local.LessonPlanEntity?>(null) }
    var renamePlanTitle by remember { mutableStateOf("") }
    var renamePlanTags by remember { mutableStateOf("") }
    var importedPlan by remember { mutableStateOf<ImportedLessonPlan?>(null) }
    var importedPlanTitle by remember { mutableStateOf("") }
    var materialToDelete by remember { mutableStateOf<LessonMaterialEntity?>(null) }
    var materialToRename by remember { mutableStateOf<LessonMaterialEntity?>(null) }
    var materialRenameText by remember { mutableStateOf("") }
    
    val context = androidx.compose.ui.platform.LocalContext.current
    val importPlanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            coroutineScope.launch {
                val result = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    DocxLessonPlanImporter.import(context, uri)
                }
                result.onSuccess { plan ->
                    importedPlan = plan
                    importedPlanTitle = plan.fileName.substringBeforeLast('.').replace('_', ' ').trim()
                }.onFailure { error ->
                    android.widget.Toast.makeText(
                        context,
                        error.message ?: "Не удалось прочитать Word-план",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }
    val importMaterialLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.addMaterial(context, folderId, uri) { result ->
                result.onSuccess {
                    android.widget.Toast.makeText(context, "Материал добавлен в папку", android.widget.Toast.LENGTH_SHORT).show()
                }.onFailure { error ->
                    android.widget.Toast.makeText(
                        context,
                        error.message ?: "Не удалось добавить материал",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }
    val filteredPlans = plans.filter { it.title.contains(searchQuery, ignoreCase = true) || it.content.contains(searchQuery, ignoreCase = true) || it.tags.contains(searchQuery, ignoreCase = true) }
    val displayedPlans = remember(filteredPlans, selectedSort) { sortPlans(filteredPlans, selectedSort) }
    val df = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

    if (importedPlan != null) {
        AlertDialog(
            onDismissRequest = { importedPlan = null },
            title = { Text("Добавить готовый план") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = importedPlanTitle,
                        onValueChange = { importedPlanTitle = it },
                        label = { Text("Название в папке") },
                        singleLine = true
                    )
                    Text(
                        "Документ сохранится как обычный план: его можно открыть, редактировать и использовать дальше.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        importedPlan!!.text.take(1_500),
                        modifier = Modifier.fillMaxWidth().heightIn(max = 180.dp).verticalScroll(rememberScrollState()),
                        style = MaterialTheme.typography.bodySmall
                    )
                    if (importedPlan!!.wasTruncated) {
                        Text(
                            "Предпросмотр сокращён. В папке сохранится полный текст документа.",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    enabled = importedPlanTitle.isNotBlank(),
                    onClick = {
                        val plan = importedPlan ?: return@Button
                        val title = importedPlanTitle.trim()
                        viewModel.importPlan(folderId, title, importedPlanMarkdown(title, plan)) { id ->
                            importedPlan = null
                            navController.navigate("plan_detail/$id")
                        }
                    }
                ) { Text("Добавить") }
            },
            dismissButton = {
                TextButton(onClick = { importedPlan = null }) { Text("Отмена") }
            }
        )
    }
    
    if (planToRename != null) {
        AlertDialog(
            onDismissRequest = { planToRename = null },
            title = { Text("Свойства плана") },
            text = {
                Column {
                    OutlinedTextField(
                        value = renamePlanTitle,
                        onValueChange = { renamePlanTitle = it },
                        label = { Text("Название плана") },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = renamePlanTags,
                        onValueChange = { renamePlanTags = it },
                        label = { Text("Метки (через запятую)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (renamePlanTitle.isNotBlank()) {
                        val targetId = planToRename?.id ?: return@Button
                        viewModel.updatePlanProperties(targetId, renamePlanTitle, renamePlanTags)
                        planToRename = null
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = {
                TextButton(onClick = { planToRename = null }) { Text("Отмена") }
            }
        )
    }
    if (materialToRename != null) {
        AlertDialog(
            onDismissRequest = { materialToRename = null },
            title = { Text("Переименовать материал") },
            text = {
                OutlinedTextField(
                    value = materialRenameText,
                    onValueChange = { materialRenameText = it },
                    label = { Text("Название файла") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    enabled = materialRenameText.isNotBlank(),
                    onClick = {
                        val id = materialToRename?.id ?: return@Button
                        viewModel.renameMaterial(id, materialRenameText)
                        materialToRename = null
                    }
                ) { Text("Сохранить") }
            },
            dismissButton = { TextButton(onClick = { materialToRename = null }) { Text("Отмена") } }
        )
    }
    if (materialToDelete != null) {
        AlertDialog(
            onDismissRequest = { materialToDelete = null },
            title = { Text("Удалить материал?") },
            text = { Text("Файл будет удалён из папки и памяти приложения.") },
            confirmButton = {
                Button(
                    onClick = {
                        val target = materialToDelete ?: return@Button
                        viewModel.deleteMaterial(context, target)
                        materialToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Удалить") }
            },
            dismissButton = { TextButton(onClick = { materialToDelete = null }) { Text("Отмена") } }
        )
    }
    if (planToDelete != null) {
        AlertDialog(
            onDismissRequest = { planToDelete = null },
            title = { Text("Удалить план?") },
            text = { Text("Вы уверены, что хотите безвозвратно удалить этот план урока?") },
            confirmButton = {
                Button(onClick = {
                    val targetId = planToDelete ?: return@Button
                    viewModel.deletePlan(targetId)
                    planToDelete = null
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { planToDelete = null }) { Text("Отмена") }
            }
        )
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        com.example.ui.components.SoftCard(
            containerColor = com.example.ui.theme.PlannerColors.LavenderSoft
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { navController.popBackStack() }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                }
                com.example.ui.components.SectionTitle(
                    title = folder?.name ?: "Планы уроков",
                    subtitle = "Планы и материалы к урокам"
                )
            }
        }
        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(
                onClick = {
                    importPlanLauncher.launch(
                        arrayOf(
                            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                            "application/msword"
                        )
                    )
                },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.Description, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Готовый план")
            }
            FilledTonalButton(
                onClick = { importMaterialLauncher.launch(arrayOf("*/*")) },
                modifier = Modifier.weight(1f)
            ) {
                Icon(Icons.Default.AttachFile, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Материалы к уроку")
            }
        }
        if (materials.isNotEmpty()) {
            Text("Материалы", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            LazyColumn(
                modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(materials, key = { it.id }) { material ->
                    var menuExpanded by remember(material.id) { mutableStateOf(false) }
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable {
                                runCatching {
                                    context.startActivity(LessonMaterialStore.openIntent(context, material))
                                }.onFailure {
                                    android.widget.Toast.makeText(context, it.message ?: "На телефоне нет приложения для открытия файла", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.AttachFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(material.displayName, fontWeight = FontWeight.SemiBold, maxLines = 2)
                                Text(
                                    formatMaterialSize(material.sizeBytes),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Box {
                                IconButton(onClick = { menuExpanded = true }) {
                                    Icon(Icons.Default.MoreVert, contentDescription = "Действия с материалом")
                                }
                                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                                    DropdownMenuItem(
                                        text = { Text("Поделиться") },
                                        onClick = {
                                            menuExpanded = false
                                            runCatching {
                                                context.startActivity(Intent.createChooser(LessonMaterialStore.shareIntent(context, material), "Поделиться материалом"))
                                            }.onFailure {
                                                android.widget.Toast.makeText(
                                                    context,
                                                    it.message ?: "На телефоне нет приложения для отправки файла",
                                                    android.widget.Toast.LENGTH_LONG
                                                ).show()
                                            }
                                        },
                                        leadingIcon = { Icon(Icons.Default.Share, contentDescription = null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Переименовать") },
                                        onClick = {
                                            menuExpanded = false
                                            materialToRename = material
                                            materialRenameText = material.displayName
                                        },
                                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Удалить") },
                                        onClick = { menuExpanded = false; materialToDelete = material },
                                        leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Найти план") },
                modifier = Modifier.weight(1f),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Поиск") }
            )
            Box {
                IconButton(onClick = { sortMenuExpanded = true }) {
                    Icon(Icons.Default.Sort, contentDescription = "Сортировка: ${selectedSort.label}")
                }
                DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                    PlanSort.entries.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option.label) },
                            onClick = { selectedSort = option; sortMenuExpanded = false },
                            leadingIcon = {
                                if (selectedSort == option) Icon(Icons.Default.Check, contentDescription = null)
                            }
                        )
                    }
                }
            }
        }
        Text(selectedSort.label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)

        if (plans.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    com.example.ui.components.mascot.PlannerMascot(
                        com.example.ui.components.mascot.MascotState.PlansEmpty,
                        modifier = Modifier.size(142.dp)
                    )
                    Text(
                        if (materials.isEmpty()) "В этой папке пока ничего нет" else "В этой папке пока нет планов",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Сохранённые планы появятся здесь",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else if (filteredPlans.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    com.example.ui.components.mascot.PlannerMascot(
                        com.example.ui.components.mascot.MascotState.Guide,
                        modifier = Modifier.size(120.dp)
                    )
                    Text("По этому запросу ничего не найдено")
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(displayedPlans, key = { it.id }) { plan ->
                    var menuExpanded by remember(plan.id) { mutableStateOf(false) }
                    Box {
                        com.example.ui.components.PlanCard(
                            plan = plan,
                            onOpen = { navController.navigate("plan_detail/${plan.id}") },
                            onToggleFavorite = {
                                viewModel.toggleFavorite(plan.id, !plan.isFavorite)
                            },
                            onMore = { menuExpanded = true }
                        )
                        DropdownMenu(
                            expanded = menuExpanded,
                            onDismissRequest = { menuExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Обновить урок на основе") },
                                onClick = {
                                    menuExpanded = false
                                    navController.navigate("generator?sourcePlanId=${plan.id}") {
                                        popUpTo(navController.graph.startDestinationId) { inclusive = true }
                                        launchSingleTop = true
                                    }
                                },
                                leadingIcon = { Icon(Icons.Default.Refresh, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Свойства") },
                                onClick = {
                                    menuExpanded = false
                                    planToRename = plan
                                    renamePlanTitle = plan.title
                                    renamePlanTags = plan.tags
                                },
                                leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Удалить") },
                                onClick = {
                                    menuExpanded = false
                                    planToDelete = plan.id
                                },
                                leadingIcon = {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

internal fun formatMaterialSize(bytes: Long): String = when {
    bytes < 1024L -> "$bytes Б"
    bytes < 1024L * 1024L -> "${bytes / 1024L} КБ"
    else -> String.format(Locale.getDefault(), "%.1f МБ", bytes / (1024.0 * 1024.0))
}
