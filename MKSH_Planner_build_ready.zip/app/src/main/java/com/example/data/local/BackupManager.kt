package com.example.data.local

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.flow.first
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.room.withTransaction
import android.util.Base64
import kotlinx.coroutines.CancellationException
import java.io.File

@Serializable
data class BackupData(
    val folders: List<FolderData>,
    val plans: List<PlanData>,
    val templates: List<TemplateData> = emptyList(),
    val materials: List<MaterialData> = emptyList(),
    val schemaVersion: Int = 2
)

@Serializable
data class FolderData(
    val oldId: Long,
    val name: String,
    val isArchived: Boolean,
    val uid: String = ""
)

@Serializable
data class PlanData(
    val oldFolderId: Long,
    val title: String,
    val content: String,
    val isFavorite: Boolean,
    val tags: String,
    val timestamp: Long,
    val durationMinutes: Int = 45,
    val uid: String = "",
    val updatedAt: Long = timestamp,
    val sourcePlanUid: String? = null
)

@Serializable
data class MaterialData(
    val oldFolderId: Long,
    val displayName: String,
    val mimeType: String,
    val timestamp: Long,
    val uid: String = "",
    val contentBase64: String
)

@Serializable
data class TemplateData(
    val name: String,
    val useSecondClass: Boolean = false,
    val classASubject: String = "",
    val classAGrade: String = "",
    val classATopic: String = "",
    val classBSubject: String = "",
    val classBGrade: String = "",
    val classBTopic: String = "",
    val classAIndependentWorkLimit: String = "15",
    val classBIndependentWorkLimit: String = "15",
    val planMode: String = "Для себя",
    val additionalInstructions: String = "",
    val lessonDuration: String = "45",
    val lessonType: String = "Комбинированный"
)

class BackupManager(private val context: Context, private val database: PlannerDatabase) {
    suspend fun createBackup(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val backup = database.withTransaction {
                val dao = database.plannerDao()
                val folders = dao.getAllFoldersSnapshot().map { FolderData(it.id, it.name, it.isArchived, it.uid) }
                val plans = dao.getAllPlansSnapshot().map { plan ->
                    PlanData(
                        plan.folderId, plan.title, plan.content, plan.isFavorite, plan.tags,
                        plan.timestamp, plan.durationMinutes, plan.uid, plan.updatedAt, plan.sourcePlanUid
                    )
                }
                val templates = dao.getAllTemplates().first().map { template ->
                    TemplateData(
                        template.name, template.useSecondClass,
                        template.classASubject, template.classAGrade, template.classATopic,
                        template.classBSubject, template.classBGrade, template.classBTopic,
                        template.classAIndependentWorkLimit, template.classBIndependentWorkLimit,
                        template.planMode, template.additionalInstructions, template.lessonDuration, template.lessonType
                    )
                }
                val materials = dao.getAllMaterialsSnapshot().mapNotNull { material ->
                    val file = LessonMaterialStore.file(context, material)
                    if (!file.exists()) null else MaterialData(
                        oldFolderId = material.folderId,
                        displayName = material.displayName,
                        mimeType = material.mimeType,
                        timestamp = material.timestamp,
                        uid = material.uid,
                        contentBase64 = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)
                    )
                }
                BackupData(folders, plans, templates, materials)
            }
            val json = Json.encodeToString(backup)

            val stream = context.contentResolver.openOutputStream(uri) ?: return@withContext false
            stream.use {
                it.write(json.toByteArray())
            }
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun restoreBackup(uri: Uri): Boolean = withContext(Dispatchers.IO) {
        try {
            val json = context.contentResolver.openInputStream(uri)?.use {
                val reader = BufferedReader(InputStreamReader(it))
                reader.readText()
            } ?: return@withContext false

            val parser = Json { this.ignoreUnknownKeys = true }
            val backup = parser.decodeFromString<BackupData>(json)

            database.withTransaction {
                val dao = database.plannerDao()
                val folderIdMap = mutableMapOf<Long, Long>()

                for (folder in backup.folders) {
                    val existing = folder.uid.takeIf { it.isNotBlank() }?.let { dao.getFolderByUid(it) }
                        ?: dao.getFolderByName(folder.name)
                    val newId = if (existing != null) {
                        if (existing.isArchived != folder.isArchived) {
                            dao.updateFolderArchiveStatus(existing.id, folder.isArchived)
                        }
                        existing.id
                    } else {
                        dao.insertFolder(FolderEntity(name = folder.name, isArchived = folder.isArchived, uid = folder.uid.ifBlank { java.util.UUID.randomUUID().toString() }))
                    }
                    folderIdMap[folder.oldId] = newId
                }

                for (plan in backup.plans) {
                    val newFolderId = folderIdMap[plan.oldFolderId]
                    val stableMatch = plan.uid.takeIf { it.isNotBlank() }?.let { dao.getPlanByUid(it) }
                    if (newFolderId != null && stableMatch != null && plan.updatedAt > stableMatch.updatedAt) {
                        dao.updateLessonPlan(
                            stableMatch.copy(
                                folderId = newFolderId,
                                title = plan.title,
                                content = plan.content,
                                isFavorite = plan.isFavorite,
                                tags = plan.tags,
                                timestamp = plan.timestamp,
                                durationMinutes = plan.durationMinutes,
                                updatedAt = plan.updatedAt,
                                sourcePlanUid = plan.sourcePlanUid
                            )
                        )
                    } else if (newFolderId != null && stableMatch == null && !dao.planExists(newFolderId, plan.title, plan.timestamp)) {
                        val entity = LessonPlanEntity(
                            folderId = newFolderId,
                            title = plan.title,
                            content = plan.content,
                            isFavorite = plan.isFavorite,
                            tags = plan.tags,
                            timestamp = plan.timestamp,
                            durationMinutes = plan.durationMinutes,
                            uid = plan.uid.ifBlank { java.util.UUID.randomUUID().toString() },
                            updatedAt = plan.updatedAt,
                            sourcePlanUid = plan.sourcePlanUid
                        )
                        dao.insertLessonPlan(entity)
                    }
                }

                for (template in backup.templates) {
                    dao.upsertTemplate(LessonTemplateEntity(
                        name = template.name,
                        useSecondClass = template.useSecondClass,
                        classASubject = template.classASubject,
                        classAGrade = template.classAGrade,
                        classATopic = template.classATopic,
                        classBSubject = template.classBSubject,
                        classBGrade = template.classBGrade,
                        classBTopic = template.classBTopic,
                        classAIndependentWorkLimit = template.classAIndependentWorkLimit,
                        classBIndependentWorkLimit = template.classBIndependentWorkLimit,
                        planMode = template.planMode,
                        additionalInstructions = template.additionalInstructions,
                        lessonDuration = template.lessonDuration,
                        lessonType = template.lessonType
                    ))
                }

                val materialsDir = File(context.filesDir, "lesson_materials").apply { mkdirs() }
                for (material in backup.materials) {
                    val newFolderId = folderIdMap[material.oldFolderId] ?: continue
                    if (material.uid.isNotBlank() && dao.getMaterialByUid(material.uid) != null) continue
                    val bytes = runCatching { Base64.decode(material.contentBase64, Base64.DEFAULT) }.getOrNull() ?: continue
                    if (bytes.isEmpty() || bytes.size.toLong() > LessonMaterialStore.MAX_FILE_BYTES) continue
                    val extension = material.displayName.substringAfterLast('.', "").takeIf { it.length in 1..10 }
                    val storedName = java.util.UUID.randomUUID().toString() + (extension?.let { ".$it" } ?: "")
                    val target = File(materialsDir, storedName)
                    target.writeBytes(bytes)
                    runCatching {
                        dao.insertMaterial(
                            LessonMaterialEntity(
                                folderId = newFolderId,
                                displayName = material.displayName,
                                storedFileName = storedName,
                                mimeType = material.mimeType,
                                sizeBytes = bytes.size.toLong(),
                                timestamp = material.timestamp,
                                uid = material.uid.ifBlank { java.util.UUID.randomUUID().toString() }
                            )
                        )
                    }.onFailure { target.delete() }
                }
            }
            true
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
