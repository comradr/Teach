package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val isArchived: Boolean = false,
    val uid: String = java.util.UUID.randomUUID().toString()
)

@Entity(
    tableName = "lesson_plans",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("folderId")]
)
data class LessonPlanEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val folderId: Long,
    val title: String,
    val content: String,
    val isFavorite: Boolean = false,
    val tags: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val durationMinutes: Int = 45,
    val uid: String = java.util.UUID.randomUUID().toString(),
    val updatedAt: Long = System.currentTimeMillis(),
    val sourcePlanUid: String? = null
)

@Entity(
    tableName = "lesson_materials",
    foreignKeys = [
        ForeignKey(
            entity = FolderEntity::class,
            parentColumns = ["id"],
            childColumns = ["folderId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("folderId"), Index(value = ["uid"], unique = true)]
)
data class LessonMaterialEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val folderId: Long,
    val displayName: String,
    val storedFileName: String,
    val mimeType: String = "application/octet-stream",
    val sizeBytes: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val uid: String = java.util.UUID.randomUUID().toString()
)

@Entity(
    tableName = "lesson_templates",
    indices = [Index(value = ["name"], unique = true)]
)
data class LessonTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val useSecondClass: Boolean = false,
    val classASubject: String = "",
    val classAGrade: String = "",
    val classATopic: String = "",
    val classBSubject: String = "",
    val classBGrade: String = "",
    val classBTopic: String = "",
    val classAIndependentWorkLimit: String = "15",
    val classBIndependentWorkLimit: String = "15",
    val planMode: String = "Для себя",
    val additionalInstructions: String = "",
    val lessonDuration: String = "45",
    val lessonType: String = "Комбинированный",
    val updatedAt: Long = System.currentTimeMillis()
)

data class FolderPlanCount(
    val folderId: Long,
    val planCount: Int
)

data class PlanSearchResult(
    val id: Long,
    val folderId: Long,
    val title: String,
    val content: String,
    val isFavorite: Boolean,
    val tags: String,
    val timestamp: Long,
    val durationMinutes: Int,
    val folderName: String,
    val uid: String = "",
    val updatedAt: Long = timestamp,
    val sourcePlanUid: String? = null
) {
    fun asEntity() = LessonPlanEntity(
        id = id,
        folderId = folderId,
        title = title,
        content = content,
        isFavorite = isFavorite,
        tags = tags,
        timestamp = timestamp,
        durationMinutes = durationMinutes,
        uid = uid.ifBlank { java.util.UUID.randomUUID().toString() },
        updatedAt = updatedAt,
        sourcePlanUid = sourcePlanUid
    )
}
