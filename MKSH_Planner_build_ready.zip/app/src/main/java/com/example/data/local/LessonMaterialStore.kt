package com.example.data.local

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

object LessonMaterialStore {
    const val MAX_FILE_BYTES = 50L * 1024L * 1024L

    suspend fun import(context: Context, folderId: Long, uri: Uri): Result<LessonMaterialEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val metadata = queryMetadata(context, uri)
                if (metadata.sizeBytes > MAX_FILE_BYTES) {
                    error("Файл больше 50 МБ. Уменьшите его и попробуйте снова.")
                }
                val mimeType = context.contentResolver.getType(uri) ?: guessMimeType(metadata.displayName)
                if (!isSupportedLessonMaterial(metadata.displayName, mimeType)) {
                    error("Поддерживаются только PDF, DOC/DOCX и изображения.")
                }
                val materialsDir = File(context.filesDir, "lesson_materials").apply { mkdirs() }
                val extension = metadata.displayName.substringAfterLast('.', "")
                    .takeIf { extensionValue -> extensionValue.length in 1..10 && extensionValue.all { char -> char.isLetterOrDigit() } }
                val storedName = buildString {
                    append(UUID.randomUUID())
                    if (extension != null) append('.').append(extension.lowercase())
                }
                val target = File(materialsDir, storedName)
                try {
                    var total = 0L
                    val input = context.contentResolver.openInputStream(uri)
                        ?: error("Не удалось открыть выбранный материал.")
                    input.use { source ->
                        FileOutputStream(target).use { output ->
                            val buffer = ByteArray(16 * 1024)
                            while (true) {
                                val read = source.read(buffer)
                                if (read < 0) break
                                total += read
                                if (total > MAX_FILE_BYTES) {
                                    error("Файл больше 50 МБ. Уменьшите его и попробуйте снова.")
                                }
                                output.write(buffer, 0, read)
                            }
                        }
                    }
                    if (total == 0L) error("Выбранный файл пуст.")
                    LessonMaterialEntity(
                        folderId = folderId,
                        displayName = metadata.displayName,
                        storedFileName = storedName,
                        mimeType = mimeType,
                        sizeBytes = total
                    )
                } catch (error: Exception) {
                    target.delete()
                    throw error
                }
            }.onFailure { if (it is CancellationException) throw it }
        }

    fun file(context: Context, material: LessonMaterialEntity): File =
        File(File(context.filesDir, "lesson_materials"), material.storedFileName)

    fun deleteFile(context: Context, material: LessonMaterialEntity): Boolean =
        !file(context, material).exists() || file(context, material).delete()

    fun openIntent(context: Context, material: LessonMaterialEntity): Intent {
        val file = file(context, material)
        require(file.exists()) { "Материал не найден в памяти приложения." }
        val uri = FileProvider.getUriForFile(
            context,
            "com.aistudio.lessonplanner.xyazqw.fileprovider",
            file
        )
        return Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, material.mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    fun shareIntent(context: Context, material: LessonMaterialEntity): Intent {
        val file = file(context, material)
        require(file.exists()) { "Материал не найден в памяти приложения." }
        val uri = FileProvider.getUriForFile(
            context,
            "com.aistudio.lessonplanner.xyazqw.fileprovider",
            file
        )
        return Intent(Intent.ACTION_SEND).apply {
            type = material.mimeType
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    private data class SourceMetadata(val displayName: String, val sizeBytes: Long)

    private fun queryMetadata(context: Context, uri: Uri): SourceMetadata {
        var name = uri.lastPathSegment?.substringAfterLast('/') ?: "Материал"
        var size = -1L
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIndex >= 0) name = cursor.getString(nameIndex)?.takeIf { it.isNotBlank() } ?: name
                if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) size = cursor.getLong(sizeIndex)
            }
        }
        return SourceMetadata(name.take(180), size)
    }

    internal fun isSupportedLessonMaterial(name: String, mimeType: String): Boolean {
        if (mimeType.lowercase().startsWith("image/")) return true
        return when (name.substringAfterLast('.', "").lowercase()) {
            "pdf", "doc", "docx", "jpg", "jpeg", "png", "webp", "heic", "heif" -> true
            else -> mimeType.lowercase() in setOf(
                "application/pdf",
                "application/msword",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
        }
    }

    private fun guessMimeType(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "pdf" -> "application/pdf"
        "docx" -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        "doc" -> "application/msword"
        "xlsx" -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        "pptx" -> "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "heic", "heif" -> "image/heif"
        else -> "application/octet-stream"
    }
}
