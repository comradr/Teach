package com.example.data.local

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Locale

class PlannerRepository(private val plannerDao: PlannerDao) {

    val allFolders: Flow<List<FolderEntity>> = plannerDao.getAllFolders()
    val archivedFolders: Flow<List<FolderEntity>> = plannerDao.getArchivedFolders()
    val allTemplates: Flow<List<LessonTemplateEntity>> = plannerDao.getAllTemplates()
    val folderPlanCounts: Flow<List<FolderPlanCount>> = plannerDao.getFolderPlanCounts()
    val allPlansWithFolders: Flow<List<PlanSearchResult>> = plannerDao.observeAllPlansWithFolders()

    suspend fun insertFolder(name: String): Long {
        return plannerDao.insertFolder(FolderEntity(name = name))
    }
    
    suspend fun updateFolderArchiveStatus(folderId: Long, isArchived: Boolean) {
        plannerDao.updateFolderArchiveStatus(folderId, isArchived)
    }

    suspend fun getFolderByName(name: String): FolderEntity? {
        return plannerDao.getFolderByName(name)
    }

    suspend fun insertLessonPlan(
        folderId: Long,
        title: String,
        content: String,
        durationMinutes: Int = 45,
        sourcePlanUid: String? = null
    ): Long {
        return plannerDao.insertLessonPlan(
            LessonPlanEntity(
                folderId = folderId,
                title = title,
                content = content,
                durationMinutes = durationMinutes,
                sourcePlanUid = sourcePlanUid
            )
        )
    }

    fun getPlansForFolder(folderId: Long): Flow<List<LessonPlanEntity>> {
        return plannerDao.getPlansForFolder(folderId)
    }

    fun searchAllPlans(query: String): Flow<List<PlanSearchResult>> {
        val needle = query.trim().lowercase(Locale.ROOT)
        return allPlansWithFolders.map { plans ->
            if (needle.isBlank()) emptyList() else plans.filter { plan ->
                sequenceOf(plan.title, plan.content, plan.tags, plan.folderName)
                    .any { it.lowercase(Locale.ROOT).contains(needle) }
            }
        }
    }

    suspend fun getPlanById(planId: Long): LessonPlanEntity? {
        return plannerDao.getPlanById(planId)
    }

    suspend fun updateFavoriteStatus(planId: Long, isFavorite: Boolean) {
        plannerDao.updateFavoriteStatus(planId, isFavorite)
    }
    
    suspend fun updatePlanTags(planId: Long, tags: String) {
        plannerDao.updatePlanTags(planId, tags)
    }

    fun getFavoritePlans(): Flow<List<LessonPlanEntity>> {
        return plannerDao.getFavoritePlans()
    }

    
    suspend fun updateFolderName(folderId: Long, name: String) {
        plannerDao.updateFolderName(folderId, name)
    }

    suspend fun updatePlanTitle(planId: Long, title: String) {
        plannerDao.updatePlanTitle(planId, title)
    }

    suspend fun updatePlanContent(planId: Long, content: String) {
        plannerDao.updatePlanContent(planId, content)
    }

    suspend fun updatePlanProperties(planId: Long, title: String, tags: String) {
        plannerDao.updatePlanProperties(planId, title, tags)
    }

    suspend fun deletePlan(planId: Long)
 {
        plannerDao.deletePlan(planId)
    }

    suspend fun deleteFolder(folderId: Long) {
        plannerDao.deleteFolder(folderId)
    }

    suspend fun upsertTemplate(template: LessonTemplateEntity): Long =
        plannerDao.upsertTemplate(template.copy(name = template.name.trim(), updatedAt = System.currentTimeMillis()))

    suspend fun deleteTemplate(template: LessonTemplateEntity) {
        plannerDao.deleteTemplate(template)
    }

    fun observeFolder(folderId: Long): Flow<FolderEntity?> = plannerDao.observeFolder(folderId)

    fun getMaterialsForFolder(folderId: Long): Flow<List<LessonMaterialEntity>> =
        plannerDao.getMaterialsForFolder(folderId)

    suspend fun getMaterialsForFolderSnapshot(folderId: Long): List<LessonMaterialEntity> =
        plannerDao.getMaterialsForFolderSnapshot(folderId)

    suspend fun insertMaterial(material: LessonMaterialEntity): Long = plannerDao.insertMaterial(material)

    suspend fun updateMaterialName(materialId: Long, displayName: String) =
        plannerDao.updateMaterialName(materialId, displayName)

    suspend fun deleteMaterial(materialId: Long) = plannerDao.deleteMaterial(materialId)
}
