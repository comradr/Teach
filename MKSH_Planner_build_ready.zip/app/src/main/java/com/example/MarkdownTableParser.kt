package com.example

/** Splits a Markdown table row without treating an escaped `\|` inside a cell as a separator. */
fun splitMarkdownTableRow(line: String): List<String> {
    var value = line.trim()
    if (value.startsWith('|')) value = value.drop(1)
    if (value.endsWith('|') && !value.endsWith("\\|")) value = value.dropLast(1)

    val cells = mutableListOf<String>()
    val cell = StringBuilder()
    var index = 0
    while (index < value.length) {
        val char = value[index]
        if (char == '\\' && index + 1 < value.length && value[index + 1] == '|') {
            cell.append('|')
            index += 2
            continue
        }
        if (char == '|') {
            cells += cell.toString().trim()
            cell.clear()
        } else {
            cell.append(char)
        }
        index++
    }
    cells += cell.toString().trim()
    return cells
}
