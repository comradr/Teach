package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.LessonPlanEntity
import com.example.data.local.LessonMaterialEntity
import com.example.data.local.LessonMaterialStore
import com.example.data.local.FolderEntity
import com.example.data.local.PlannerDatabase
import com.example.data.local.PlannerRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class LessonPlanListViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PlannerRepository
    private val _plans = MutableStateFlow<List<LessonPlanEntity>>(emptyList())
    val plans: StateFlow<List<LessonPlanEntity>> = _plans.asStateFlow()
    private var loadJob: Job? = null
    private var materialsJob: Job? = null
    private var folderJob: Job? = null
    private val _materials = MutableStateFlow<List<LessonMaterialEntity>>(emptyList())
    val materials: StateFlow<List<LessonMaterialEntity>> = _materials.asStateFlow()
    private val _folder = MutableStateFlow<FolderEntity?>(null)
    val folder: StateFlow<FolderEntity?> = _folder.asStateFlow()

    init {
        val plannerDao = PlannerDatabase.getDatabase(application).plannerDao()
        repository = PlannerRepository(plannerDao)
    }

    fun loadPlans(folderId: Long) {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            repository.getPlansForFolder(folderId).collect {
                _plans.value = it
            }
        }
        materialsJob?.cancel()
        materialsJob = viewModelScope.launch {
            repository.getMaterialsForFolder(folderId).collect { _materials.value = it }
        }
        folderJob?.cancel()
        folderJob = viewModelScope.launch {
            repository.observeFolder(folderId).collect { _folder.value = it }
        }
    }

    fun loadFavoritePlans() {
        loadJob?.cancel()
        loadJob = viewModelScope.launch {
            repository.getFavoritePlans().collect {
                _plans.value = it
            }
        }
    }

    fun toggleFavorite(planId: Long, isFavorite: Boolean) {
        viewModelScope.launch {
            repository.updateFavoriteStatus(planId, isFavorite)
        }
    }

    fun deletePlan(planId: Long) {
        viewModelScope.launch {
            repository.deletePlan(planId)
            PlanEditDraftStore(getApplication()).clear(planId)
        }
    }
    
    fun renamePlan(planId: Long, newTitle: String) {
        viewModelScope.launch {
            if (newTitle.isNotBlank()) {
                repository.updatePlanTitle(planId, newTitle)
            }
        }
    }

    fun updatePlanProperties(planId: Long, newTitle: String, tags: String) {
        viewModelScope.launch {
            if (newTitle.isNotBlank()) repository.updatePlanProperties(planId, newTitle.trim(), tags.trim())
        }
    }
    
    fun updatePlanContent(planId: Long, newContent: String) {
        viewModelScope.launch {
            repository.updatePlanContent(planId, newContent)
        }
    }

    fun importPlan(
        folderId: Long,
        title: String,
        content: String,
        onImported: (Long) -> Unit = {}
    ) {
        viewModelScope.launch {
            val id = repository.insertLessonPlan(folderId, title.trim(), content)
            onImported(id)
        }
    }

    fun addMaterial(
        context: android.content.Context,
        folderId: Long,
        uri: android.net.Uri,
        onResult: (Result<LessonMaterialEntity>) -> Unit
    ) {
        viewModelScope.launch {
            val result = LessonMaterialStore.import(context.applicationContext, folderId, uri)
            result.onSuccess { material ->
                try {
                    repository.insertMaterial(material)
                    onResult(Result.success(material))
                } catch (error: CancellationException) {
                    withContext(Dispatchers.IO) { LessonMaterialStore.deleteFile(context, material) }
                    throw error
                } catch (error: Exception) {
                    withContext(Dispatchers.IO) { LessonMaterialStore.deleteFile(context, material) }
                    onResult(Result.failure(error))
                }
            }.onFailure { onResult(Result.failure(it)) }
        }
    }

    fun renameMaterial(materialId: Long, displayName: String) {
        viewModelScope.launch {
            if (displayName.isNotBlank()) repository.updateMaterialName(materialId, displayName.trim())
        }
    }

    fun deleteMaterial(context: android.content.Context, material: LessonMaterialEntity) {
        viewModelScope.launch {
            repository.deleteMaterial(material.id)
            withContext(Dispatchers.IO) { LessonMaterialStore.deleteFile(context.applicationContext, material) }
        }
    }
}
