package com.example

const val MAX_MATERIAL_PHOTOS_PER_CLASS = 5

fun remainingMaterialPhotoSlots(currentCount: Int): Int =
    (MAX_MATERIAL_PHOTOS_PER_CLASS - currentCount).coerceAtLeast(0)

fun moveDraftImage(images: List<DraftLessonImage>, fromIndex: Int, toIndex: Int): List<DraftLessonImage> {
    if (fromIndex !in images.indices || toIndex !in images.indices || fromIndex == toIndex) return images
    return images.toMutableList().apply {
        add(toIndex, removeAt(fromIndex))
    }
}
