package com.example

data class PrintableCard(
    val topic: String?,
    val bodyMarkdown: String
)

private val printableCardBoundary = Regex("(?m)^###\\s+(.+?)\\s*$")
private val printableTopicLine = Regex("(?i)^Тема(?:\\s+урока)?\\s*:\\s*(.+)$")

fun extractPrintableCards(content: String): List<PrintableCard> {
    val cardSections = outermostSections(findMarkdownSections(content, "Карточка"))
    val independentSections = findMarkdownSections(content, "Материалы для самостоятельной работы")
    val sections = (if (cardSections.isNotEmpty()) cardSections else independentSections)
        .distinctBy { it.start }
        .sortedBy { it.start }

    val fallbackTopics = extractTopicsBeforeCards(content, sections.firstOrNull()?.start ?: content.length)
    val blocks = if (sections.isEmpty()) {
        listOf(content)
    } else {
        sections.flatMap { section -> splitPrintableCardSection(section.text) }
    }

    return blocks.mapIndexedNotNull { index, block ->
        var topic: String? = null
        val body = block.lineSequence().mapNotNull { rawLine ->
            val line = rawLine.trimEnd()
            val plain = line
                .replace(Regex("^#{1,6}\\s+"), "")
                .replace("**", "")
                .trim()

            when {
                plain.contains("карточк", ignoreCase = true) && line.trimStart().startsWith("#") -> null
                plain.startsWith("Класс", ignoreCase = true) && line.trimStart().startsWith("#") -> null
                plain.startsWith("Предмет:", ignoreCase = true) -> null
                printableTopicLine.matches(plain) -> {
                    topic = printableTopicLine.matchEntire(plain)?.groupValues?.get(1)?.trim()
                    null
                }
                else -> line
            }
        }.joinToString("\n").trim()

        if (body.isBlank()) null else PrintableCard(
            topic = topic?.takeIf { it.isNotBlank() } ?: fallbackTopics.getOrNull(index) ?: fallbackTopics.firstOrNull(),
            bodyMarkdown = body
        )
    }
}

private fun outermostSections(sections: List<MarkdownSection>): List<MarkdownSection> {
    val minimumLevel = sections.minOfOrNull { it.level } ?: return emptyList()
    return sections.filter { it.level == minimumLevel }
}

private fun splitPrintableCardSection(sectionText: String): List<String> {
    val withoutSectionHeading = sectionText.lineSequence().drop(1).joinToString("\n").trim()
    if (withoutSectionHeading.isBlank()) return emptyList()

    val boundaries = printableCardBoundary.findAll(withoutSectionHeading)
        .filter { match ->
            val title = match.groupValues[1]
            title.contains("класс", ignoreCase = true) || title.contains("карточк", ignoreCase = true)
        }
        .toList()
    if (boundaries.isEmpty()) return listOf(withoutSectionHeading)

    return boundaries.mapIndexed { index, match ->
        val start = match.range.last + 1
        val end = boundaries.getOrNull(index + 1)?.range?.first ?: withoutSectionHeading.length
        withoutSectionHeading.substring(start, end).trim()
    }.filter { it.isNotBlank() }
}

private fun extractTopicsBeforeCards(content: String, cardStart: Int): List<String> =
    content.substring(0, cardStart).lineSequence().mapNotNull { rawLine ->
        val plain = rawLine
            .replace(Regex("^#{1,6}\\s+"), "")
            .replace("**", "")
            .trim()
        printableTopicLine.matchEntire(plain)?.groupValues?.get(1)?.trim()
    }.filter { it.isNotBlank() }.distinct().toList()

fun extractCardsForPrinting(content: String): String {
    val cardSections = outermostSections(findMarkdownSections(content, "Карточка"))
    val independentSections = findMarkdownSections(content, "Материалы для самостоятельной работы")

    // Prefer explicit printable cards. Older plans may only have a general
    // "Материалы для самостоятельной работы" section, so keep it as fallback.
    val sections = (if (cardSections.isNotEmpty()) cardSections else independentSections)
        .distinctBy { it.start }
        .sortedBy { it.start }

    return if (sections.isNotEmpty()) {
        sections.joinToString("\n\n<hr>\n\n") { it.text.trim() }
    } else {
        content
    }
}

fun extractAnswersForPrinting(content: String): String? {
    val sections = outermostSections(findMarkdownSections(content, "Ответы учителю"))
        .sortedBy { it.start }
    if (sections.isEmpty()) return null
    return sections.joinToString("\n\n") { section ->
        section.text.lineSequence().drop(1).joinToString("\n").trim()
    }.trim().takeIf { it.isNotBlank() }
}

fun removeStudentCardsAndAnswers(content: String): String {
    val explicitCards = outermostSections(findMarkdownSections(content, "Карточка"))
    val fallbackCards = if (explicitCards.isEmpty()) {
        outermostSections(findMarkdownSections(content, "Материалы для самостоятельной работы"))
    } else {
        emptyList()
    }
    val answers = outermostSections(findMarkdownSections(content, "Ответы учителю"))
    val ranges = (explicitCards + fallbackCards + answers)
        .distinctBy { it.start to it.end }
        .sortedByDescending { it.start }

    var result = content
    ranges.forEach { section -> result = result.removeRange(section.start, section.end) }
    return result.replace(Regex("\n{3,}"), "\n\n").trim()
}
