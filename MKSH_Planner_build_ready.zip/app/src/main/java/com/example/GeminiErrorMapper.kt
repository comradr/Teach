package com.example

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import retrofit2.HttpException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

@Serializable
private data class GoogleErrorEnvelope(val error: GoogleError? = null)

@Serializable
private data class GoogleError(val code: Int? = null, val message: String? = null, val status: String? = null)

object GeminiErrorMapper {
    private const val MAX_ERROR_BODY_BYTES = 256L * 1024L
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val retryDelayPattern = Regex("""\"retryDelay\"\s*:\s*\"(\d+(?:\.\d+)?)s\"""")

    fun fromHttp(exception: HttpException, hasImages: Boolean = false): String {
        val body = peekErrorBody(exception)
        val detail = parseMessage(body)
        val normalized = (detail + " " + body).lowercase()

        return when (exception.code()) {
            400 -> when {
                normalized.contains("api key") || normalized.contains("api_key") || normalized.contains("key not valid") ->
                    "API-ключ Gemini недействителен. Проверьте GEMINI_API_KEY в .env или в секрете сборки и пересоберите приложение."
                normalized.contains("quota") || normalized.contains("billing") ->
                    "Для этого API-ключа недоступен запрос Gemini. Проверьте квоту и настройки проекта Google AI."
                isLocationUnsupportedText(normalized) ->
                    "Google Gemini отклонил соединение из-за определения региона. Приложение уже попробовало повторить запрос через IPv4. Попробуйте другую сеть или VPN-сервер в поддерживаемом регионе."
                hasImages && (normalized.contains("image") || normalized.contains("mime") || normalized.contains("inline") || normalized.contains("media")) ->
                    "Gemini не смог обработать прикреплённое изображение. Попробуйте другое фото или уменьшите его размер."
                else -> friendlyBadRequest(detail)
            }
            401, 403 -> "Нет доступа к Gemini. Проверьте GEMINI_API_KEY и разрешения API-ключа."
            404 -> "Модель Gemini сейчас недоступна для этого API-ключа. Попробуйте обновить приложение или выбрать другой ключ."
            408 -> "Gemini слишком долго отвечал. Повторите запрос."
            429 -> rateLimitMessage(normalized, retryDelaySeconds(exception))
            500, 502, 503, 504 -> "Gemini временно недоступен. Повторите запрос чуть позже."
            else -> if (detail.isNotBlank()) "Ошибка Gemini (${exception.code()}): ${detail.take(220)}" else "Ошибка Gemini (${exception.code()})."
        }
    }

    fun isLocationUnsupported(exception: HttpException): Boolean {
        if (exception.code() != 400 && exception.code() != 403) return false
        return isLocationUnsupportedText(peekErrorBody(exception).lowercase())
    }

    /** True only for a short-lived limit that can realistically recover during this request. */
    internal fun shouldRetry(exception: HttpException): Boolean {
        if (exception.code() in 500..599) return true
        if (exception.code() != 429) return false
        val normalized = peekErrorBody(exception).lowercase()
        val persistentLimit = normalized.contains("perday") ||
            normalized.contains("per_day") ||
            normalized.contains("per day") ||
            normalized.contains("daily quota") ||
            normalized.contains("quota_exceeded") ||
            normalized.contains("billing") ||
            normalized.contains("spend") ||
            normalized.contains("\"quotavalue\":\"0\"")
        val requestedWait = retryDelaySeconds(exception)
        return !persistentLimit && (requestedWait == null || requestedWait <= 8L)
    }

    internal fun retryDelayMillis(exception: HttpException, attempt: Int): Long {
        val serverSeconds = retryDelaySeconds(exception)
        if (serverSeconds != null) return (serverSeconds * 1_000L).coerceIn(1_000L, 8_000L)
        return listOf(1_000L, 2_000L, 4_000L)[attempt.coerceIn(0, 2)]
    }

    internal fun isLocationUnsupportedText(text: String): Boolean {
        val normalized = text.lowercase()
        return normalized.contains("user location is not supported") ||
            (normalized.contains("location") && normalized.contains("not supported") && normalized.contains("api"))
    }

    fun fromException(exception: Exception): String = when (exception) {
        is HttpException -> fromHttp(exception)
        is UnknownHostException -> "Нет подключения к интернету."
        is SocketTimeoutException -> "Gemini не ответил вовремя. Проверьте интернет и повторите запрос."
        else -> {
            val message = exception.localizedMessage.orEmpty().lowercase()
            when {
                message.contains("timeout") -> "Gemini не ответил вовремя. Проверьте интернет и повторите запрос."
                message.contains("connect") -> "Не удалось подключиться к Gemini. Проверьте интернет."
                else -> "Не удалось выполнить запрос Gemini. Повторите попытку."
            }
        }
    }

    private fun peekErrorBody(exception: HttpException): String {
        return try {
            val errorBody = exception.response()?.errorBody()
            if (errorBody != null) {
                val source = errorBody.source()
                source.request(MAX_ERROR_BODY_BYTES)
                val copy = source.buffer.clone()
                copy.readUtf8(minOf(copy.size, MAX_ERROR_BODY_BYTES))
            } else {
                exception.response()?.raw()?.peekBody(MAX_ERROR_BODY_BYTES)?.string().orEmpty()
            }
        } catch (_: Exception) {
            ""
        }
    }

    private fun parseMessage(body: String): String {
        if (body.isBlank()) return ""
        return try {
            json.decodeFromString<GoogleErrorEnvelope>(body).error?.message.orEmpty().trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun retryDelaySeconds(exception: HttpException): Long? {
        val headerSeconds = exception.response()?.headers()?.get("Retry-After")?.trim()?.toLongOrNull()
        if (headerSeconds != null) return headerSeconds
        val raw = retryDelayPattern.find(peekErrorBody(exception))?.groupValues?.getOrNull(1)
        return raw?.toDoubleOrNull()?.toLong()
    }

    private fun rateLimitMessage(normalized: String, retryDelaySeconds: Long?): String {
        val wait = retryDelaySeconds?.takeIf { it in 1..120 }?.let { " Повторите примерно через $it сек." }.orEmpty()
        return when {
            normalized.contains("perday") || normalized.contains("per_day") ||
                normalized.contains("per day") || normalized.contains("daily quota") ||
                normalized.contains("quota_exceeded") ->
                "Дневная квота Gemini закончилась. Дождитесь её обновления или увеличьте лимит проекта Google AI."
            normalized.contains("spend") ->
                "Достигнут лимит расходов Gemini для проекта. Подождите или проверьте лимиты оплаты в Google AI."
            normalized.contains("billing") || normalized.contains("\"quotavalue\":\"0\"") ->
                "Для проекта сейчас нет доступной квоты Gemini. Проверьте квоту и оплату проекта Google AI."
            normalized.contains("perminute") || normalized.contains("per_minute") ||
                normalized.contains("per minute") || normalized.contains("rate_limit") ||
                normalized.contains("too many requests") ->
                "Слишком много запросов к Gemini за короткое время.$wait"
            else ->
                "Gemini ограничил запрос по квоте проекта.$wait Если ошибка повторяется сразу, проверьте квоту и оплату в Google AI."
        }
    }

    private fun friendlyBadRequest(detail: String): String {
        if (detail.isBlank()) return "Gemini отклонил запрос. Проверьте API-ключ и параметры урока."
        return "Gemini отклонил запрос: ${detail.replace('\n', ' ').take(220)}"
    }
}
