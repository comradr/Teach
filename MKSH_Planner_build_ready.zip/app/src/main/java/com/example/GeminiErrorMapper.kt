package com.example

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import retrofit2.HttpException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

@Serializable
private data class GoogleErrorEnvelope(val error: GoogleError? = null)

@Serializable
private data class GoogleError(val code: Int? = null, val message: String? = null, val status: String? = null)

object GeminiErrorMapper {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    fun fromHttp(exception: HttpException, hasImages: Boolean = false): String {
        val body = peekErrorBody(exception)
        val detail = parseMessage(body)
        val normalized = (detail + " " + body).lowercase()

        return when (exception.code()) {
            400 -> when {
                normalized.contains("api key") || normalized.contains("api_key") || normalized.contains("key not valid") ->
                    "API-ключ Gemini недействителен. Проверьте GEMINI_API_KEY в .env или в секрете сборки и пересоберите приложение."
                normalized.contains("quota") || normalized.contains("billing") ->
                    "Для этого API-ключа недоступен запрос Gemini. Проверьте квоту и настройки проекта Google AI."
                isLocationUnsupportedText(normalized) ->
                    "Google Gemini отклонил соединение из-за определения региона. Приложение уже попробовало повторить запрос через IPv4. Попробуйте другую сеть или VPN-сервер в поддерживаемом регионе."
                hasImages && (normalized.contains("image") || normalized.contains("mime") || normalized.contains("inline") || normalized.contains("media")) ->
                    "Gemini не смог обработать прикреплённое изображение. Попробуйте другое фото или уменьшите его размер."
                else -> friendlyBadRequest(detail)
            }
            401, 403 -> "Нет доступа к Gemini. Проверьте GEMINI_API_KEY и разрешения API-ключа."
            404 -> "Модель Gemini сейчас недоступна для этого API-ключа. Попробуйте обновить приложение или выбрать другой ключ."
            408 -> "Gemini слишком долго отвечал. Повторите запрос."
            429 -> "Достигнут лимит Gemini. Подождите немного и повторите запрос."
            500, 502, 503, 504 -> "Gemini временно недоступен. Повторите запрос чуть позже."
            else -> if (detail.isNotBlank()) "Ошибка Gemini (${exception.code()}): ${detail.take(220)}" else "Ошибка Gemini (${exception.code()})."
        }
    }

    fun isLocationUnsupported(exception: HttpException): Boolean {
        if (exception.code() != 400 && exception.code() != 403) return false
        return isLocationUnsupportedText(peekErrorBody(exception).lowercase())
    }

    internal fun isLocationUnsupportedText(text: String): Boolean {
        val normalized = text.lowercase()
        return normalized.contains("user location is not supported") ||
            (normalized.contains("location") && normalized.contains("not supported") && normalized.contains("api"))
    }

    fun fromException(exception: Exception): String = when (exception) {
        is HttpException -> fromHttp(exception)
        is UnknownHostException -> "Нет подключения к интернету."
        is SocketTimeoutException -> "Gemini не ответил вовремя. Проверьте интернет и повторите запрос."
        else -> {
            val message = exception.localizedMessage.orEmpty().lowercase()
            when {
                message.contains("timeout") -> "Gemini не ответил вовремя. Проверьте интернет и повторите запрос."
                message.contains("connect") -> "Не удалось подключиться к Gemini. Проверьте интернет."
                else -> "Не удалось выполнить запрос Gemini. Повторите попытку."
            }
        }
    }

    private fun peekErrorBody(exception: HttpException): String {
        return try {
            exception.response()?.raw()?.peekBody(256 * 1024)?.string().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private fun parseMessage(body: String): String {
        if (body.isBlank()) return ""
        return try {
            json.decodeFromString<GoogleErrorEnvelope>(body).error?.message.orEmpty().trim()
        } catch (_: Exception) {
            ""
        }
    }

    private fun friendlyBadRequest(detail: String): String {
        if (detail.isBlank()) return "Gemini отклонил запрос. Проверьте API-ключ и параметры урока."
        return "Gemini отклонил запрос: ${detail.replace('\n', ' ').take(220)}"
    }
}
