package com.example

object GeminiLessonPartsBuilder {

    fun buildParts(
        useSecondClass: Boolean,
        classAImages: List<DraftLessonImage>,
        classBImages: List<DraftLessonImage>,
        userPrompt: String,
        classAImportedPlan: ImportedLessonPlan? = null,
        classBImportedPlan: ImportedLessonPlan? = null
    ): List<Part> {
        val parts = mutableListOf<Part>(Part(text = userPrompt))
        val classAParts = imageParts(classAImages)
        val classBParts = imageParts(classBImages)

        if (useSecondClass) {
            classAImportedPlan?.let { parts.add(oldPlanPart(it, "КЛАССА 1", classAParts.isNotEmpty())) }
            if (classAParts.isNotEmpty()) {
                parts.add(Part(text = "НОВЫЕ МАТЕРИАЛЫ КЛАССА 1.\nСледующие ${classAParts.size} фото относятся ТОЛЬКО к Классу 1 и идут в порядке страниц учебника. Они имеют приоритет над заданиями и номерами страниц из старого плана: сохрани основу старого плана, но актуальные упражнения возьми с фото.\nНе используй их для Класса 2."))
                parts.addAll(classAParts)
            }
            classBImportedPlan?.let { parts.add(oldPlanPart(it, "КЛАССА 2", classBParts.isNotEmpty())) }
            if (classBParts.isNotEmpty()) {
                parts.add(Part(text = "НОВЫЕ МАТЕРИАЛЫ КЛАССА 2.\nСледующие ${classBParts.size} фото относятся ТОЛЬКО к Классу 2 и идут в порядке страниц учебника. Они имеют приоритет над заданиями и номерами страниц из старого плана: сохрани основу старого плана, но актуальные упражнения возьми с фото.\nНе используй их для Класса 1."))
                parts.addAll(classBParts)
            }
        } else {
            classAImportedPlan?.let { parts.add(oldPlanPart(it, "К УРОКУ", classAParts.isNotEmpty())) }
            if (classAParts.isNotEmpty()) {
                parts.add(Part(text = "НОВЫЕ МАТЕРИАЛЫ К УРОКУ.\nСледующие ${classAParts.size} фото идут в порядке страниц учебника. Они имеют приоритет над заданиями и номерами страниц из старого плана: сохрани методическую основу, но обнови упражнения по фото."))
                parts.addAll(classAParts)
            }
        }

        return parts
    }

    private fun imageParts(images: List<DraftLessonImage>): List<Part> = images.mapNotNull { image ->
        ImageOptimizer.getBase64FromPath(image.path)?.let { base64 ->
            Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64))
        }
    }

    private fun oldPlanPart(plan: ImportedLessonPlan, label: String, hasNewPhotos: Boolean): Part {
        val photoRule = if (hasNewPhotos) {
            "После этого документа приложены новые фото учебника. Не копируй устаревшие упражнения механически: фото главнее для конкретных заданий, формулировок и страниц."
        } else {
            "Новых фото для этого класса нет: используй документ как основную содержательную опору и аккуратно приведи его к требуемому формату."
        }
        return Part(
            text = """
                СТАРЫЙ ГОТОВЫЙ ПЛАН $label (${plan.fileName}).
                Сохрани его полезную основу: тему, цели, последовательность, методы и удачные этапы. Перестрой временную схему под текущую длительность и формат ${if (label.contains("КЛАССА")) "МКШ" else "урока"}.
                $photoRule

                НАЧАЛО СТАРОГО ПЛАНА
                ${plan.text}
                КОНЕЦ СТАРОГО ПЛАНА
            """.trimIndent()
        )
    }
}
