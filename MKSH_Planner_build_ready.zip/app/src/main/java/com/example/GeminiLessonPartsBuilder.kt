package com.example

object GeminiLessonPartsBuilder {

    fun buildParts(
        useSecondClass: Boolean,
        classAImages: List<DraftLessonImage>,
        classBImages: List<DraftLessonImage>,
        userPrompt: String
    ): List<Part> {
        val parts = mutableListOf<Part>(Part(text = userPrompt))
        val classAParts = imageParts(classAImages)
        val classBParts = imageParts(classBImages)

        if (useSecondClass) {
            if (classAParts.isNotEmpty()) {
                parts.add(Part(text = "МАТЕРИАЛЫ КЛАССА 1.\nСледующие изображения относятся ТОЛЬКО к Классу 1.\nНе используй их для Класса 2."))
                parts.addAll(classAParts)
            }
            if (classBParts.isNotEmpty()) {
                parts.add(Part(text = "МАТЕРИАЛЫ КЛАССА 2.\nСледующие изображения относятся ТОЛЬКО к Классу 2.\nНе используй их для Класса 1."))
                parts.addAll(classBParts)
            }
        } else {
            parts.addAll(classAParts)
        }

        return parts
    }

    private fun imageParts(images: List<DraftLessonImage>): List<Part> = images.mapNotNull { image ->
        ImageOptimizer.getBase64FromPath(image.path)?.let { base64 ->
            Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64))
        }
    }
}
