package com.example

object GeminiLessonPartsBuilder {

    fun buildParts(
        useSecondClass: Boolean,
        classAImages: List<DraftLessonImage>,
        classBImages: List<DraftLessonImage>,
        userPrompt: String,
        classAImportedPlan: ImportedLessonPlan? = null,
        classBImportedPlan: ImportedLessonPlan? = null,
        materialUpdateMode: String = "Обновить задания по фото"
    ): List<Part> {
        val parts = mutableListOf<Part>(Part(text = userPrompt))
        val classAParts = imageParts(classAImages)
        val classBParts = imageParts(classBImages)
        val materialRule = when (materialUpdateMode) {
            "Дополнить план материалами" -> "Сохрани существующие задания и дополни их содержанием фото там, где оно подходит."
            "Сохранить основу строго" -> "Используй фото как уточнение; не заменяй этапы старого плана без прямой необходимости."
            else -> "Замени по фото только соответствующие упражнения, формулировки и страницы; остальные удачные задания старого плана сохрани."
        }

        if (useSecondClass) {
            classAImportedPlan?.let { parts.add(oldPlanPart(it, "КЛАССА 1", classAParts.isNotEmpty(), materialUpdateMode)) }
            if (classAParts.isNotEmpty()) {
                parts.add(Part(text = "НОВЫЕ МАТЕРИАЛЫ КЛАССА 1.\nСледующие ${classAParts.size} фото относятся ТОЛЬКО к Классу 1 и идут в порядке страниц учебника. $materialRule\nНе используй их для Класса 2."))
                parts.addAll(classAParts)
            }
            classBImportedPlan?.let { parts.add(oldPlanPart(it, "КЛАССА 2", classBParts.isNotEmpty(), materialUpdateMode)) }
            if (classBParts.isNotEmpty()) {
                parts.add(Part(text = "НОВЫЕ МАТЕРИАЛЫ КЛАССА 2.\nСледующие ${classBParts.size} фото относятся ТОЛЬКО к Классу 2 и идут в порядке страниц учебника. $materialRule\nНе используй их для Класса 1."))
                parts.addAll(classBParts)
            }
        } else {
            classAImportedPlan?.let { parts.add(oldPlanPart(it, "К УРОКУ", classAParts.isNotEmpty(), materialUpdateMode)) }
            if (classAParts.isNotEmpty()) {
                parts.add(Part(text = "НОВЫЕ МАТЕРИАЛЫ К УРОКУ.\nСледующие ${classAParts.size} фото идут в порядке страниц учебника. $materialRule"))
                parts.addAll(classAParts)
            }
        }

        return parts
    }

    private fun imageParts(images: List<DraftLessonImage>): List<Part> = images.mapNotNull { image ->
        ImageOptimizer.getBase64FromPath(image.path)?.let { base64 ->
            Part(inlineData = InlineData(mimeType = "image/jpeg", data = base64))
        }
    }

    private fun oldPlanPart(plan: ImportedLessonPlan, label: String, hasNewPhotos: Boolean, materialUpdateMode: String): Part {
        val promptText = plan.text.take(DocxLessonPlanImporter.MAX_IMPORTED_PLAN_CHARS)
        val truncationRule = if (plan.text.length > promptText.length) {
            "Для запроса показана первая часть очень длинного документа; полный исходный текст остаётся в черновике приложения без обрезки. Не выдумывай содержание отсутствующего фрагмента."
        } else {
            ""
        }
        val photoRule = if (hasNewPhotos) {
            when (materialUpdateMode) {
                "Дополнить план материалами" -> "После документа приложены новые фото. Сохрани существующие задания и дополни их материалами с фото там, где они действительно подходят."
                "Сохранить основу строго" -> "После документа приложены новые фото. Сохрани основу и задания максимально строго; используй фото как уточнение и не заменяй этапы без прямой необходимости."
                else -> "После документа приложены новые фото. Замени по ним только соответствующие задания, формулировки и страницы; остальные упражнения старого плана сохрани."
            }
        } else {
            "Новых фото для этого класса нет: используй документ как основную содержательную опору и аккуратно приведи его к требуемому формату."
        }
        return Part(
            text = """
                СТАРЫЙ ГОТОВЫЙ ПЛАН $label (${plan.fileName}).
                Сохрани его полезную основу: тему, цели, последовательность, методы и удачные этапы. Перестрой временную схему под текущую длительность и формат ${if (label.contains("КЛАССА")) "МКШ" else "урока"}.
                $photoRule
                $truncationRule

                НАЧАЛО СТАРОГО ПЛАНА
                $promptText
                КОНЕЦ СТАРОГО ПЛАНА
            """.trimIndent()
        )
    }
}
