package com.example.data.local

import com.example.lessonMaterialMimeTypes
import com.example.lessonPlanMimeTypes
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LessonMaterialPolicyTest {
    @Test
    fun folderEntryPointsUseSeparatedMimePolicies() {
        assertEquals(
            setOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword"),
            lessonPlanMimeTypes().toSet()
        )
        assertEquals(
            setOf(
                "application/pdf",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/msword",
                "image/*"
            ),
            lessonMaterialMimeTypes().toSet()
        )
    }

    @Test
    fun acceptsOnlyAgreedLessonMaterialTypes() {
        assertTrue(LessonMaterialStore.isSupportedLessonMaterial("лист.pdf", "application/pdf"))
        assertTrue(LessonMaterialStore.isSupportedLessonMaterial("план.doc", "application/msword"))
        assertTrue(
            LessonMaterialStore.isSupportedLessonMaterial(
                "план.docx",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            )
        )
        assertTrue(LessonMaterialStore.isSupportedLessonMaterial("страница.webp", "image/webp"))
        assertFalse(LessonMaterialStore.isSupportedLessonMaterial("таблица.xlsx", "application/octet-stream"))
        assertFalse(LessonMaterialStore.isSupportedLessonMaterial("архив.zip", "application/zip"))
    }

    @Test
    fun backupExtensionCannotEscapeMaterialsDirectory() {
        assertEquals("docx", safeBackupMaterialExtension("План.DOCX"))
        assertNull(safeBackupMaterialExtension("подмена../outside"))
        assertNull(safeBackupMaterialExtension("файл.bad-ext"))
        assertNull(safeBackupMaterialExtension("файл.слишкомдлинноерасширение"))
    }
}
