package com.example

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ImportedPlanLogicTest {
    @Test
    fun importedPlanBecomesEditableStoredMarkdown() {
        val markdown = importedPlanMarkdown(
            "Старый урок",
            ImportedLessonPlan("old.docx", "Тема: Сложение\nХод урока")
        )

        assertTrue(markdown.startsWith("# Старый урок"))
        assertTrue(markdown.contains("Тема: Сложение"))
    }

    @Test
    fun printExtractionPlacesAnswersOutsideStudentCard() {
        val markdown = """
            ## Карточка — ученику
            1. Задание
            ## Ответы учителю
            1. Ответ
        """.trimIndent()

        val card = extractPrintableCards(markdown).single()
        assertFalse(card.bodyMarkdown.contains("Ответ"))
        assertTrue(extractAnswersForPrinting(markdown)!!.contains("Ответ"))
        val teacher = removeStudentCardsAndAnswers("## Ход\nЭтап\n\n$markdown")
        assertTrue(teacher.contains("Этап"))
        assertFalse(teacher.contains("Задание"))
        assertFalse(teacher.contains("Ответ"))
    }

    @Test
    fun oldPlanPromptMakesNewPhotosAuthoritative() {
        val plan = ImportedLessonPlan("русский.docx", "Старая основа")
        val parts = GeminiLessonPartsBuilder.buildParts(
            useSecondClass = true,
            classAImages = emptyList(),
            classBImages = emptyList(),
            userPrompt = "Создай МКШ",
            classAImportedPlan = plan
        )

        val prompt = parts.mapNotNull { it.text }.joinToString("\n")
        assertTrue(prompt.contains("СТАРЫЙ ГОТОВЫЙ ПЛАН КЛАССА 1"))
        assertTrue(prompt.contains("Старая основа"))
        assertTrue(prompt.contains("основную содержательную опору"))
    }
}
