package com.example

import org.junit.Test
import org.junit.Assert.*

class CardExtractorTest {
    @Test
    fun testExtractCards() {
        val content = """
            # План урока
            Текст
            ## Карточка — ученику
            Пример 1
            ## Ответы учителю
            Пример 2
        """.trimIndent()
        val cards = extractCardsForPrinting(content)
        assertTrue(cards.contains("Карточка"))
        assertTrue(cards.contains("Пример 1"))
        assertFalse(cards.contains("Ответы учителю"))
        assertFalse(cards.contains("Пример 2"))
    }

    @Test
    fun testNestedClassHeadingsStayInsideCard() {
        val content = """
            # План урока
            ## Карточка — ученику
            ### Класс 1
            1. Задание А
            ### Класс 2
            1. Задание Б
            ## Ответы учителю
            Ответы
        """.trimIndent()

        val cards = extractCardsForPrinting(content)
        assertTrue(cards.contains("### Класс 1"))
        assertTrue(cards.contains("Задание А"))
        assertTrue(cards.contains("### Класс 2"))
        assertTrue(cards.contains("Задание Б"))
        assertFalse(cards.contains("Ответы учителю"))
    }

    @Test
    fun printableCardsRemoveServiceHeadingsAndSubjects() {
        val content = """
            # План МКШ
            ## Карточка — ученику
            ### Карточка 1 (Класс 1)
            Предмет: Математика
            Тема: Сложение
            1. Реши пример
            ### Карточка 2 (Класс 2)
            **Предмет:** Русский язык
            **Тема:** Словосочетание
            1. Составь предложение
            ## Ответы учителю
            Ответы
        """.trimIndent()

        val cards = extractPrintableCards(content)
        assertEquals(2, cards.size)
        assertEquals("Сложение", cards[0].topic)
        assertEquals("Словосочетание", cards[1].topic)
        assertFalse(cards.any { it.bodyMarkdown.contains("Предмет") })
        assertTrue(cards[0].bodyMarkdown.contains("Реши пример"))
        assertTrue(cards[1].bodyMarkdown.contains("Составь предложение"))
    }
}
