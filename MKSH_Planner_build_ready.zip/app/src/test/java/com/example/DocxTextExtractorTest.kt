package com.example

import org.junit.Assert.assertTrue
import org.junit.Test

class DocxTextExtractorTest {
    @Test
    fun `extracts paragraphs and tables in document order`() {
        val xml = """
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body>
                <w:p><w:r><w:t>Тема: Сложение</w:t></w:r></w:p>
                <w:tbl>
                  <w:tr><w:tc><w:p><w:r><w:t>Время</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Этап</w:t></w:r></w:p></w:tc></w:tr>
                  <w:tr><w:tc><w:p><w:r><w:t>0–5</w:t></w:r></w:p></w:tc><w:tc><w:p><w:r><w:t>Начало</w:t></w:r></w:p></w:tc></w:tr>
                </w:tbl>
                <w:p><w:r><w:t>Задание 1</w:t></w:r></w:p>
              </w:body>
            </w:document>
        """.trimIndent()

        val result = DocxTextExtractor.extractFromDocumentXml(xml)
        assertTrue(result.startsWith("Тема: Сложение"))
        assertTrue(result.contains("| Время | Этап |"))
        assertTrue(result.contains("| 0–5 | Начало |"))
        assertTrue(result.endsWith("Задание 1"))
    }
}
