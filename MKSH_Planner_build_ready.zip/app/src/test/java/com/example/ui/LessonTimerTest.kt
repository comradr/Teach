package com.example.ui

import org.junit.Assert.assertEquals
import org.junit.Test

class LessonTimerTest {
    @Test fun sameBootUsesMonotonicClock() {
        val saved = PersistedLessonTimer(true, 60, 200_000L, 80_000L, 100_000L)
        assertEquals(30, restoredTimerSeconds(saved, 150_000L, 50_000L))
    }

    @Test fun afterRebootUsesWallClock() {
        val saved = PersistedLessonTimer(true, 60, 200_000L, 80_000L, 100_000L)
        assertEquals(40, restoredTimerSeconds(saved, 160_000L, 5_000L))
    }

    @Test fun pausedTimerKeepsSavedValue() {
        assertEquals(77, restoredTimerSeconds(PersistedLessonTimer(false, 77, 0L, 0L, 0L), 999_999L, 42L))
    }

    @Test fun expiredTimerRestoresToZero() {
        assertEquals(0, restoredTimerSeconds(PersistedLessonTimer(true, 12, 90_000L, 20_000L, 70_000L), 100_000L, 30_000L))
    }
}
