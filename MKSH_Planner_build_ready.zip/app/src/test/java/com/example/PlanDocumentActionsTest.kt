package com.example

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PlanDocumentActionsTest {
    @Test
    fun printableCardsUseFullWidthA4Layout() {
        val html = cardsMarkdownToHtml("## Карточка ученику\n- Задание 1<br>Подсказка\n")

        assertTrue(html.contains("@page { size: A4 portrait"))
        assertTrue(html.contains("<article class=\"card\">"))
        assertTrue(html.contains("<li>Задание 1<br>Подсказка</li>"))
        assertFalse(html.contains("&lt;br&gt;"))
        assertFalse(html.contains("Раздаточные материалы"))
        assertFalse(html.contains("Карточка ученику</h2>"))
        assertFalse(html.contains("grid-template-columns"))
        assertFalse(html.contains("border: 2px dashed"))
    }

    @Test
    fun fullPlanPrintRendersNativeTableAndEscapesHtml() {
        val html = fullPlanMarkdownToHtml(
            "Математика <1 класс>",
            "# Урок\n| Этап | Время |\n|---|---|\n| Начало | **5 мин** |\n- Задание"
        )

        assertTrue(html.contains("Математика &lt;1 класс&gt;"))
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<th>Этап</th>"))
        assertTrue(html.contains("<td><b>5 мин</b></td>"))
        assertTrue(html.contains("<li>Задание</li>"))
    }

    @Test
    fun fullPlanPrintConvertsBreakTagsInsideTableCells() {
        val html = fullPlanMarkdownToHtml(
            "Русский язык",
            """
                ## Ход урока
                | Время | Этап урока | Действия учителя | Деятельность учеников | Материалы |
                |---|---|---|---|---|
                | 3–10 | Минутка | **На доске:** П п<br>Запишите *пары букв*.<br />Объясните _правило_. | Пишут | Доска |
            """.trimIndent()
        )

        assertFalse(html.contains("&lt;br", ignoreCase = true))
        assertTrue(html.contains("П п<br>Запишите <i>пары букв</i>.<br>Объясните <i>правило</i>."))
        assertTrue(html.contains("<col style=\"width:8%\">"))
        assertTrue(html.contains("<col style=\"width:31%\">"))
        assertTrue(html.contains("table-layout: fixed"))
        assertTrue(html.contains("thead { display: table-header-group; }"))
    }

    @Test
    fun fullPlanPrintDecodesCommonEntitiesOnce() {
        val html = fullPlanMarkdownToHtml("План", "Тема:&nbsp;имена &amp; фамилии")

        assertFalse(html.contains("&nbsp;"))
        assertTrue(html.contains("Тема: имена &amp; фамилии"))
    }

    @Test
    fun fullPlanPrintRendersMarkdownHorizontalRule() {
        val html = fullPlanMarkdownToHtml("План", "Раздел один\n\n---\n\nРаздел два")

        assertTrue(html.contains("<hr>"))
        assertFalse(html.contains("<p>---</p>"))
    }

    @Test
    fun cardsPrintFullWidthSequentiallyWithTopicOnly() {
        val html = cardsMarkdownToHtml("""
            # План МКШ
            ## Карточка — ученику
            ### Карточка 1 (Класс 1 / 2 класс)
            Предмет: Русский язык
            Тема: Творчество А. С. Пушкина
            1. Первое задание
            ### Карточка 2 (Класс 2 / 3 класс)
            **Предмет:** Русский язык
            **Тема:** Словосочетание
            1. Второе задание
            | Слово | Словосочетание |
            |---|---|
            | Солнце | Яркое солнце |
            ## Ответы учителю
            Ответы
        """.trimIndent())

        assertTrue(html.contains("Тема: Творчество А. С. Пушкина"))
        assertTrue(html.contains("Тема: Словосочетание"))
        assertTrue(html.indexOf("Первое задание") < html.indexOf("Второе задание"))
        assertTrue(html.contains(".card { width: 100%; break-before: page"))
        assertTrue(html.contains("<table>"))
        assertTrue(html.contains("<td>Яркое солнце</td>"))
        assertFalse(html.contains("Предмет:"))
        assertFalse(html.contains("Карточка 1"))
        assertFalse(html.contains("Карточка 2"))
        assertTrue(html.contains("<section class=\"answers\">"))
        assertTrue(html.contains(">Ответы</h1>"))
        assertTrue(html.contains("page-break-before: always"))
    }

    @Test
    fun lessonKitKeepsTeacherPlanThenCardsThenAnswers() {
        val html = lessonKitMarkdownToHtml(
            "Урок",
            """
                ## Ход урока
                Объяснение учителя
                ## Карточка — ученику
                Тема: Сложение
                1. Реши пример
                ## Ответы учителю
                1. Ответ: 5
            """.trimIndent()
        )

        assertTrue(html.indexOf("Объяснение учителя") < html.indexOf("Реши пример"))
        assertTrue(html.indexOf("Реши пример") < html.indexOf("Ответ: 5"))
        assertTrue(html.contains("class=\"kit-materials\""))
        assertTrue(html.contains("class=\"answers\""))
    }
}
