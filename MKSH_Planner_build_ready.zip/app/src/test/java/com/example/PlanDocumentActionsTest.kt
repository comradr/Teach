package com.example

import org.junit.Assert.assertTrue
import org.junit.Test

class PlanDocumentActionsTest {
    @Test
    fun printableCardsUseTwoColumnNativePrintLayout() {
        val html = cardsMarkdownToHtml("## Карточка ученику\n- Задание 1\n")

        assertTrue(html.contains("grid-template-columns: repeat(2, 1fr)"))
        assertTrue(html.contains("<h2>Карточка ученику</h2>"))
        assertTrue(html.contains("<li>Задание 1</li>"))
    }
}
