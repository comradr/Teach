package com.example

import com.example.ui.components.splitPlanSections
import com.example.ui.components.splitTableAwareBlocks
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class StructuredPlanViewerTest {
    @Test
    fun splitsMarkdownAtHeadingsWithoutLosingContent() {
        val markdown = """
            # План
            Введение
            ## Цели
            Цель
            ## Ход урока
            | Время | Работа |
            |---|---|
            | 0–5 | Начало |
        """.trimIndent()

        val sections = splitPlanSections(markdown)

        assertEquals(3, sections.size)
        assertEquals(true, sections[2].contains("| 0–5 | Начало |"))
    }

    @Test
    fun levelThreeHeadingsStayWithTheirParentSection() {
        val sections = splitPlanSections("## Карточка\n### Класс 1\nЗадание\n### Класс 2\nЗадание")

        assertEquals(1, sections.size)
    }

    @Test
    fun onlyTheTableBlockNeedsHorizontalScrolling() {
        val blocks = splitTableAwareBlocks("## Ход\nВводный текст\n| Время | Этап |\n|---|---|\n| 0–5 | Старт |\nИтог")

        assertEquals(3, blocks.size)
        assertFalse(blocks.first().isTable)
        assertTrue(blocks[1].isTable)
        assertFalse(blocks.last().isTable)
    }
}
