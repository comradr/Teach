package com.example

import org.junit.Test
import org.junit.Assert.*

class GeminiApiServiceTest {
    @Test
    fun testPlanContentInterpolation() {
        val testContent = "UNIQUE_TEST_PLAN_12345"
        
        val requestPresentation = buildPresentationRequest(testContent)
        val requestActivity = buildFiveMinuteActivityRequest(testContent)
        val requestHomework = buildHomeworkRequest(testContent, emptyList())
        
        val textPresentation = requestPresentation.contents.first().parts?.first()?.text
        val textActivity = requestActivity.contents.first().parts?.first()?.text
        val textHomework = requestHomework.contents.first().parts?.first()?.text
        
        // Assert contains the actual string
        assertTrue(textPresentation?.contains(testContent) == true)
        assertTrue(textActivity?.contains(testContent) == true)
        assertTrue(textHomework?.contains(testContent) == true)
        
        // Assert does not contain literal variable name
        assertFalse(textPresentation?.contains("\$planContent") == true)
        assertFalse(textActivity?.contains("\$planContent") == true)
        assertFalse(textHomework?.contains("\$planContent") == true)
    }

    @Test
    fun testHomeworkCanBeLockedToOneMksClass() {
        val request = buildHomeworkRequest("# Класс 1\nМатематика\n# Класс 2\nРусский", emptyList(), "Класс 2")
        val system = request.systemInstruction?.parts?.firstOrNull()?.text.orEmpty()
        val prompt = request.contents.first().parts?.firstOrNull()?.text.orEmpty()
        assertTrue(system.contains("ТОЛЬКО к Класс 2"))
        assertTrue(system.contains("только для Класс 2"))
        assertTrue(prompt.contains("Целевой класс: Класс 2"))
    }
}
