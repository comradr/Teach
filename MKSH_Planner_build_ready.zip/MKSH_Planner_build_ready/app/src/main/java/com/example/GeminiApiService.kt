package com.example

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    @kotlinx.serialization.SerialName("system_instruction")
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val role: String? = null,
    val parts: List<Part>? = null
)

@Serializable
data class InlineData(
    @kotlinx.serialization.SerialName("mime_type")
    val mimeType: String,
    val data: String
)

@Serializable
data class Part(
    val text: String? = null,
    @kotlinx.serialization.SerialName("inline_data")
    val inlineData: InlineData? = null
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@Serializable
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object RetrofitClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    val service: GeminiApiService by lazy {
        val json = Json { ignoreUnknownKeys = true; isLenient = true }
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
        retrofit.create(GeminiApiService::class.java)
    }
}

sealed class GeminiExtraResult {
    data class Success(val text: String) : GeminiExtraResult()
    data class Error(val message: String) : GeminiExtraResult()
}

// Request builder extraction for testing
internal fun buildPresentationRequest(planContent: String): GenerateContentRequest {
    val systemPrompt = "Ты — школьный методист для 1–5 классов. На основе плана урока составь структуру презентации. Для каждого слайда напиши заголовок, текст, и опиши визуальный ряд. Ответ выдай в формате Markdown."
    return GenerateContentRequest(
        contents = listOf(Content(parts = listOf(Part(text = "План урока:\n" + planContent)))),
        systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
    )
}

internal fun buildFiveMinuteActivityRequest(planContent: String): GenerateContentRequest {
    val isTwoClasses = LessonPromptBuilder.looksLikeTwoClassPlan(planContent)
    val systemPrompt = if (isTwoClasses) {
        "Ты — школьный методист для 1–5 классов. Проанализируй этот план урока совмещённых классов и создай интересную 5-минутную активность (пятиминутку), которая объединит оба класса (например, интеллектуальная разминка, игра на внимание или нейрогимнастика). Ответ выдай в формате Markdown, без лишних вступлений."
    } else {
        "Ты — школьный методист для 1–5 классов. Проанализируй этот план урока и создай интересную 5-минутную активность (пятиминутку) для выбранного класса (например, интеллектуальная разминка, игра на внимание или нейрогимнастика). Никаких упоминаний другого класса быть не должно. Ответ выдай в формате Markdown, без лишних вступлений."
    }
    return GenerateContentRequest(
        contents = listOf(Content(parts = listOf(Part(text = "План урока:\n" + planContent)))),
        systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
    )
}

internal fun buildHomeworkRequest(
    planContent: String,
    images: List<Pair<String, String>>,
    targetClass: String? = null
): GenerateContentRequest {
    val targetRule = if (targetClass.isNullOrBlank()) {
        "Определи класс только из исходного плана и материала."
    } else {
        "Фотография относится ТОЛЬКО к $targetClass. Составь домашнее задание только для $targetClass и не добавляй задания второму классу."
    }
    val systemPrompt = "Ты — школьный методист для 1–5 классов. Проанализируй этот план урока и приложенные фотографии учебников. Составь домашнее задание, которое опирается на материал из учебников и соответствует плану урока. $targetRule Не добавляй задания для классов, которых нет в исходном плане/материале. Ответ выдай в формате Markdown."
    
    val promptPrefix = if (targetClass.isNullOrBlank()) "" else "Целевой класс: $targetClass\n"
    val parts = mutableListOf<Part>(Part(text = promptPrefix + "План урока:\n" + planContent))
    images.forEach { (mimeType, base64Image) ->
        parts.add(Part(inlineData = InlineData(mimeType = mimeType, data = base64Image)))
    }
    
    return GenerateContentRequest(
        contents = listOf(Content(parts = parts)),
        systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
    )
}

suspend fun generatePresentationOutline(planContent: String): GeminiExtraResult {
    val apiKey = com.example.BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
         return GeminiExtraResult.Error("API ключ не настроен. Пожалуйста, проверьте настройки.")
    }
    val request = buildPresentationRequest(planContent)
    return try {
        val response = RetrofitClient.service.generateContent(apiKey, request)
        val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
        if (text != null) GeminiExtraResult.Success(LessonTextSanitizer.sanitizeGeminiMarkdown(text)) else GeminiExtraResult.Error("Не удалось получить ответ от нейросети.")
    } catch (e: Exception) {
        GeminiExtraResult.Error(getFriendlyErrorMessage(e))
    }
}

suspend fun generateFiveMinuteActivity(planContent: String): GeminiExtraResult {
    val apiKey = com.example.BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
         return GeminiExtraResult.Error("API ключ не настроен. Пожалуйста, проверьте настройки.")
    }
    val request = buildFiveMinuteActivityRequest(planContent)
    return try {
        val response = RetrofitClient.service.generateContent(apiKey, request)
        val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
        if (text != null) GeminiExtraResult.Success(LessonTextSanitizer.sanitizeGeminiMarkdown(text)) else GeminiExtraResult.Error("Не удалось получить ответ от нейросети.")
    } catch (e: Exception) {
        GeminiExtraResult.Error(getFriendlyErrorMessage(e))
    }
}

suspend fun generateHomeworkFromImage(
    planContent: String,
    images: List<Pair<String, String>>,
    targetClass: String? = null
): GeminiExtraResult {
    val apiKey = com.example.BuildConfig.GEMINI_API_KEY
    if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
         return GeminiExtraResult.Error("API ключ не настроен. Пожалуйста, проверьте настройки.")
    }
    val request = buildHomeworkRequest(planContent, images, targetClass)
    return try {
        val response = RetrofitClient.service.generateContent(apiKey, request)
        val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
        if (text != null) GeminiExtraResult.Success(LessonTextSanitizer.sanitizeGeminiMarkdown(text)) else GeminiExtraResult.Error("Не удалось получить ответ от нейросети.")
    } catch (e: retrofit2.HttpException) {
        GeminiExtraResult.Error(getFriendlyErrorMessage(e))
    } catch (e: Exception) {
        GeminiExtraResult.Error(getFriendlyErrorMessage(e))
    }
}

fun getFriendlyErrorMessage(e: Exception): String {
    if (e is retrofit2.HttpException) {
        val errorBody = try { e.response()?.errorBody()?.string() } catch(ex: Exception) { "no body" }
        return "Ошибка HTTP ${e.code()}: $errorBody"
    }
    val msg = e.localizedMessage ?: "Неизвестная ошибка"
    return when {
        msg.contains("429") -> "Слишком много запросов. Пожалуйста, подождите немного и повторите."
        msg.contains("400") -> "Некорректный запрос к серверу. Возможно, параметры урока неполные."
        msg.contains("401") || msg.contains("403") -> "Ошибка авторизации. Проверьте API ключ в настройках."
        msg.contains("500") || msg.contains("503") -> "Сервер нейросети временно недоступен. Попробуйте позже."
        msg.contains("UnknownHostException") || msg.contains("timeout") || msg.contains("ConnectException") -> "Отсутствует подключение к сети. Проверьте интернет."
        else -> "Произошла ошибка при генерации: Не удалось подключиться к сервису."
    }
}
