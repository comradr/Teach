package com.example.data.remote

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.example.data.local.LessonPlanEntity
import com.example.data.local.FolderEntity
import kotlinx.coroutines.tasks.await

object FirebaseSyncManager {
    private var db: FirebaseFirestore? = null

    fun initialize() {
        try {
            db = FirebaseFirestore.getInstance()
        } catch (e: Exception) {
            Log.d("FirebaseSync", "Firebase not initialized. Sync features will be disabled.")
        }
    }

    suspend fun syncPlan(plan: LessonPlanEntity, syncCode: String): Boolean {
        if (db == null) return false
        return try {
            val planMap = hashMapOf(
                "title" to plan.title,
                "content" to plan.content,
                "timestamp" to plan.timestamp,
                "isFavorite" to plan.isFavorite
            )
            db!!.collection("sync").document(syncCode).collection("plans").document(plan.id.toString())
                .set(planMap)
                .await()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun downloadPlans(syncCode: String): List<LessonPlanEntity> {
        if (db == null) return emptyList()
        return try {
            val snapshot = db!!.collection("sync").document(syncCode).collection("plans").get().await()
            snapshot.documents.mapNotNull { doc ->
                val title = doc.getString("title") ?: return@mapNotNull null
                val content = doc.getString("content") ?: ""
                val timestamp = doc.getLong("timestamp") ?: 0L
                val isFavorite = doc.getBoolean("isFavorite") ?: false
                val id = doc.id.toLongOrNull() ?: 0L
                LessonPlanEntity(id = id, folderId = 0, title = title, content = content, timestamp = timestamp, isFavorite = isFavorite)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }
}
