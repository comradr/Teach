package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.Article
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.data.local.FolderEntity
import com.example.data.local.LessonPlanEntity
import com.example.ui.FavoritesScreen
import com.example.ui.theme.MyApplicationTheme
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = androidx.compose.foundation.isSystemInDarkTheme()) {
                val navController = rememberNavController()
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentRoute = navBackStackEntry?.destination?.route
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar {
                            NavigationBarItem(
                                selected = currentRoute == "generator",
                                onClick = { navController.navigate("generator") { popUpTo("generator") { inclusive = true } } },
                                icon = { Icon(Icons.Default.Add, contentDescription = "Генератор") },
                                label = { Text("Создать") }
                            )
                            NavigationBarItem(
                                selected = currentRoute == "folders" || currentRoute?.startsWith("folder_plans") == true || currentRoute?.startsWith("plan_detail") == true,
                                onClick = { navController.navigate("folders") { popUpTo("generator") } },
                                icon = { Icon(Icons.Default.Folder, contentDescription = "Папки") },
                                label = { Text("Папки") }
                            )
                            NavigationBarItem(
                                selected = currentRoute == "favorites",
                                onClick = { navController.navigate("favorites") { popUpTo("generator") } },
                                icon = { Icon(Icons.Default.Favorite, contentDescription = "Избранное") },
                                label = { Text("Избранное") }
                            )
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "generator",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("generator") {
                            LessonPlannerScreen(navController = navController)
                        }
                        composable("folders") {
                            FoldersScreen(navController = navController)
                        }
                        composable("favorites") {
                            FavoritesScreen(navController = navController)
                        }
                        composable("folder_plans/{folderId}") { backStackEntry ->
                            val folderId = backStackEntry.arguments?.getString("folderId")?.toLongOrNull() ?: 0L
                            LessonPlansScreen(folderId = folderId, navController = navController)
                        }
                        composable("plan_detail/{planId}") { backStackEntry ->
                            val planId = backStackEntry.arguments?.getString("planId")?.toLongOrNull() ?: 0L
                            PlanDetailScreen(planId = planId, navController = navController)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonPlannerScreen(
    modifier: Modifier = Modifier,
    viewModel: LessonPlannerViewModel = viewModel(),
    foldersViewModel: PlannerFoldersViewModel = viewModel(),
    navController: NavHostController
) {
    var classASubject by remember { mutableStateOf("") }
    var lastGeneratedPlan by remember { mutableStateOf("") }
    var classAGrade by remember { mutableStateOf("") }
    var classATopic by remember { mutableStateOf("") }
    val context = LocalContext.current
    val photoScope = rememberCoroutineScope()

    var classBSubject by remember { mutableStateOf("") }
    var classBGrade by remember { mutableStateOf("") }
    var classBTopic by remember { mutableStateOf("") }

    var useSecondClass by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(false) }
    var classAIndependentWorkLimit by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("15") }
    var classBIndependentWorkLimit by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("15") }
    var planMode by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("Для себя") }
    var additionalInstructions by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("") }
    var lessonDuration by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf("45") }
    val draftStore = remember { LessonDraftStore(context) }
    var draftLoaded by remember { mutableStateOf(false) }

    
    var showSaveDialog by remember { mutableStateOf(false) }
    var selectedFolderId by remember { mutableStateOf<Long?>(null) }
    var planTitle by remember { mutableStateOf("") }
    var isError by remember { mutableStateOf(false) }
    val folders by foldersViewModel.allFolders.collectAsState()
    var showTemplatesDialog by remember { mutableStateOf(false) }

    var expandedASubject by remember { mutableStateOf(false) }
    var expandedAGrade by remember { mutableStateOf(false) }
    var expandedBSubject by remember { mutableStateOf(false) }
    var expandedBGrade by remember { mutableStateOf(false) }
    var expandedLessonType by remember { mutableStateOf(false) }
    var lessonType by remember { mutableStateOf("Комбинированный") }

    val subjects = listOf("Математика", "Русский язык", "Литературное чтение", "Литература", "Окружающий мир", "История", "География", "Биология", "Информатика", "Иностранный язык", "Изобразительное искусство", "Технология", "Музыка", "Физкультура")
    var classAImages by remember { mutableStateOf<List<DraftLessonImage>>(emptyList()) }
    var classBImages by remember { mutableStateOf<List<DraftLessonImage>>(emptyList()) }
    var targetClassForPhoto by remember { mutableStateOf<String?>(null) }
    var currentPhotoUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var voiceTarget by remember { mutableStateOf<String?>(null) }

    val voiceInputLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val spoken = result.data
                ?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
                ?.trim()
            if (!spoken.isNullOrBlank()) {
                when (voiceTarget) {
                    "A" -> classATopic = spoken
                    "B" -> classBTopic = spoken
                }
                isError = false
            }
        }
        voiceTarget = null
    }

    fun launchVoiceInput(targetClass: String) {
        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, java.util.Locale.getDefault().toLanguageTag())
            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Назовите тему урока")
        }
        if (intent.resolveActivity(context.packageManager) != null) {
            voiceTarget = targetClass
            voiceInputLauncher.launch(intent)
        } else {
            android.widget.Toast.makeText(context, "На устройстве нет службы голосового ввода", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    val removeDraftImage = { image: DraftLessonImage ->
        val file = java.io.File(image.path)
        if (file.exists() && file.absolutePath.contains("draft_images")) {
            file.delete()
        }
    }

    val handleOptimizedImage = { optimizedImage: DraftLessonImage?, targetClass: String? ->
        if (optimizedImage != null) {
            when (targetClass) {
                "A" -> if (classAImages.size < 2) classAImages = classAImages + optimizedImage
                "B" -> if (classBImages.size < 2) classBImages = classBImages + optimizedImage
            }
        } else {
            android.widget.Toast.makeText(context, "Ошибка подготовки фото", android.widget.Toast.LENGTH_SHORT).show()
        }
        ImageOptimizer.cleanUpTempCameraFiles(context)
    }

    val imagePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri: android.net.Uri? ->
        uri?.let { selectedUri ->
            val target = targetClassForPhoto
            photoScope.launch {
                val optimized = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                    ImageOptimizer.optimizeImage(context, selectedUri)
                }
                handleOptimizedImage(optimized, target)
            }
        }
    }
    
    val takePictureLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success) {
            currentPhotoUri?.let { uri ->
                val target = targetClassForPhoto
                photoScope.launch {
                    val optimized = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                        ImageOptimizer.optimizeImage(context, uri)
                    }
                    handleOptimizedImage(optimized, target)
                }
            }
        }
    }

    fun launchCamera(targetClass: String) {
        targetClassForPhoto = targetClass
        val tempFile = java.io.File(context.cacheDir, "temp_camera_${System.currentTimeMillis()}.jpg")
        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.aistudio.lessonplanner.xyazqw.fileprovider", tempFile)
        currentPhotoUri = uri
        takePictureLauncher.launch(uri)
    }

    fun launchGallery(targetClass: String) {
        targetClassForPhoto = targetClass
        imagePickerLauncher.launch("image/*")
    }
    val grades = listOf("1 класс", "2 класс", "3 класс", "4 класс", "5 класс")
    val lessonTypes = listOf("Комбинированный", "Изучение нового материала", "Урок закрепления", "Урок обобщения", "Контрольный урок")

    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(Unit) {
        if (!draftLoaded) {
            val draft = draftStore.getDraft()
            useSecondClass = draft.useSecondClass
            classASubject = draft.classASubject
            classAGrade = draft.classAGrade
            classATopic = draft.classATopic
            classBSubject = draft.classBSubject
            classBGrade = draft.classBGrade
            classBTopic = draft.classBTopic
            classAIndependentWorkLimit = draft.classAIndependentWorkLimit
            classBIndependentWorkLimit = draft.classBIndependentWorkLimit
            lessonDuration = draft.lessonDuration
            additionalInstructions = draft.additionalInstructions
            planMode = draft.planMode
            lessonType = draft.lessonType
            if (draft.generatedPlan.isNotEmpty()) {
                viewModel.updateGeneratedPlan(draft.generatedPlan)
            }
            val restoredA = draft.classAImages.filter { image ->
                java.io.File(image.path).let { it.exists() && it.length() > 0L }
            }
            val restoredB = draft.classBImages.filter { image ->
                java.io.File(image.path).let { it.exists() && it.length() > 0L }
            }
            if (restoredA.isNotEmpty()) {
                classAImages = restoredA
            } else if (draft.attachedImages.isNotEmpty()) {
                classAImages = draft.attachedImages.mapNotNull { legacy ->
                    runCatching {
                        val tempId = java.util.UUID.randomUUID().toString()
                        val tempFile = java.io.File(ImageOptimizer.getDraftsDir(context), "legacy_$tempId.jpg")
                        val bytes = android.util.Base64.decode(legacy.second, android.util.Base64.DEFAULT)
                        java.io.FileOutputStream(tempFile).use { it.write(bytes) }
                        DraftLessonImage(tempId, tempFile.absolutePath)
                    }.getOrNull()
                }.take(2)
            }
            classBImages = restoredB
            draftLoaded = true
        }
    }

    LaunchedEffect(
        useSecondClass, classASubject, classAGrade, classATopic,
        classBSubject, classBGrade, classBTopic,
        classAIndependentWorkLimit, classBIndependentWorkLimit,
        lessonDuration, additionalInstructions, planMode, lessonType,
        classAImages, classBImages, lastGeneratedPlan
    ) {
        if (draftLoaded) {
            kotlinx.coroutines.delay(500)
            val generatedPlanText = lastGeneratedPlan
            val draft = com.example.LessonDraft(
                useSecondClass = useSecondClass,
                classASubject = classASubject,
                classAGrade = classAGrade,
                classATopic = classATopic,
                classBSubject = classBSubject,
                classBGrade = classBGrade,
                classBTopic = classBTopic,
                classAIndependentWorkLimit = classAIndependentWorkLimit,
                classBIndependentWorkLimit = classBIndependentWorkLimit,
                lessonDuration = lessonDuration,
                additionalInstructions = additionalInstructions,
                planMode = planMode,
                lessonType = lessonType,
                generatedPlan = generatedPlanText,
                classAImages = classAImages,
                classBImages = classBImages,
                attachedImages = emptyList()
            )
            draftStore.saveDraft(draft)
        }
    }
    
    var isEditingPlan by remember { mutableStateOf(false) }
    var editingPlanContent by remember { mutableStateOf("") }

    val templates = listOf(
        Pair("Математика и Русский", "2 класс, 3 класс"),
        Pair("Чтение и Окружающий мир", "4 класс, 2 класс")
    )

    if (showTemplatesDialog) {
        AlertDialog(
            onDismissRequest = { showTemplatesDialog = false },
            title = { Text("Выберите шаблон") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(templates) { template ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable {
                                useSecondClass = true
                                if (template.first == "Математика и Русский") {
                                    classASubject = "Математика"
                                    classAGrade = "2 класс"
                                    classATopic = "Сложение до 100"
                                    classBSubject = "Русский язык"
                                    classBGrade = "3 класс"
                                    classBTopic = "Безударные гласные"
                                } else {
                                    classASubject = "Литературное чтение"
                                    classAGrade = "4 класс"
                                    classATopic = "А.С. Пушкин"
                                    classBSubject = "Окружающий мир"
                                    classBGrade = "2 класс"
                                    classBTopic = "Животные"
                                }
                                showTemplatesDialog = false
                            }
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(template.first, fontWeight = FontWeight.Bold)
                                Text(template.second, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showTemplatesDialog = false }) {
                    Text("Закрыть")
                }
            }
        )
    }

    
    LaunchedEffect(uiState) {
        if (uiState is PlannerUiState.Success) {
            lastGeneratedPlan = (uiState as PlannerUiState.Success).resultText
        }
        if (uiState is PlannerUiState.Saved) {
            val savedId = (uiState as PlannerUiState.Saved).planId
            showSaveDialog = false
            
            viewModel.resetState()
            lastGeneratedPlan = ""
            classASubject = ""
            classAGrade = ""
            classATopic = ""
            classBSubject = ""
            classBGrade = ""
            classBTopic = ""
            planTitle = ""
            selectedFolderId = null
            classAImages.forEach(removeDraftImage)
            classBImages.forEach(removeDraftImage)
            classAImages = emptyList()
            classBImages = emptyList()
            isEditingPlan = false
            editingPlanContent = ""
            
            navController.navigate("plan_detail/$savedId") {
                popUpTo("generator") { inclusive = false }
            }
        }
    }
    

    if (showSaveDialog && uiState is PlannerUiState.Success) {
        var newFolderName by remember { mutableStateOf("") }
        var isCreatingFolder by remember { mutableStateOf(false) }
        
        AlertDialog(
            onDismissRequest = { showSaveDialog = false },
            title = { Text("Сохранить план") },
            text = {
                Column {
                    OutlinedTextField(
                        value = planTitle,
                        onValueChange = { planTitle = it },
                        label = { Text("Название плана") }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("Выберите папку:")
                    
                    if (isCreatingFolder) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = newFolderName,
                                onValueChange = { newFolderName = it },
                                label = { Text("Имя новой папки") },
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = {
                                if (newFolderName.isNotBlank()) {
                                    foldersViewModel.addFolder(newFolderName)
                                    isCreatingFolder = false
                                    newFolderName = ""
                                }
                            }) {
                                Icon(Icons.Default.Check, contentDescription = "Создать")
                            }
                        }
                    } else {
                        TextButton(onClick = { isCreatingFolder = true }) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Создать новую папку")
                        }
                    }
                    
                    if (folders.isEmpty() && !isCreatingFolder) {
                        Text("Нет папок.", color = MaterialTheme.colorScheme.error)
                    } else {
                        androidx.compose.foundation.lazy.LazyColumn(modifier = Modifier.heightIn(max = 200.dp)) {
                            items(folders.size) { i ->
                                val folder = folders[i]
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { selectedFolderId = folder.id }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selectedFolderId == folder.id,
                                        onClick = { selectedFolderId = folder.id }
                                    )
                                    Text(folder.name)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val folderId = selectedFolderId
                        if (folderId != null && planTitle.isNotBlank()) {
                            val finalContent = if (isEditingPlan) editingPlanContent else (uiState as PlannerUiState.Success).resultText
                            viewModel.saveLessonPlan(
                                folderId = folderId,
                                title = planTitle,
                                content = finalContent,
                                durationMinutes = lessonDuration.toIntOrNull() ?: 45
                            )
                        }
                    },
                    enabled = selectedFolderId != null && planTitle.isNotBlank() && uiState !is PlannerUiState.Loading
                ) {
                    if (uiState is PlannerUiState.Loading) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    } else {
                        Text("Сохранить")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showSaveDialog = false }) {
                    Text("Отмена")
                }
            }
        )

    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "МКШ Планировщик",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { 
                    draftStore.clearDraft()
                    classASubject = ""
                    classAGrade = ""
                    classATopic = ""
                    classBSubject = ""
                    classBGrade = ""
                    classBTopic = ""
                    useSecondClass = false
                    classAIndependentWorkLimit = "15"
                    classBIndependentWorkLimit = "15"
                    planMode = "Для себя"
                    additionalInstructions = ""
                    lessonDuration = "45"
                    
                    classAImages.forEach { removeDraftImage(it) }
                    classBImages.forEach { removeDraftImage(it) }
                    classAImages = emptyList()
                    classBImages = emptyList()
                    
                    lastGeneratedPlan = ""
                    editingPlanContent = ""
                    isEditingPlan = false
                    lessonType = "Комбинированный"
                    viewModel.resetState()
            lastGeneratedPlan = ""
                }) {
                    Text("Очистить")
                }
                TextButton(onClick = { showTemplatesDialog = true }) {
                    Text("Шаблоны")
                }
            }
        }

        HorizontalDivider()

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("Общие настройки", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Сколько классов на уроке", style = MaterialTheme.typography.bodyMedium)
                Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = !useSecondClass, onClick = { useSecondClass = false })
                    Text("Один класс")
                    Spacer(modifier = Modifier.width(16.dp))
                    RadioButton(selected = useSecondClass, onClick = { useSecondClass = true })
                    Text("Два класса")
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Режим плана")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = planMode == "Для себя", onClick = { planMode = "Для себя" })
                        Text("Для себя")
                        Spacer(modifier = Modifier.width(4.dp))
                        RadioButton(selected = planMode == "Официальный", onClick = { planMode = "Официальный" })
                        Text("Офиц.")
                    }
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Длительность")
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        listOf("35", "40", "45").forEach { duration ->
                            RadioButton(selected = lessonDuration == duration, onClick = { lessonDuration = duration })
                            Text(duration)
                        }
                    }
                }
                var expandInstructions by remember { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable { expandInstructions = !expandInstructions }) {
                    Text("Дополнительные пожелания", fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.weight(1f))
                    Icon(if (expandInstructions) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown, contentDescription = null)
                }
                androidx.compose.animation.AnimatedVisibility(visible = expandInstructions) {
                    OutlinedTextField(
                        value = additionalInstructions,
                        onValueChange = { additionalInstructions = it },
                        label = { Text("Опишите ваши пожелания") },
                        modifier = Modifier.fillMaxWidth().heightIn(min = 100.dp),
                        maxLines = 5
                    )
                }

                ExposedDropdownMenuBox(
                    expanded = expandedLessonType,
                    onExpandedChange = { expandedLessonType = !expandedLessonType }
                ) {
                    OutlinedTextField(
                        value = lessonType,
                        onValueChange = { lessonType = it },
                        label = { Text("Тип урока") },
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedLessonType) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedLessonType,
                        onDismissRequest = { expandedLessonType = false }
                    ) {
                        lessonTypes.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { lessonType = selectionOption; expandedLessonType = false })
                        }
                    }
                }
            }
        }

        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(if (useSecondClass) "Класс 1" else "Класс", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                ExposedDropdownMenuBox(
                    expanded = expandedASubject,
                    onExpandedChange = { expandedASubject = !expandedASubject }
                ) {
                    OutlinedTextField(
                        value = classASubject, 
                        onValueChange = { classASubject = it; isError = false }, 
                        label = { Text("Предмет") }, 
                        isError = isError && classASubject.isBlank(), 
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedASubject) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedASubject,
                        onDismissRequest = { expandedASubject = false }
                    ) {
                        subjects.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classASubject = selectionOption; expandedASubject = false; isError = false })
                        }
                    }
                }
                ExposedDropdownMenuBox(
                    expanded = expandedAGrade,
                    onExpandedChange = { expandedAGrade = !expandedAGrade }
                ) {
                    OutlinedTextField(
                        value = classAGrade, 
                        onValueChange = { classAGrade = it; isError = false }, 
                        label = { Text("Класс") }, 
                        isError = isError && classAGrade.isBlank(), 
                        modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                        readOnly = true,
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedAGrade) },
                        colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                    )
                    ExposedDropdownMenu(
                        expanded = expandedAGrade,
                        onDismissRequest = { expandedAGrade = false }
                    ) {
                        grades.forEach { selectionOption ->
                            DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classAGrade = selectionOption; expandedAGrade = false; isError = false })
                        }
                    }
                }
                OutlinedTextField(
                    value = classATopic, 
                    onValueChange = { classATopic = it; isError = false }, 
                    label = { Text("Тема урока") }, 
                    isError = isError && classATopic.isBlank(), 
                    modifier = Modifier.fillMaxWidth(),
                    trailingIcon = {
                        IconButton(onClick = { launchVoiceInput("A") }) {
                            Icon(Icons.Default.Mic, contentDescription = "Голосовой ввод")
                        }
                    }
                )
                PhotosSection(
                    title = "Материалы (Класс 1)",
                    images = classAImages,
                    onLaunchCamera = { launchCamera("A") },
                    onLaunchGallery = { launchGallery("A") },
                    onRemoveImage = { image -> classAImages = classAImages.filter { it.id != image.id }; removeDraftImage(image) }
                )
                if (useSecondClass) {
                    OutlinedTextField(
                        value = classAIndependentWorkLimit,
                        onValueChange = { classAIndependentWorkLimit = it },
                        label = { Text("Максимум самостоятельной работы без учителя, мин.") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                    )
                }
            }
        }

        androidx.compose.animation.AnimatedVisibility(visible = useSecondClass) {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Класс 2", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    ExposedDropdownMenuBox(
                        expanded = expandedBSubject,
                        onExpandedChange = { expandedBSubject = !expandedBSubject }
                    ) {
                        OutlinedTextField(
                            value = classBSubject, 
                            onValueChange = { classBSubject = it; isError = false }, 
                            label = { Text("Предмет") }, 
                            isError = isError && classBSubject.isBlank(), 
                            modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedBSubject) },
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedBSubject,
                            onDismissRequest = { expandedBSubject = false }
                        ) {
                            subjects.forEach { selectionOption ->
                                DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classBSubject = selectionOption; expandedBSubject = false; isError = false })
                            }
                        }
                    }
                    ExposedDropdownMenuBox(
                        expanded = expandedBGrade,
                        onExpandedChange = { expandedBGrade = !expandedBGrade }
                    ) {
                        OutlinedTextField(
                            value = classBGrade, 
                            onValueChange = { classBGrade = it; isError = false }, 
                            label = { Text("Класс") }, 
                            isError = isError && classBGrade.isBlank(), 
                            modifier = Modifier.fillMaxWidth().menuAnchor(androidx.compose.material3.MenuAnchorType.PrimaryNotEditable),
                            readOnly = true,
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedBGrade) },
                            colors = ExposedDropdownMenuDefaults.outlinedTextFieldColors()
                        )
                        ExposedDropdownMenu(
                            expanded = expandedBGrade,
                            onDismissRequest = { expandedBGrade = false }
                        ) {
                            grades.forEach { selectionOption ->
                                DropdownMenuItem(text = { Text(selectionOption) }, onClick = { classBGrade = selectionOption; expandedBGrade = false; isError = false })
                            }
                        }
                    }
                    OutlinedTextField(
                        value = classBTopic, 
                        onValueChange = { classBTopic = it; isError = false }, 
                        label = { Text("Тема урока") }, 
                        isError = isError && classBTopic.isBlank(), 
                        modifier = Modifier.fillMaxWidth(),
                        trailingIcon = {
                            IconButton(onClick = { launchVoiceInput("B") }) {
                                Icon(Icons.Default.Mic, contentDescription = "Голосовой ввод")
                            }
                        }
                    )
                    PhotosSection(
                        title = "Материалы (Класс 2)",
                        images = classBImages,
                        onLaunchCamera = { launchCamera("B") },
                        onLaunchGallery = { launchGallery("B") },
                        onRemoveImage = { image -> classBImages = classBImages.filter { it.id != image.id }; removeDraftImage(image) }
                    )
                    OutlinedTextField(
                        value = classBIndependentWorkLimit,
                        onValueChange = { classBIndependentWorkLimit = it },
                        label = { Text("Максимум самостоятельной работы без учителя, мин.") },
                        modifier = Modifier.fillMaxWidth(),
                        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number)
                    )
                }
            }


        }
        Button(
            onClick = {
                if (classASubject.isBlank() || classAGrade.isBlank() || (useSecondClass && (classBSubject.isBlank() || classBGrade.isBlank()))) {
                    isError = true
                    android.widget.Toast.makeText(context, "Заполните предметы и классы", android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    viewModel.generateLessonPlan(context, useSecondClass, classASubject, classAGrade, classATopic, classAIndependentWorkLimit, classBSubject, classBGrade, classBTopic, classBIndependentWorkLimit, planMode, lessonType, classAImages, classBImages, lessonDuration.toIntOrNull() ?: 45, additionalInstructions)
                }
            },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            enabled = uiState !is PlannerUiState.Loading
        ) {
            if (uiState is PlannerUiState.Loading) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Генерация...")
            } else {
                Text("Сгенерировать план урока")
            }
        }

        when (uiState) {
            is PlannerUiState.Error -> {
                Text((uiState as PlannerUiState.Error).message, color = MaterialTheme.colorScheme.error)
            }
            is PlannerUiState.Success -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text("Результат:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                val history = viewModel.history.collectAsState().value
                                if (history.isNotEmpty()) {
                                    IconButton(onClick = { viewModel.undoLastChange() }) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Отменить")
                                    }
                                }
                                if (isEditingPlan) {
                                    OutlinedButton(onClick = {
                                        viewModel.updateGeneratedPlan(editingPlanContent)
                                        isEditingPlan = false
                                    }) {
                                        Text("Готово")
                                    }
                                } else {
                                    IconButton(onClick = {
                                        editingPlanContent = (uiState as PlannerUiState.Success).resultText
                                        isEditingPlan = true
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Редактировать план")
                                    }
                                }
                                Button(onClick = { showSaveDialog = true }) {
                                    Text("Сохранить в папку")
                                }
                            }
                        }
                        val validationWarnings = (uiState as PlannerUiState.Success).warnings
                        if (validationWarnings.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text("Автопроверка нашла замечания", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onErrorContainer)
                                    validationWarnings.forEach { warning ->
                                        Text("• $warning", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onErrorContainer)
                                    }
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        if (isEditingPlan) {
                            OutlinedTextField(
                                value = editingPlanContent,
                                onValueChange = { editingPlanContent = it },
                                modifier = Modifier.fillMaxWidth().heightIn(min = 300.dp),
                                textStyle = MaterialTheme.typography.bodyMedium
                            )
                        } else {
                            androidx.compose.foundation.text.selection.SelectionContainer {
                                com.example.ui.MarkdownViewer(
                                    markdown = (uiState as PlannerUiState.Success).resultText
                                )
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            var regenerateSectionTitle by remember { mutableStateOf("") }
                            var regenerateInstruction by remember { mutableStateOf("") }
                            Text("Перегенерировать фрагмент", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = regenerateSectionTitle,
                                    onValueChange = { regenerateSectionTitle = it },
                                    label = { Text("Название раздела (например, 'Ход урока')") },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = regenerateInstruction,
                                    onValueChange = { regenerateInstruction = it },
                                    label = { Text("Что переделать?") },
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (regenerateSectionTitle.isNotBlank() && regenerateInstruction.isNotBlank()) {
                                            val fullText = (uiState as PlannerUiState.Success).resultText
                                            viewModel.regenerateSection(
                                                currentPlan = fullText,
                                                sectionTitle = regenerateSectionTitle,
                                                instructions = regenerateInstruction,
                                                useSecondClass = useSecondClass
                                            )
                                            regenerateSectionTitle = ""
                                            regenerateInstruction = ""
                                        }
                                    },
                                    enabled = regenerateSectionTitle.isNotBlank() && regenerateInstruction.isNotBlank()
                                ) {
                                    Text("Заменить")
                                }
                            }
                        }
                    }
                }
            }
            else -> {}
        }
        Spacer(modifier = Modifier.height(32.dp))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FoldersScreen(
    viewModel: PlannerFoldersViewModel = viewModel(),
    navController: NavHostController
) {
    val folders by viewModel.allFolders.collectAsState()
    val archivedFolders by viewModel.archivedFolders.collectAsState()
    var showAddDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }
    var folderToDelete by remember { mutableStateOf<Long?>(null) }
    var folderToRename by remember { mutableStateOf<com.example.data.local.FolderEntity?>(null) }
    var renameFolderName by remember { mutableStateOf("") }
    var showArchived by remember { mutableStateOf(false) }
    
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showMessage by remember { mutableStateOf<String?>(null) }
    
    val exportLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                val bm = com.example.data.local.BackupManager(context, db)
                val success = bm.createBackup(it)
                showMessage = if (success) "Резервная копия создана" else "Ошибка при создании"
            }
        }
    }
    
    val importLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let {
            coroutineScope.launch {
                val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                val bm = com.example.data.local.BackupManager(context, db)
                val success = bm.restoreBackup(it)
                showMessage = if (success) "Данные успешно восстановлены" else "Ошибка при восстановлении"
            }
        }
    }

    
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Новая папка") },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Название папки") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (newFolderName.isNotBlank()) {
                        viewModel.addFolder(newFolderName)
                        newFolderName = ""
                        showAddDialog = false
                    }
                }) { Text("Создать") }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) { Text("Отмена") }
            }
        )
    }

    if (showMessage != null) {
        AlertDialog(
            onDismissRequest = { showMessage = null },
            title = { Text("Информация") },
            text = { Text(showMessage!!) },
            confirmButton = {
                Button(onClick = { showMessage = null }) { Text("ОК") }
            }
        )
    }

    if (folderToRename != null) {
        AlertDialog(
            onDismissRequest = { folderToRename = null },
            title = { Text("Переименовать папку") },
            text = {
                OutlinedTextField(
                    value = renameFolderName,
                    onValueChange = { renameFolderName = it },
                    label = { Text("Новое название") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (renameFolderName.isNotBlank()) {
                        viewModel.renameFolder(folderToRename!!.id, renameFolderName)
                        folderToRename = null
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = {
                TextButton(onClick = { folderToRename = null }) { Text("Отмена") }
            }
        )
    }
    if (folderToDelete != null) {
        AlertDialog(
            onDismissRequest = { folderToDelete = null },
            title = { Text("Удалить папку?") },
            text = { Text("Вы уверены, что хотите удалить эту папку и все планы в ней?") },
            confirmButton = {
                Button(onClick = {
                    viewModel.deleteFolder(folderToDelete!!)
                    folderToDelete = null
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { folderToDelete = null }) { Text("Отмена") }
            }
        )
    }
    
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddDialog = true }) {
                Icon(Icons.Default.Add, contentDescription = "Добавить папку")
            }
        }
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding).padding(horizontal = 16.dp)) {
            Spacer(modifier = Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Мои папки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                var showBackupMenu by remember { mutableStateOf(false) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        IconButton(onClick = { showBackupMenu = true }) {
                            Icon(Icons.Default.Settings, contentDescription = "Настройки")
                        }
                        DropdownMenu(expanded = showBackupMenu, onDismissRequest = { showBackupMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Создать резервную копию") },
                                onClick = { showBackupMenu = false; exportLauncher.launch("lesson_planner_backup.json") }
                            )
                            DropdownMenuItem(
                                text = { Text("Восстановить из копии") },
                                onClick = { showBackupMenu = false; importLauncher.launch("application/json") }
                            )
                        }
                    }
                    TextButton(onClick = { showArchived = !showArchived }) {
                        Text(if (showArchived) "Скрыть архив" else "Архив")
                    }
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            
            val currentFolders = if (showArchived) archivedFolders else folders
            
            if (currentFolders.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Folder, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(if (showArchived) "Архив пуст" else "У вас пока нет папок", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(currentFolders) { folder ->
                        Card(
                            modifier = Modifier.fillMaxWidth().clickable { navController.navigate("folder_plans/${folder.id}") },
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Icon(Icons.Default.Folder, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.width(16.dp))
                                    Text(folder.name, style = MaterialTheme.typography.titleMedium)
                                }
                                Row {
                                    IconButton(onClick = { 
                                        folderToRename = folder
                                        renameFolderName = folder.name
                                    }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Переименовать")
                                    }
                                    IconButton(onClick = { viewModel.archiveFolder(folder.id, !showArchived) }) {
                                        Icon(
                                            painter = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_save), 
                                            contentDescription = if (showArchived) "Разархивировать" else "Архивировать", 
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                    IconButton(onClick = { folderToDelete = folder.id }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LessonPlansScreen(
    folderId: Long,
    viewModel: LessonPlanListViewModel = viewModel(),
    navController: NavHostController
) {
    LaunchedEffect(folderId) {
        viewModel.loadPlans(folderId)
    }
    val plans by viewModel.plans.collectAsState()
    var searchQuery by remember { mutableStateOf("") }
    var planToDelete by remember { mutableStateOf<Long?>(null) }
    val coroutineScope = rememberCoroutineScope()
    var planToRename by remember { mutableStateOf<com.example.data.local.LessonPlanEntity?>(null) }
    var renamePlanTitle by remember { mutableStateOf("") }
    var renamePlanTags by remember { mutableStateOf("") }
    
    val context = androidx.compose.ui.platform.LocalContext.current
    val filteredPlans = plans.filter { it.title.contains(searchQuery, ignoreCase = true) || it.content.contains(searchQuery, ignoreCase = true) || it.tags.contains(searchQuery, ignoreCase = true) }
    val df = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())
    
    if (planToRename != null) {
        AlertDialog(
            onDismissRequest = { planToRename = null },
            title = { Text("Свойства плана") },
            text = {
                Column {
                    OutlinedTextField(
                        value = renamePlanTitle,
                        onValueChange = { renamePlanTitle = it },
                        label = { Text("Название плана") },
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = renamePlanTags,
                        onValueChange = { renamePlanTags = it },
                        label = { Text("Метки (через запятую)") },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (renamePlanTitle.isNotBlank()) {
                        viewModel.renamePlan(planToRename!!.id, renamePlanTitle)
                        val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                        coroutineScope.launch {
                            db.plannerDao().updatePlanTags(planToRename!!.id, renamePlanTags)
                        }
                        planToRename = null
                    }
                }) { Text("Сохранить") }
            },
            dismissButton = {
                TextButton(onClick = { planToRename = null }) { Text("Отмена") }
            }
        )
    }
    if (planToDelete != null) {
        AlertDialog(
            onDismissRequest = { planToDelete = null },
            title = { Text("Удалить план?") },
            text = { Text("Вы уверены, что хотите безвозвратно удалить этот план урока?") },
            confirmButton = {
                Button(onClick = {
                    viewModel.deletePlan(planToDelete!!)
                    planToDelete = null
                }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
                    Text("Удалить")
                }
            },
            dismissButton = {
                TextButton(onClick = { planToDelete = null }) { Text("Отмена") }
            }
        )
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Планы уроков", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(16.dp))
        
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Поиск планов") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Поиск") }
        )
        Spacer(modifier = Modifier.height(16.dp))
        
        if (plans.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.AutoMirrored.Filled.Article, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("В этой папке пока нет планов", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else if (filteredPlans.isEmpty()) {
             Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Ничего не найдено", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredPlans) { plan ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { navController.navigate("plan_detail/${plan.id}") },
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                                Text(plan.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                IconButton(onClick = { viewModel.toggleFavorite(plan.id, !plan.isFavorite) }) {
                                    Icon(
                                        if (plan.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, 
                                        contentDescription = "Избранное",
                                        tint = if (plan.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(df.format(Date(plan.timestamp)), style = MaterialTheme.typography.bodySmall)
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                IconButton(onClick = {
                                    planToRename = plan
                                    renamePlanTitle = plan.title
                                    renamePlanTags = plan.tags
                                }) {
                                    Icon(Icons.Default.Edit, contentDescription = "Свойства", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { planToDelete = plan.id }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanDetailScreen(
    planId: Long,
    navController: NavHostController
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var plan by remember { mutableStateOf<LessonPlanEntity?>(null) }
    var isPlanLoading by remember { mutableStateOf(true) }
    var isGeneratingActivity by remember { mutableStateOf(false) }
    
    LaunchedEffect(planId) {
        val db = com.example.data.local.PlannerDatabase.getDatabase(context)
        val loadedPlan = db.plannerDao().getPlanById(planId)
        if (loadedPlan != null) {
            plan = loadedPlan.copy(content = com.example.LessonTextSanitizer.sanitizeGeminiMarkdown(loadedPlan.content))
        } else {
            plan = null
        }
        isPlanLoading = false
    }

    if (isPlanLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (plan == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("План не найден")
        }
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
            Text(plan!!.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { 
                coroutineScope.launch {
                    val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                    val newFav = !plan!!.isFavorite
                    db.plannerDao().updateFavoriteStatus(planId, newFav)
                    plan = plan?.copy(isFavorite = newFav)
                }
            }) {
                Icon(
                    if (plan!!.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, 
                    contentDescription = "Избранное",
                    tint = if (plan!!.isFavorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        
        com.example.ui.LessonTimer(durationMinutes = plan!!.durationMinutes)
        
        @OptIn(ExperimentalLayoutApi::class)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Button(
                onClick = {
                    isGeneratingActivity = true
                    coroutineScope.launch {
                        val activityResult = com.example.generateFiveMinuteActivity(plan!!.content)
                        if (activityResult is com.example.GeminiExtraResult.Success) {
                            val activity = activityResult.text
                            val newContent = plan!!.content + "\n\n# ⚡ Пятиминутка\n" + activity
                            val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                            db.plannerDao().updatePlanContent(plan!!.id, newContent)
                            plan = plan?.copy(content = newContent)
                        } else {
                            android.widget.Toast.makeText(context, (activityResult as com.example.GeminiExtraResult.Error).message, android.widget.Toast.LENGTH_SHORT).show()
                        }
                        isGeneratingActivity = false
                    }
                },
                enabled = !isGeneratingActivity
            ) {
                if (isGeneratingActivity) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                } else {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text("Пятиминутка")
            }
            
            Button(
                onClick = {
                    isGeneratingActivity = true
                    coroutineScope.launch {
                        val presentationResult = com.example.generatePresentationOutline(plan!!.content)
                        if (presentationResult is com.example.GeminiExtraResult.Success) {
                            val presentation = presentationResult.text
                            val newContent = plan!!.content + "\n\n# 📊 Структура презентации\n" + presentation
                            val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                            db.plannerDao().updatePlanContent(plan!!.id, newContent)
                            plan = plan?.copy(content = newContent)
                        } else {
                            android.widget.Toast.makeText(context, (presentationResult as com.example.GeminiExtraResult.Error).message, android.widget.Toast.LENGTH_SHORT).show()
                        }
                        isGeneratingActivity = false
                    }
                },
                enabled = !isGeneratingActivity
            ) {
                if (isGeneratingActivity) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                } else {
                    Icon(androidx.compose.material.icons.Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                }
                Text("Презентация")
            }
            
            var hwPhotoUri by remember { mutableStateOf<android.net.Uri?>(null) }
            var hwTargetClass by remember { mutableStateOf<String?>(null) }
            val isTwoClassPlan = com.example.LessonPromptBuilder.looksLikeTwoClassPlan(plan!!.content)
            val handleHwImage = { uri: android.net.Uri ->
                coroutineScope.launch {
                    isGeneratingActivity = true
                    var optimized: DraftLessonImage? = null
                    try {
                        optimized = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                            ImageOptimizer.optimizeImage(context, uri)
                        }
                        
                        if (optimized != null) {
                            val base64Image = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
                                ImageOptimizer.getBase64FromPath(optimized.path)
                            }
                            if (base64Image != null) {
                                val hwResult = com.example.generateHomeworkFromImage(
                                    plan!!.content,
                                    listOf(Pair("image/jpeg", base64Image)),
                                    targetClass = hwTargetClass
                                )
                                if (hwResult is com.example.GeminiExtraResult.Success) {
                                    val hw = hwResult.text
                                    val newContent = plan!!.content + "\n\n# 📚 Домашнее задание по фото учебника\n" + hw
                                    val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                                    db.plannerDao().updatePlanContent(plan!!.id, newContent)
                                    plan = plan?.copy(content = newContent)
                                } else {
                                    android.widget.Toast.makeText(context, (hwResult as com.example.GeminiExtraResult.Error).message, android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        } else {
                            android.widget.Toast.makeText(context, "Ошибка обработки фото", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Exception) {
                        android.widget.Toast.makeText(context, "Ошибка: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                    } finally {
                        isGeneratingActivity = false
                        ImageOptimizer.cleanUpTempCameraFiles(context)
                        optimized?.let { java.io.File(it.path).delete() }
                        // Also, if optimized was created just for HW, we shouldn't keep it forever, but deleting here is fine if we can track it.
                        // Actually, we don't need to save the HW image permanently, we can delete the optimized one too.
                    }
                }
            }

            val imagePickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
            ) { uri: android.net.Uri? ->
                uri?.let { handleHwImage(it) }
            }

            val takePictureLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.TakePicture()
            ) { success: Boolean ->
                if (success) {
                    hwPhotoUri?.let { handleHwImage(it) }
                }
            }

            var expandedMenu by remember { mutableStateOf(false) }
            Box {
                Button(
                    onClick = { expandedMenu = true },
                    enabled = !isGeneratingActivity
                ) {
                    if (isGeneratingActivity) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                    } else {
                        Icon(Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text("ДЗ по фото")
                }
                DropdownMenu(
                    expanded = expandedMenu,
                    onDismissRequest = { expandedMenu = false }
                ) {
                    fun chooseGallery(targetClass: String?) {
                        expandedMenu = false
                        hwTargetClass = targetClass
                        imagePickerLauncher.launch("image/*")
                    }
                    fun chooseCamera(targetClass: String?) {
                        expandedMenu = false
                        hwTargetClass = targetClass
                        val tempFile = java.io.File(context.cacheDir, "temp_camera_${System.currentTimeMillis()}.jpg")
                        val uri = androidx.core.content.FileProvider.getUriForFile(context, "com.aistudio.lessonplanner.xyazqw.fileprovider", tempFile)
                        hwPhotoUri = uri
                        takePictureLauncher.launch(uri)
                    }

                    if (isTwoClassPlan) {
                        DropdownMenuItem(
                            text = { Text("Класс 1 — из галереи") },
                            onClick = { chooseGallery("Класс 1") },
                            leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Класс 1 — сделать фото") },
                            onClick = { chooseCamera("Класс 1") },
                            leadingIcon = { Icon(Icons.Default.CameraAlt, contentDescription = null) }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text("Класс 2 — из галереи") },
                            onClick = { chooseGallery("Класс 2") },
                            leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Класс 2 — сделать фото") },
                            onClick = { chooseCamera("Класс 2") },
                            leadingIcon = { Icon(Icons.Default.CameraAlt, contentDescription = null) }
                        )
                    } else {
                        DropdownMenuItem(
                            text = { Text("Выбрать из галереи") },
                            onClick = { chooseGallery(null) },
                            leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) }
                        )
                        DropdownMenuItem(
                            text = { Text("Сделать фото") },
                            onClick = { chooseCamera(null) },
                            leadingIcon = { Icon(Icons.Default.CameraAlt, contentDescription = null) }
                        )
                    }
                }
            }

            Button(onClick = {
                val sendIntent = Intent().apply {
                    action = Intent.ACTION_SEND
                    putExtra(Intent.EXTRA_TEXT, plan!!.content)
                    type = "text/plain"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Поделиться планом"))
            }) {
                Icon(Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Поделиться")
            }
            
            val createDocLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
                contract = androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/rtf")
            ) { uri ->
                uri?.let {
                    context.contentResolver.openOutputStream(it)?.use { outputStream ->
                        val md = plan?.content ?: ""
                        val sb = java.lang.StringBuilder()
                        sb.append("{\\rtf1\\ansi\\ansicpg1251\\uc1\\deff0{\\fonttbl{\\f0\\fswiss\\fcharset204 Arial;}}\\f0\\fs24\n")
                        md.lines().forEach { line ->
                            var pLine = line.trimEnd()
                            val toRtfUnicode = { s: String ->
                                s.replace("\\", "\\\\").replace("{", "\\{").replace("}", "\\}").map { c -> if (c.code > 127) "\\u${c.code}?" else c.toString() }.joinToString("")
                            }
                            
                            if (pLine.startsWith("# ")) {
                                pLine = "\\b\\fs36 " + toRtfUnicode(pLine.removePrefix("# ")) + "\\b0\\fs24"
                            } else if (pLine.startsWith("## ")) {
                                pLine = "\\b\\fs32 " + toRtfUnicode(pLine.removePrefix("## ")) + "\\b0\\fs24"
                            } else if (pLine.startsWith("### ")) {
                                pLine = "\\b\\fs28 " + toRtfUnicode(pLine.removePrefix("### ")) + "\\b0\\fs24"
                            } else if (pLine.startsWith("- ") || pLine.startsWith("* ")) {
                                pLine = "\\bullet  " + toRtfUnicode(pLine.substring(2))
                            } else {
                                pLine = toRtfUnicode(pLine)
                            }
                            
                            pLine = pLine.replace(Regex("\\*\\*(.*?)\\*\\*")) { "\\b " + it.groupValues[1] + "\\b0 " }
                            sb.append(pLine).append("\\par\n")
                        }
                        sb.append("}")
                        outputStream.write(sb.toString().toByteArray())
                    }
                }
            }
            Button(onClick = { 
                createDocLauncher.launch("${plan!!.title.replace(" ", "_")}.rtf") 
            }) {
                Text("Редактируемый документ")
            }
            
            OutlinedButton(onClick = {
                coroutineScope.launch {
                    val db = com.example.data.local.PlannerDatabase.getDatabase(context)
                    db.plannerDao().insertLessonPlan(
                        plan!!.copy(id = 0, title = plan!!.title + " (Копия)", timestamp = System.currentTimeMillis())
                    )
                    android.widget.Toast.makeText(context, "План скопирован", android.widget.Toast.LENGTH_SHORT).show()
                }
            }) {
                Text("Клонировать")
            }
            
            OutlinedButton(onClick = {
                val intent = android.content.Intent(android.content.Intent.ACTION_INSERT).apply {
                    data = android.provider.CalendarContract.Events.CONTENT_URI
                    putExtra(android.provider.CalendarContract.Events.TITLE, plan!!.title)
                    putExtra(android.provider.CalendarContract.Events.DESCRIPTION, plan!!.content.take(500) + "...")
                }
                context.startActivity(intent)
            }) {
                Icon(Icons.Default.DateRange, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("В календарь")
            }
            
            val webView = android.webkit.WebView(context)
            Button(onClick = {
                val materials = com.example.extractCardsForPrinting(plan!!.content)
                
                var htmlBody = materials
                htmlBody = htmlBody.replace(Regex("\\*\\*(.*?)\\*\\*"), "<b>$1</b>")
                htmlBody = htmlBody.replace(Regex("### (.*?)\n"), "</div><div class=\"card\"><h3>$1</h3>\n")
                htmlBody = htmlBody.replace(Regex("## (.*?)\n"), "</div><div class=\"card\"><h2>$1</h2>\n")
                htmlBody = htmlBody.replace(Regex("# (.*?)\n"), "</div><div class=\"card\"><h1>$1</h1>\n")
                htmlBody = htmlBody.replace(Regex("\\* (.*?)\n"), "<li>$1</li>\n")
                htmlBody = htmlBody.replace(Regex("- (.*?)\n"), "<li>$1</li>\n")
                htmlBody = htmlBody.replace(Regex("!\\[(.*?)\\]\\((.*?)\\)"), "<img src=\"$2\" alt=\"$1\" style=\"max-width: 100%; border-radius: 8px; margin: 10px 0;\">")
                htmlBody = htmlBody.replace("\n", "<br>")
                
                // Remove the first closing div if it exists at the beginning
                if (htmlBody.startsWith("</div>")) {
                    htmlBody = htmlBody.substring(6)
                } else {
                    htmlBody = "<div class=\"card\">$htmlBody"
                }
                htmlBody += "</div>"
                
                // Clean up empty cards
                htmlBody = htmlBody.replace("<div class=\"card\"></div>", "")

                val htmlContent = """
                    <html>
                    <head>
                        <meta charset="utf-8">
                        <style>
                            body { font-family: sans-serif; padding: 20px; font-size: 18px; background: #fff; }
                            .grid {
                                display: grid;
                                grid-template-columns: repeat(2, 1fr);
                                gap: 20px;
                            }
                            .card {
                                border: 2px dashed #999;
                                padding: 20px;
                                border-radius: 12px;
                                page-break-inside: avoid;
                                background-color: #fafafa;
                                box-shadow: 2px 2px 5px rgba(0,0,0,0.05);
                            }
                            h1, h2, h3 { margin-top: 0; color: #333; }
                            ul { padding-left: 20px; }
                            @media print {
                                body { padding: 0; }
                                .card { border-color: #000; box-shadow: none; }
                            }
                        </style>
                    </head>
                    <body>
                        <h2 style="text-align: center; margin-bottom: 30px;">Раздаточные материалы</h2>
                        <div class="grid">
                            $htmlBody
                        </div>
                    </body>
                    </html>
                """.trimIndent()
                
                webView.webViewClient = object : android.webkit.WebViewClient() {
                    override fun onPageFinished(view: android.webkit.WebView, url: String) {
                        val printManager = context.getSystemService(android.content.Context.PRINT_SERVICE) as android.print.PrintManager
                        val printAdapter = view.createPrintDocumentAdapter("Карточки к уроку")
                        printManager.print("Cards", printAdapter, android.print.PrintAttributes.Builder().build())
                    }
                }
                webView.loadDataWithBaseURL(null, htmlContent, "text/HTML", "UTF-8", null)
            }) {
                Icon(painter = androidx.compose.ui.res.painterResource(android.R.drawable.ic_menu_agenda), contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Карточки (PDF/Печать)")
            }
        }
        HorizontalDivider()
        androidx.compose.foundation.text.selection.SelectionContainer {
            com.example.ui.MarkdownViewer(
                markdown = plan!!.content
            )
        }
    }
}
