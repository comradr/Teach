package com.example.ui

import android.content.Context
import android.net.Uri
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import com.itextpdf.layout.element.Table
import com.itextpdf.layout.element.Cell
import com.itextpdf.kernel.font.PdfFontFactory
import com.itextpdf.io.font.PdfEncodings
import com.itextpdf.layout.properties.TextAlignment
import com.example.data.local.LessonPlanEntity
import java.io.File

object PdfGenerator {
    fun generateGostPdf(context: Context, uri: Uri, plan: LessonPlanEntity): String? {
        try {
            val outputStream = context.contentResolver.openOutputStream(uri) ?: return "Failed to open output stream"
            val writer = PdfWriter(outputStream)
            val pdf = PdfDocument(writer)
            val document = Document(pdf)

            val fontFile = File("/system/fonts/Roboto-Regular.ttf")
            val font = if (fontFile.exists()) {
                PdfFontFactory.createFont(fontFile.absolutePath, PdfEncodings.IDENTITY_H)
            } else {
                PdfFontFactory.createFont()
            }

            document.add(Paragraph("Министерство просвещения Российской Федерации\n\n\n\n\n\n")
                .setFont(font)
                .setFontSize(14f)
                .setTextAlignment(TextAlignment.CENTER))
                
            document.add(Paragraph("ПЛАН-КОНСПЕКТ УРОКА\n\n")
                .setFont(font)
                .setFontSize(24f)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER))
                
            document.add(Paragraph(plan.title)
                .setFont(font)
                .setFontSize(18f)
                .setTextAlignment(TextAlignment.CENTER))
                
            val lines = plan.content.split("\n")
            var i = 0
            while (i < lines.size) {
                val line = lines[i]
                if (line.trim().startsWith("|")) {
                    // Accumulate table
                    val tableLines = mutableListOf<String>()
                    while (i < lines.size && lines[i].trim().startsWith("|")) {
                        tableLines.add(lines[i].trim())
                        i++
                    }
                    if (tableLines.isNotEmpty()) {
                        // First row is header
                        val headerCells = tableLines[0].split("|").map { it.trim() }.filter { it.isNotEmpty() }
                        val numCols = headerCells.size
                        if (numCols > 0) {
                            val table = Table(numCols)
                            // Skip the separator row (usually like |---|---|)
                            for (r in 0 until tableLines.size) {
                                if (r == 1 && tableLines[r].contains("---")) continue
                                val rowCells = tableLines[r].split("|").map { it.trim() }.filter { it.isNotEmpty() }
                                for (c in 0 until numCols) {
                                    val cellText = if (c < rowCells.size) rowCells[c].replace("**", "") else ""
                                    val cell = Cell().add(Paragraph(cellText).setFont(font).setFontSize(10f))
                                    if (r == 0) cell.setBold()
                                    table.addCell(cell)
                                }
                            }
                            document.add(table.setMarginTop(10f).setMarginBottom(10f))
                        }
                    }
                    continue // Already advanced i
                } else if (line.startsWith("# ")) {
                    document.add(Paragraph(line.removePrefix("# "))
                        .setFont(font).setFontSize(16f).setBold().setMarginTop(10f))
                } else if (line.startsWith("## ")) {
                    document.add(Paragraph(line.removePrefix("## "))
                        .setFont(font).setFontSize(14f).setBold().setMarginTop(8f))
                } else if (line.startsWith("### ")) {
                    document.add(Paragraph(line.removePrefix("### "))
                        .setFont(font).setFontSize(12f).setBold().setMarginTop(6f))
                } else if (line.startsWith("- ") || line.startsWith("* ")) {
                    document.add(Paragraph("• " + line.drop(2))
                        .setFont(font).setFontSize(12f).setMarginLeft(15f))
                } else if (line.isNotBlank()) {
                    val cleanText = line.replace("**", "")
                    document.add(Paragraph(cleanText)
                        .setFont(font).setFontSize(12f))
                }
                i++
            }

            document.close()
            return null // Success
        } catch (e: Exception) {
            e.printStackTrace()
            return e.localizedMessage
        }
    }
}
