package com.example.ui

import android.widget.TextView
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import io.noties.markwon.Markwon
import io.noties.markwon.ext.tables.TablePlugin
import io.noties.markwon.image.coil.CoilImagesPlugin

@Composable
fun MarkdownViewer(markdown: String, modifier: Modifier = Modifier) {
    AndroidView(
        modifier = modifier.fillMaxWidth().padding(bottom = 8.dp),
        factory = { context ->
            TextView(context).apply {
                // Configure TextView if needed
            }
        },
        update = { textView ->
            val markwon = Markwon.builder(textView.context)
                .usePlugin(TablePlugin.create(textView.context))
                .usePlugin(CoilImagesPlugin.create(textView.context))
                .build()
            markwon.setMarkdown(textView, markdown)
        }
    )
}
