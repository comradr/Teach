# Сборка APK

Проект подготовлен для сборки debug APK.

## Самый простой вариант — GitHub Actions

1. Создайте пустой репозиторий на GitHub.
2. Загрузите **содержимое этой папки** в корень репозитория.
3. Если нужен ключ Gemini, встроенный при сборке, откройте в GitHub:
   **Settings → Secrets and variables → Actions → New repository secret**.
4. Создайте секрет с именем `GEMINI_API_KEY` и вставьте свой ключ.
5. Откройте вкладку **Actions → Build APK → Run workflow**.
6. После завершения сборки откройте запуск workflow и скачайте artifact **Plania-v1.5.0-unsigned**.
7. Внутри будет `app-debug.apk`.

Workflow сам использует JDK 17, ставит Android SDK Platform 36.1, запускает unit-тесты, Android lint и `assembleRelease`. Он не публикует приватный ключ: готовый unsigned APK подписывается локально прежним файлом `mksh-planner-update.jks` с alias `mkshupdate`. Если GitHub Secret Gemini не задан, сборка всё равно проходит с безопасным placeholder; личный API-ключ затем вводится в приложении нажатием на верхнего маскота.

## Через Android Studio

1. Откройте эту папку как проект.
2. Дождитесь Gradle Sync.
3. Создайте рядом с `.env.example` файл `.env`:

   `GEMINI_API_KEY=ВАШ_КЛЮЧ`

4. Выберите **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
5. APK появится в:

   `app/build/outputs/apk/debug/app-debug.apk`

## Важно

- В проект уже положен исправный `gradle/wrapper/gradle-wrapper.jar`.
- Для AGP 9.1.1 нужен JDK 17 и Gradle 9.3.1.
- Проект компилируется против Android SDK 36.1 (`compileSdk 36`, `minorApiLevel 1`).
- Debug APK не требует вашего release-keystore.
- Чтобы установить APK поверх ранее установленной стабильной версии без потери данных, соберите release APK с тем же сертификатом. В проекте уже повышен `versionCode` до 14 и добавлена миграция базы 6 → 7.
